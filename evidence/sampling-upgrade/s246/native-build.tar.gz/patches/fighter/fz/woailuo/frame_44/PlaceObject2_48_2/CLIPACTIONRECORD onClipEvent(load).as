onClipEvent(load){
_root.aiAtm1Observe("load_before",this,"game/fighter/fz/woailuo.swf#frame_44/PlaceObject2_48_2/CLIPACTIONRECORD onClipEvent(load).as");

   if(_parent._xscale < 0)
   {
      _X = - (_root.game["p" + _parent.pn]._x - _parent._x);
   }
   else
   {
      _X = _root.game["p" + _parent.pn]._x - _parent._x;
   }

_root.aiAtm1Observe("load_after",this,"game/fighter/fz/woailuo.swf#frame_44/PlaceObject2_48_2/CLIPACTIONRECORD onClipEvent(load).as");
}
