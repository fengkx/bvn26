onClipEvent(enterFrame){
   if(_root.s275Value("pause", _root.zhanting == false))
   {
      if(_root.s275Value("result1", _root.s275Value("receiver1", mian).hitTest(_root.s275Value("target1", _root.game["p" + _parent.pn].mc.bdmn))) or _root.s275Value("result2", _root.s275Value("receiver2", mian).hitTest(_root.s275Value("target2", _root.game["p" + _parent.pn].mc.zh1atm))) or _root.s275Value("result3", _root.s275Value("receiver3", mian).hitTest(_root.s275Value("target3", _root.game["p" + _parent.pn].mc.zh2atm))) or _root.s275Value("result4", _root.s275Value("receiver4", hitmc.mian).hitTest(_root.s275Value("target4", _root.game["p" + _parent.pn].mc.zh3atm))) or _root.s275Value("result5", _root.s275Value("receiver5", mian).hitTest(_root.s275Value("target5", _root.game["p" + _parent.pn].mc.abcd))))
      {
         if(_root.s275Value("played", played == 0))
         {
            played = 1;
            movspeed = 0;
            _root.s275Boundary("before_goto", this);
         gotoAndPlay(5);
         _root.s275Boundary("after_goto", this);
         }
      }
      else
      {
         _X = _X + movspeed;
      }
   }
}
