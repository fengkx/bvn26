_root.s275Boundary("before_rename", this);
this._name = "abcd";
_root.s275Boundary("after_rename", this);
