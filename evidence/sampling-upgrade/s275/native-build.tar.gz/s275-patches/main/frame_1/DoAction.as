// Analysis-only pass-through: return the same once-evaluated value.
_root.s275Value = function(site, value)
{
   if(_root.aiFight >= 15 && _root.aiFight <= 22)
   {
      _root.aiEvent("s275_value", site + "," + typeof(value) + "," + escape(String(value)) + "," + escape(String(value._parent)) + "," + value._currentframe + "," + value.__aiGeoId + "," + escape(String(value.__aiGeoSource)));
   }
   return value;
};
_root.s275Boundary = function(phase, mc)
{
   if(_root.aiFight < 15 || _root.aiFight > 22) return;
   _root.aiEvent("s275_boundary", phase + "," + escape(String(mc)) + "," + mc._currentframe + "," + mc.__aiGeoId + "," + escape(String(mc._parent)) + "," + escape(String(mc.mian)) + "," + escape(String(mc.getInstanceAtDepth(-16382))) + "," + escape(String(_root.game.p1.mc.getInstanceAtDepth(-16356))) + "," + escape(String(_root.game.p1.mc.k1atm)) + "," + escape(String(_root.game.p1.mc.abcd)));
};
Stage.displayState = "normal";
Stage.scaleMode = "showAll";
// Observe the original target expression; do not substitute an ancestor's pn.
_root.aiK1Observe = function(phase, mc, target)
{
   if(_root.aiFight < 15 || _root.aiFight > 19) return;
   var parent = mc._parent;
   var grandparent = parent._parent;
   _root.aiEvent("k1atm_provenance", phase + "," + escape(String(mc)) + "," + (mc != undefined) + "," + mc._currentframe + "," + escape(String(mc.__aiGeoId)) + "," + escape(String(mc.__aiGeoSource)) + "," + escape(String(mc.__aiGeoBirth)) + "," + escape(String(parent)) + "," + parent._currentframe + "," + parent.pn + "," + escape(String(target)) + "," + (mc._fsArray != undefined) + "," + mc._fsArray.length + "," + escape(String(mc._fsArray)) + "," + (mc._fzfsArray != undefined) + "," + mc._fzfsArray.length + "," + escape(String(mc._fzfsArray)) + "," + (mc.stgks != undefined) + "," + mc.stgks.length + "," + escape(String(mc.stgks)) + "," + typeof(mc.getHitObj) + "," + typeof(mc.getStgHitObj) + "," + escape(String(grandparent)) + "," + grandparent.pn);
};
// Analysis only: enumerate the source collision receivers and their candidate lists.
_root.aiGeoSerial = 0;
_root.aiGeoStamp = function(mc, source)
{
   if(mc.__aiGeoId == undefined)
   {
      mc.__aiGeoId = ++_root.aiGeoSerial;
      mc.__aiGeoSource = source;
      mc.__aiGeoBirth = _root.aiDisplay;
   }
};
_root.aiGeoBox = function(mc, role)
{
   if(mc == undefined) return;
   var path = String(mc);
   if(_root.aiGeoSeen[path] == true) return;
   _root.aiGeoSeen[path] = true;
   if(mc.__aiGeoId == undefined || mc.__aiGeoSource == undefined)
   {
      _root.aiEvent("geometry_error", "unbound:" + path);
      return;
   }
   var m = mc.transform.concatenatedMatrix;
   var b = mc.getBounds(mc);
   _root.aiEvent("geometry_box", role + "," + path + "," + mc.__aiGeoId + "," + mc.__aiGeoSource + "," + mc.__aiGeoBirth + "," + mc.getDepth() + "," + mc._currentframe + "," + _root.aiNumber(m.a) + "," + _root.aiNumber(m.b) + "," + _root.aiNumber(m.c) + "," + _root.aiNumber(m.d) + "," + _root.aiNumber(m.tx) + "," + _root.aiNumber(m.ty) + "," + _root.aiNumber(b.xMin) + "," + _root.aiNumber(b.yMin) + "," + _root.aiNumber(b.xMax) + "," + _root.aiNumber(b.yMax));
   _root.aiGeoCount++;
};
_root.aiGeoWalk = function(mc)
{
   var path = String(mc);
   if(_root.aiGeoWalked[path] == true) return;
   _root.aiGeoWalked[path] = true;
   if(typeof(mc.getHitObj) == "function" && typeof(mc.getStgHitObj) == "function")
   {
      _root.aiGeoReceivers++;
      var boxName = mc._name;
      var boxRole = boxName.substr(boxName.length - 3) == "atm" ? "attack" : "hurt";
      _root.aiGeoBox(mc,boxRole);
      var target = _root.game["p" + mc._parent.pn];
      if(path == "_level0.game.p1.mc.k1atm.mian") _root.aiK1Observe("source_list_check",mc,target);
      if(target == undefined || mc._fsArray == undefined || mc._fzfsArray == undefined || mc.stgks == undefined)
         _root.aiEvent("geometry_error", "missing-source-list:" + path);
      for(var i in mc._fsArray) _root.aiGeoBox(target.mc[mc._fsArray[i] + "atm"],"attack");
      for(var j in mc._fzfsArray) _root.aiGeoBox(_root.game["p" + mc._parent.pn + "fz"][mc._fzfsArray[j]],"helper_attack");
      for(var k in mc.stgks)
      {
         var stage = _root.game.layer_effect[mc.stgks[k] + "_P" + mc._parent.pn];
         if(stage != undefined) _root.aiGeoBox(stage.mian,"stage_attack");
      }
   }
   for(var name in mc)
   {
      var child = mc[name];
      if(typeof(child) == "movieclip" && child._parent == mc) _root.aiGeoWalk(child);
   }
};
_root.aiGeometrySample = function()
{
   if(_root.aiFight < 0) return;
   _root.aiGeoSeen = {};
   _root.aiGeoWalked = {};
   _root.aiGeoCount = 0;
   _root.aiGeoReceivers = 0;
   _root.aiEvent("geometry_begin", "");
   _root.aiGeoWalk(_root.game);
   _root.aiEvent("geometry_end", _root.aiGeoCount + "," + _root.aiGeoReceivers);
};
_root.aiHelperClipFrame = function(helper, instanceName)
{
   var clip = helper[instanceName];
   return clip == undefined ? undefined : clip._currentframe;
};
_root.aiHelperState = function(player)
{
   var f = _root.game[player + "fz"];
   var m = f;
   _root.aiEvent("helper_state", player + "," + m._currentframe + "," + _root.aiNumber(f._x) + "," + _root.aiNumber(f._y) + "," + _root.aiNumber(f._xscale) + "," + m.attacking + "," + m.动作 + "," + m.hits + "," + _root.aiHelperClipFrame(f,"atm1") + "," + _root.aiHelperClipFrame(f,"atm2") + "," + _root.aiHelperClipFrame(f,"atm3"));
   _root.aiEvent("helper_clip_state", player + "," + m._currentframe + "," + "atm1" + "=" + _root.aiHelperClipFrame(f,"atm1"));
   var parent = f._parent;
   _root.aiEvent("helper_lifecycle", player + "," + m._currentframe + "," + f._visible + "," + _root.zhanting + "," + (parent == undefined ? undefined : parent._currentframe) + "," + _root.aiHelperClipFrame(f,"atm1") + "," + _root.aiHelperClipFrame(f,"atm2") + "," + _root.aiHelperClipFrame(f,"atm3"));
};
// Analysis-only binary significand encoding avoids FP32's short decimal strings.
_root.aiNumber = function(value)
{
   if(typeof value != "number" || !isFinite(value)) return String(value);
   if(value == 0) return "f:" + (1 / value < 0 ? -1 : 1) + ":0:0:0";
   var sign = value < 0 ? -1 : 1;
   var fraction = Math.abs(value);
   var exponent = 0;
   while(fraction >= 2) { fraction /= 2; exponent++; }
   while(fraction < 1) { fraction *= 2; exponent--; }
   var mantissa = fraction * 4503599627370496;
   var high = Math.floor(mantissa / 67108864);
   var low = mantissa - high * 67108864;
   return "f:" + sign + ":" + exponent + ":" + high + ":" + low;
};
// Analysis-only bootstrap: the original battle loader and AI remain active.
_root.aiRun = "s275-yulong-r01";
_root.aiSeq = 0;
_root.aiDisplay = 0;
_root.aiFight = -1;
_root.aiDraw = 0;
_root.aiClockDraw = 0;
_root.aiNativeRandom = Math.random;
_root.aiEvent = function(kind, value)
{
   trace("AIREF|" + aiRun + "|" + (++aiSeq) + "|" + getTimer() + "|" + aiDisplay + "|" + aiFight + "|" + kind + "|" + value);
};
_root.aiTimer = function(site)
{
   var value = getTimer();
   _root.aiEvent("clock", (++_root.aiClockDraw) + "," + site + "," + value);
   return value;
};
_root.aiRandom = function(site)
{
   var value = _root.aiNativeRandom();
   _root.aiEvent("random", (++_root.aiDraw) + "," + site + "," + _root.aiNumber(value));
   return value;
};
_root.aiPredicate = function(name, receiver, value)
{
   if(receiver._parent._parent.useAI || receiver._parent.useAI)
   {
      _root.aiEvent("predicate", name + "," + receiver + "," + value);
   }
   return value;
};
_root.aiState = function(player)
{
   var f = _root.game[player];
   var m = f.mc;
   _root.aiEvent("state", player + "," + m._currentframe + "," + _root.aiNumber(f._x) + "," + _root.aiNumber(f._y) + "," + _root.aiNumber(f._xscale) + "," + m.动作 + "," + _root.aiNumber(m.hp) + "," + _root.aiNumber(m.ql) + "," + m.sw + "," + m.touch + "," + m.touchFloor + "," + m.hits + "," + _root.zhanting + "," + m.hstm + "," + m.hurtSkling);
};
_root.aiGeometry = function()
{
   var f = _root.game.p2;
   var m = f.mc;
   var target = _root.game.p1.mc.bdmn;
   var names = ["kanmian","tkanmian","zh1mian","zh2mian","zh3mian","kj1mian","kj2mian","bsmian","sbsmian","cbsmian","tzmian","absmian"];
   _root.aiEvent("geometry_frame", m._currentframe + "," + f._x + "," + f._y + "," + f._xscale);
   var chain = [f,m,m.AImain];
   for(var c = 0; c < chain.length; c++)
   {
      var cm = chain[c].transform.matrix;
      var gm = chain[c].transform.concatenatedMatrix;
      _root.aiEvent("geometry_matrix", c + "," + cm.a + "," + cm.b + "," + cm.c + "," + cm.d + "," + cm.tx + "," + cm.ty + "," + gm.a + "," + gm.b + "," + gm.c + "," + gm.d + "," + gm.tx + "," + gm.ty);
   }
   for(var n = 0; n < names.length; n++)
   {
      var obj = m.AImain[names[n]];
      var bounds = obj.getBounds(f);
      _root.aiEvent("sensor_bounds", names[n] + "," + bounds.xMin + "," + bounds.yMin + "," + bounds.xMax + "," + bounds.yMax + "," + obj.hitTest(target));
      var own = obj.getBounds(obj);
      var sm = obj.transform.matrix;
      _root.aiEvent("sensor_local", names[n] + "," + own.xMin + "," + own.yMin + "," + own.xMax + "," + own.yMax + "," + sm.a + "," + sm.b + "," + sm.c + "," + sm.d + "," + sm.tx + "," + sm.ty);
   }
};
function showCommt()
{
   if(allowGoLink)
   {
      goLink();
      return undefined;
   }
   if(_global.bridge)
   {
      _global.bridge.showGameList();
   }
}
function goLink(url)
{
}
_root.ver = "V 2.6";
_root.date_ver = "2016/6/23";
var adType;
var wudi = false;
var TYPE_4399 = "4399";
var allowGoLink = true;
var NO_AD = "no-ad";
var debuging = true;
adType = TYPE_4399;
var _loc0_;
if((_loc0_ = adType) === TYPE_4399)
{
   _global.bridge = AS2_4399_API.Bridge.getInstance();
   var _4399_function_ad_id = "944c23f5e64a80647f8d0f3435f5c7a8";
   allowGoLink = false;
}

gotoAndPlay(6);

_root.aiGeoStamp(this, "game/main.swf#frame_1/DoAction.as");
