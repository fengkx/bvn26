_root._y -= 2;

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_638/frame_246/DoAction.as");
