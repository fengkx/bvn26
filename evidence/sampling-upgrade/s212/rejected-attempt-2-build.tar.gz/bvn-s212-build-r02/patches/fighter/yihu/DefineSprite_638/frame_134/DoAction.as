动作 = 0;

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_638/frame_134/DoAction.as");
