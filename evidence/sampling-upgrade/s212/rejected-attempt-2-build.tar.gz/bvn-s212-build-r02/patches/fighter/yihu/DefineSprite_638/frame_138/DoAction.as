gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_638/frame_138/DoAction.as");
