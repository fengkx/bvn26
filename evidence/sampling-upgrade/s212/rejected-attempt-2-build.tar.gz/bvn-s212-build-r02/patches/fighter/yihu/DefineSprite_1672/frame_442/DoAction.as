if(_parent._xscale < 0)
{
   _parent._xscale = 100;
   _parent._x = _root.game["p" + pn]._x - 100;
}
else
{
   _parent._xscale = -100;
   _parent._x = _root.game["p" + pn]._x + 100;
}
_parent._y = _root.game["p" + pn]._y;

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1672/frame_442/DoAction.as");
