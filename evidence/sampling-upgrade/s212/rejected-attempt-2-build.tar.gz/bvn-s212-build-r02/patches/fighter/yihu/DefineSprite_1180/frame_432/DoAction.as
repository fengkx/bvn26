_root.shine(0);

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1180/frame_432/DoAction.as");
