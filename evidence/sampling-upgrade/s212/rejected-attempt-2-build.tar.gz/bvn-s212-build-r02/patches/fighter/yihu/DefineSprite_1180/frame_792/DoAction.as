stop();

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1180/frame_792/DoAction.as");
