动作 = 0;

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1672/frame_330/DoAction.as");
