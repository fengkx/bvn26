_root.shine();

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1180/frame_542/DoAction.as");
