khit = 0;
jump = 0;

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1672/frame_110/DoAction.as");
