jump = 0;
jumped = 1;
clearInterval(tdint);
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1180/frame_796/DoAction.as");
