_root.cbsw(pn);
bs = 0;

_root.aiGeoStamp(this, "game/fighter/yihu.swf#DefineSprite_1672/frame_783/DoAction.as");
