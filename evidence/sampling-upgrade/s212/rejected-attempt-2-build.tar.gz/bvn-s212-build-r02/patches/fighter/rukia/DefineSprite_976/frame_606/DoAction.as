动作 = 3;
bs = 1;
ql -= 100;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_606/DoAction.as");
