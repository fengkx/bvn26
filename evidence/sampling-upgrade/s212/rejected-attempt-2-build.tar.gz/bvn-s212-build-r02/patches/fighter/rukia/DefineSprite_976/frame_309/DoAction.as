动作 = 1;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_309/DoAction.as");
