_root.shine(2679032);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_517/DoAction.as");
