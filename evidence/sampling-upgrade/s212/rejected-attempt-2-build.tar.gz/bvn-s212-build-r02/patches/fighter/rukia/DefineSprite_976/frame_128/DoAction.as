khit = 1;
动作 = 1;
jump = 0;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_128/DoAction.as");
