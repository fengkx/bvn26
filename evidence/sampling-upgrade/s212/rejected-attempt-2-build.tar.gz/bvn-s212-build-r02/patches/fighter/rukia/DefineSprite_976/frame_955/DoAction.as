doZhaoHuan();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_955/DoAction.as");
