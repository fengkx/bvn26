_root.bsw(pn);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_681/DoAction.as");
