kcplayed = 3;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_1006/DoAction.as");
