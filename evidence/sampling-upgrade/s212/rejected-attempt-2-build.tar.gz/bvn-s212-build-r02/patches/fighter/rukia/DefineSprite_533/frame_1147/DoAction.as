wankai_start();
_root.showFace(pn,"露其亚2");

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_1147/DoAction.as");
