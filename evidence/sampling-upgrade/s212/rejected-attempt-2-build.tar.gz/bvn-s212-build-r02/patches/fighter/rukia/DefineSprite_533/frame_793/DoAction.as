_root.shine();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_793/DoAction.as");
