khit = 0;
jump = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_116/DoAction.as");
