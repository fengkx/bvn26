动作 = 3;
bs = 1;
ql -= 300;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_814/DoAction.as");
