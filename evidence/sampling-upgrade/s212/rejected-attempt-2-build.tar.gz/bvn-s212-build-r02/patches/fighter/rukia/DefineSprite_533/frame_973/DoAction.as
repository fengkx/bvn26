gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_973/DoAction.as");
