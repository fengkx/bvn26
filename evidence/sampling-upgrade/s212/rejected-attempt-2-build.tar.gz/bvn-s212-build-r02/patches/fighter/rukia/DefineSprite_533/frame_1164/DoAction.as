wankai();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_1164/DoAction.as");
