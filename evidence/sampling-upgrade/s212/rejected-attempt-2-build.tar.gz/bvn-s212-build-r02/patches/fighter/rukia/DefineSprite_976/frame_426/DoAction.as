if(_parent._xscale > 0)
{
   _parent.scale_X = -1;
   _parent._xscale = -100;
   _parent._x = _root.game["p" + pn]._x + 50;
}
else
{
   _parent.scale_X = 1;
   _parent._xscale = 100;
   _parent._x = _root.game["p" + pn]._x - 50;
}

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_426/DoAction.as");
