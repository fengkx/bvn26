_root.shine(11598072);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_794/DoAction.as");
