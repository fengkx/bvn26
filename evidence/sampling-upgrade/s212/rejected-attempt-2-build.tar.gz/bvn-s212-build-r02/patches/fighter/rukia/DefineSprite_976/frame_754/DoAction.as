_root.shine(2679032);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_754/DoAction.as");
