gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_202/DoAction.as");
