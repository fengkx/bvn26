_root.shine(2798587);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_414/DoAction.as");
