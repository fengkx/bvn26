动作 = 1;
ql += 10;
jump = 1;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_372/DoAction.as");
