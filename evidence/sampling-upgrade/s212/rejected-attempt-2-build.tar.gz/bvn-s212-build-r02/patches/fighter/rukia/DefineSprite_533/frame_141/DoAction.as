gotoAndPlay(130);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_141/DoAction.as");
