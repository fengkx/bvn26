动作 = 1;
ql += 10;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_355/DoAction.as");
