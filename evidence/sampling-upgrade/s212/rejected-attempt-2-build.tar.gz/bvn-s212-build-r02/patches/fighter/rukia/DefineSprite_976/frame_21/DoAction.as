_root.shunbuxg(_parent);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_21/DoAction.as");
