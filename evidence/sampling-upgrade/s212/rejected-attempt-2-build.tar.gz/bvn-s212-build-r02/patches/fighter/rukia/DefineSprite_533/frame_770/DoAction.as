_root.cbsw(pn);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_770/DoAction.as");
