动作 = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_903/DoAction.as");
