play();
kcplayed = 1;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_1004/DoAction.as");
