stop();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_1105/DoAction.as");
