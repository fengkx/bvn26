stop();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_924/DoAction.as");
