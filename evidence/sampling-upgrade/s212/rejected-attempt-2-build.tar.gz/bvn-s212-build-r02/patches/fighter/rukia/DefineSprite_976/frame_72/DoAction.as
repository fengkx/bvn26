jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_72/DoAction.as");
