kcplayed = 2;
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1182/DoAction.as");
