jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_72/DoAction.as");
