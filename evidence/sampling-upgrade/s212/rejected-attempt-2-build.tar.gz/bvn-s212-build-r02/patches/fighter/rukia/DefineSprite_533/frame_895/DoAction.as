动作 = 2;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_895/DoAction.as");
