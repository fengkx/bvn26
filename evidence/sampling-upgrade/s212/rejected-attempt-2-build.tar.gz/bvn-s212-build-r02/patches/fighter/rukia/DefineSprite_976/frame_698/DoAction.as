动作 = 3;
bs = 1;
ql -= 100;
jump = 1;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_698/DoAction.as");
