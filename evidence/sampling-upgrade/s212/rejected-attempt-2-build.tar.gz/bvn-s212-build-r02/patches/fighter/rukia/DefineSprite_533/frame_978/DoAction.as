_root._y += 2;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_978/DoAction.as");
