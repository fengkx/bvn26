动作 = 1;
ql += 5;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_407/DoAction.as");
