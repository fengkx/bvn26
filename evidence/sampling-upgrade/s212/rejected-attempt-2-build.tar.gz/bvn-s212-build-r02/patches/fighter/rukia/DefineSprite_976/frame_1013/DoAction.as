动作 = 2;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1013/DoAction.as");
