stop();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1056/DoAction.as");
