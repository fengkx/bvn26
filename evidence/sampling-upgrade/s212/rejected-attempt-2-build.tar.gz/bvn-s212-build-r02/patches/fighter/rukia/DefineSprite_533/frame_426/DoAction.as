动作 = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_426/DoAction.as");
