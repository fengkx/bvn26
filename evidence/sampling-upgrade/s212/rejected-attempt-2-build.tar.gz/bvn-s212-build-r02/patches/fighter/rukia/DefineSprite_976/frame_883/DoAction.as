_root.cbsw(pn);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_883/DoAction.as");
