onBeHit(true);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_932/DoAction.as");
