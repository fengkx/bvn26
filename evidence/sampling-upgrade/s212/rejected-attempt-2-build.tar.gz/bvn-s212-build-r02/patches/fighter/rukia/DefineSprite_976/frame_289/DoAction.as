gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_289/DoAction.as");
