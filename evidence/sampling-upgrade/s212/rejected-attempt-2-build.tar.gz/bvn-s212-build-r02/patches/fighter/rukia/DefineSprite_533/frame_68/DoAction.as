gotoAndStop("落");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_68/DoAction.as");
