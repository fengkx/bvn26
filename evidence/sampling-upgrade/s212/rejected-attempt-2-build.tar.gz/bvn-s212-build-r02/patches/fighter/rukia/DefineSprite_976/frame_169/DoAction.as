khit = 1;
jump = 1;
动作 = 1;
ql += 5;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_169/DoAction.as");
