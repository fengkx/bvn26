wankai_end();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1171/DoAction.as");
