_root.bsw(pn);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_654/DoAction.as");
