动作 = 1;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_248/DoAction.as");
