动作 = 3;
bs = 1;
ql -= 100;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_547/DoAction.as");
