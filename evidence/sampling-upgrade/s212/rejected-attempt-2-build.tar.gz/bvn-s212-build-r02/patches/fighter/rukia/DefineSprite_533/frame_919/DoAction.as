onBeHit();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_919/DoAction.as");
