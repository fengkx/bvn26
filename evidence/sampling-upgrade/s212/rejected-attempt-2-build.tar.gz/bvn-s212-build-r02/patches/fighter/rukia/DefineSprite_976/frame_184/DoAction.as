_root.shine(16711680);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_184/DoAction.as");
