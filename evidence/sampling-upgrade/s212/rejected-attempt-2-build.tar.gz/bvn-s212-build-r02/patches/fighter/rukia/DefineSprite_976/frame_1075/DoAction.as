if(sw == true)
{
   stop();
}

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1075/DoAction.as");
