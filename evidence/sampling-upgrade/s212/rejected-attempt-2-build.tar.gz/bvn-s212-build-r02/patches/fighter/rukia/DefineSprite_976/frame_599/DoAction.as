gotoAndStop("落");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_599/DoAction.as");
