动作 = 1;
ql += 5;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_465/DoAction.as");
