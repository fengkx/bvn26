hited = 0;
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_931/DoAction.as");
