kcplayed = 3;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1124/DoAction.as");
