_root._y = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1097/DoAction.as");
