jump = 0;
jumped = 1;
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_928/DoAction.as");
