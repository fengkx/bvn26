_root.shine();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_892/DoAction.as");
