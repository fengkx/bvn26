_root.cbsd(pn);
_root.showFace(pn,"露其亚2");

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_732/DoAction.as");
