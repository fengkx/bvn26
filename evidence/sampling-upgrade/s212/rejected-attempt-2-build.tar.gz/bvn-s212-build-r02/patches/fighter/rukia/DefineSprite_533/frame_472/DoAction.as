_root.shine(14731512);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_472/DoAction.as");
