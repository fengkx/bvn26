khit = 1;
jump = 1;
动作 = 1;
ql += 5;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_175/DoAction.as");
