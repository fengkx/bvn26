_root.touchFloorEffect(_parent);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_943/DoAction.as");
