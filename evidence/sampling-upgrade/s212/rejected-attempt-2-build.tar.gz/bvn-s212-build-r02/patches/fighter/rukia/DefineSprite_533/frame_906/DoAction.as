play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_906/DoAction.as");
