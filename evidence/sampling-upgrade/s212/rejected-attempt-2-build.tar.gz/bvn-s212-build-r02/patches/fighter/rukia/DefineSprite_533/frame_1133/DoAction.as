stop();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_1133/DoAction.as");
