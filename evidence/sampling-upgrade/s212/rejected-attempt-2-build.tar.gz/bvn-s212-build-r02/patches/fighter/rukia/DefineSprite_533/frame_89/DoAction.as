jump = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_89/DoAction.as");
