动作 = 1;
ql += 10;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_454/DoAction.as");
