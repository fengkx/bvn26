jump = 0;

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_56/DoAction.as");
