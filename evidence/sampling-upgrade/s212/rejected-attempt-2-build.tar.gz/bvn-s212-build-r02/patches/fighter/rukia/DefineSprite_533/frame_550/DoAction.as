_root.bsd(pn);
_root.showFace(pn,"露其亚1");

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_550/DoAction.as");
