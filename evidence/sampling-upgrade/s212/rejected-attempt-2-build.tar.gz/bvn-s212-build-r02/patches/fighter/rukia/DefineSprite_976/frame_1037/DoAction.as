onBeHit();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1037/DoAction.as");
