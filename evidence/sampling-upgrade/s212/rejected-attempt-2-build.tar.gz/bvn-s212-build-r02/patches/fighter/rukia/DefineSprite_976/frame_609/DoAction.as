_root.bsd(pn);
_root.showFace(pn,"露其亚2");

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_609/DoAction.as");
