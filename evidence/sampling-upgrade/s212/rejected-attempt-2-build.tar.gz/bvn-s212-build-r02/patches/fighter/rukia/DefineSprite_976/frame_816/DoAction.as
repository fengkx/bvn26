_root.cbsd(pn);
_root.showFace(pn,"露其亚2");

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_816/DoAction.as");
