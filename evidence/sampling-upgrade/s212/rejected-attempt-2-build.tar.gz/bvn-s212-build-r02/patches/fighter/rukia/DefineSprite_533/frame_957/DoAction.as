if(sw == true)
{
   stop();
}

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_957/DoAction.as");
