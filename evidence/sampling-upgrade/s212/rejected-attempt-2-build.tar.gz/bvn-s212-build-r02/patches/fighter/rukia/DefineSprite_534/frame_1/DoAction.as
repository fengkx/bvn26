stop();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_534/frame_1/DoAction.as");
