onBeHit(true);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_1050/DoAction.as");
