_root.shine(7393520);

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_976/frame_891/DoAction.as");
