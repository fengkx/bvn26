stop();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_3/frame_1/DoAction.as");
