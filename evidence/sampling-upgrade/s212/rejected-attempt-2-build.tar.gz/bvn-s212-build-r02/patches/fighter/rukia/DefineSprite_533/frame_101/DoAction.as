gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/rukia.swf#DefineSprite_533/frame_101/DoAction.as");
