_root.game["p" + pn].mc.ql -= 20;

_root.aiGeoStamp(this, "game/fighter/fz/kon.swf#frame_75/DoAction.as");
