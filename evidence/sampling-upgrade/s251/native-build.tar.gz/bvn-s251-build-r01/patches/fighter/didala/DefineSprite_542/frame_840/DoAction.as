_root.shine();
_root.shine(303095);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_840/DoAction.as");
