_root.shunbuxg(_parent);

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_21/DoAction.as");
