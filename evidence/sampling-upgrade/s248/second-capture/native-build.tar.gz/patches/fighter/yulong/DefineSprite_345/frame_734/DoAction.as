_parent._x = _root.game["p" + pn]._x;
_parent._y = _root.game["p" + pn]._y;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_734/DoAction.as");
