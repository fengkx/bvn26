_root.shine(11382189);

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_288/DoAction.as");
