if(_parent._xscale > 0)
{
   shijie._x = _root.game["p" + pn]._x - _parent._x;
}
else
{
   shijie._x = _parent._x - _root.game["p" + pn]._x;
}
shijie._name = "zh2atm";

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_466/DoAction.as");
