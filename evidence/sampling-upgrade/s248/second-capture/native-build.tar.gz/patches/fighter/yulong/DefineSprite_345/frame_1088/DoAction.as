if(sw == true)
{
   stop();
}

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1088/DoAction.as");
