khit = 1;
jump = 1;
动作 = 1;
ql += 5;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_154/DoAction.as");
