stop();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_3/frame_1/DoAction.as");
