_root._y = 0;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1114/DoAction.as");
