_root.cbsw(pn);

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_747/DoAction.as");
