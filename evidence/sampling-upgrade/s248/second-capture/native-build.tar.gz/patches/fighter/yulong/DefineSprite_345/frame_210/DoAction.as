动作 = 1;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_210/DoAction.as");
