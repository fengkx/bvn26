动作 = 1;
k1n++;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_184/DoAction.as");
