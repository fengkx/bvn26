gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_148/DoAction.as");
