this._name = "abcd";

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_74/frame_5/DoAction.as");
