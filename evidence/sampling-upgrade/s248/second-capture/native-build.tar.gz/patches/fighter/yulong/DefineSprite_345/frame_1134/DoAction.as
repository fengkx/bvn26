kcplayed = 1;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1134/DoAction.as");
