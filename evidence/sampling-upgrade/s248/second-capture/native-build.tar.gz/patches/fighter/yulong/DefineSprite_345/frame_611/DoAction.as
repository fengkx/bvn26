_root.bsw(pn);

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_611/DoAction.as");
