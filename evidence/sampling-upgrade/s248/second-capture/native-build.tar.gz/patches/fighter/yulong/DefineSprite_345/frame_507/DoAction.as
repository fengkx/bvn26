_root.bsd(pn);
_root.showFace(pn,"石田1");

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_507/DoAction.as");
