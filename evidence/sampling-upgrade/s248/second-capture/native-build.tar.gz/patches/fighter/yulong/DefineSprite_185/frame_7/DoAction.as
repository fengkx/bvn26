_name = "zh21atm";

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_185/frame_7/DoAction.as");
