动作 = 2;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1026/DoAction.as");
