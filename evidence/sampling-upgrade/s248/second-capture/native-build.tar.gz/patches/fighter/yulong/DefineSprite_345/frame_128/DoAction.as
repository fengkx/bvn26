khit = 1;
动作 = 1;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_128/DoAction.as");
