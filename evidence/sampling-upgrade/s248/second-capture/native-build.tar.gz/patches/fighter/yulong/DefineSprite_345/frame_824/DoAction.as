_root.bsd(pn);
_root.showFace(pn,"石田3");

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_824/DoAction.as");
