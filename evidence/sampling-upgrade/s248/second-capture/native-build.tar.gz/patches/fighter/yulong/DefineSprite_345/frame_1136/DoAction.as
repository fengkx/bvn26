kcplayed = 3;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1136/DoAction.as");
