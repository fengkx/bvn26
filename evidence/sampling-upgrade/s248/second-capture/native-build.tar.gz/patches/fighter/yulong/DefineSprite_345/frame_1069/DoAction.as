stop();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1069/DoAction.as");
