hited = 0;
play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1062/DoAction.as");
