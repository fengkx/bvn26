动作 = 1;
ql += 10;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_351/DoAction.as");
