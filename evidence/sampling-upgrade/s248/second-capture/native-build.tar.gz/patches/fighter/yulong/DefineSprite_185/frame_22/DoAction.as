stop();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_185/frame_22/DoAction.as");
