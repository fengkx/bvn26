play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1037/DoAction.as");
