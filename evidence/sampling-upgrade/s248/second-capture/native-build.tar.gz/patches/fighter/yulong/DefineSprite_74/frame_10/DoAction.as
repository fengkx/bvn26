stop();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_74/frame_10/DoAction.as");
