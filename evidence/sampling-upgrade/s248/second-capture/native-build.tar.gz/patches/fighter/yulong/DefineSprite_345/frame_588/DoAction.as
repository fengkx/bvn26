动作 = 3;
bs = 1;
ql -= 100;
jump = 1;
_parent._x = _root.game["p" + pn]._x;
_parent._y = _root.game["p" + pn]._y - 150;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_588/DoAction.as");
