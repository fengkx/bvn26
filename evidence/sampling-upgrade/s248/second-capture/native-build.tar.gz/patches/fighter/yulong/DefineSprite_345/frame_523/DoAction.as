if(_parent._xscale > 0)
{
   bs1._x = _root.game["p" + pn]._x - _parent._x;
}
else
{
   bs1._x = _parent._x - _root.game["p" + pn]._x;
}
bs1._y = _root.game["p" + pn]._y - _parent._y;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_523/DoAction.as");
