_root.cbsd(pn);
_root.showFace(pn,"石田2");

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_681/DoAction.as");
