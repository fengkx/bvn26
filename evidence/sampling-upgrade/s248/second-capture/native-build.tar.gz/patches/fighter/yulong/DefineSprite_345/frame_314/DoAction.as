动作 = 1;
ql += 5;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_314/DoAction.as");
