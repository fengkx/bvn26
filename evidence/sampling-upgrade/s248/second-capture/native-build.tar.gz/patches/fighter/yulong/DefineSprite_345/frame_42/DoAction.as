jump = 1;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_42/DoAction.as");
