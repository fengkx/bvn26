gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1033/DoAction.as");
