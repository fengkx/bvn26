jump = 0;
jumped = 1;
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1059/DoAction.as");
