onBeHit();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1050/DoAction.as");
