stop();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_104/frame_10/DoAction.as");
