khit = 0;
jump = 0;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_116/DoAction.as");
