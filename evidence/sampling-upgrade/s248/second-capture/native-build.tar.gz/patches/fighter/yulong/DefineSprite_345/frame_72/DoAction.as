jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_72/DoAction.as");
