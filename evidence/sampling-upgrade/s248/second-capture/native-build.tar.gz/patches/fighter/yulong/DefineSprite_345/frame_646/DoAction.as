gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_646/DoAction.as");
