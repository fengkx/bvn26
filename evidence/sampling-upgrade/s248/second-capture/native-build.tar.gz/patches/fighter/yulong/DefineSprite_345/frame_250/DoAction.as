_parent._x -= _parent._xscale;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_250/DoAction.as");
