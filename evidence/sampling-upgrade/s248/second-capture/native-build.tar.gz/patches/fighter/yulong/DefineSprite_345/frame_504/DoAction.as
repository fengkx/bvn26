动作 = 3;
bs = 1;
ql -= 100;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_504/DoAction.as");
