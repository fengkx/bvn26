_root.touchFloorEffect(_parent);

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1074/DoAction.as");
