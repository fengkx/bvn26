_root.shine();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_603/DoAction.as");
