stop();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1055/DoAction.as");
