onBeHit(true);

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_1063/DoAction.as");
