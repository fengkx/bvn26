hits = 0;

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_2/DoAction.as");
