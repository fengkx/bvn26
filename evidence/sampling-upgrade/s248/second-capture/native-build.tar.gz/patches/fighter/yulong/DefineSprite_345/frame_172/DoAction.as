gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_172/DoAction.as");
