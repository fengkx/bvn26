gotoAndStop("落");
play();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_345/frame_68/DoAction.as");
