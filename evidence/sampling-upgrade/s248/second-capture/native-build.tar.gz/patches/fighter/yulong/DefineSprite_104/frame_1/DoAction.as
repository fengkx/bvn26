stop();

_root.aiGeoStamp(this, "game/fighter/yulong.swf#DefineSprite_104/frame_1/DoAction.as");
