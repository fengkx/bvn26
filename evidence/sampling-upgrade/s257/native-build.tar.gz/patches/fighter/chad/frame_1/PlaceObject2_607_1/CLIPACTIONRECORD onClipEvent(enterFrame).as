onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4c900d2e2e4150f5e4a73469da6ac846e075fadf54a614b7331e41adc8a7065d," + escape(String(this)) + "," + _currentframe);

   on_enterframe();
}
