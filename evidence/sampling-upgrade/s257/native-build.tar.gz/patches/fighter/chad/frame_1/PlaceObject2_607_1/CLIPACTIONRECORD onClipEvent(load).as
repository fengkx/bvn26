onClipEvent(load){
_root.aiEvent("clipaction_entry", "f618397f1894baeee40a88b6f938d6c2b67a7214071872464275818404dfd4a9," + escape(String(this)) + "," + _currentframe);

   var kcplayed = 0;
   var movspeed = 0;
   var fall = false;
   var touch = true;
   var sw = false;
   var jump = 0;
   var khit = 0;
   var fan = 0;
   var jumped = 1;
   var bisha = 0;
   var played = 0;
   var jhp = 0;
   var ql = 0;
   var speed = 0;
   var kis = _root.aiKeyDown;
   var spd = 6;
   var jumpPower = 15;
}
