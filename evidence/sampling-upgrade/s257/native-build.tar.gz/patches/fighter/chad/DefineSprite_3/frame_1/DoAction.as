_root.aiEvent("doaction_entry", "b735603f43f0bb3d2e59b75adc6fa662abc592829de448d5696287b877207d50," + escape(String(this)) + "," + _currentframe);
stop();
