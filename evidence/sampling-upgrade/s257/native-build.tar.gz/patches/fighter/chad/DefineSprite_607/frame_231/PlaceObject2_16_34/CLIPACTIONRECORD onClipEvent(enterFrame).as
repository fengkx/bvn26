onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c3b746d4d14d2ca55192e63bf61db102ffa1387df38e208f202290298b0cdee8," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      if(rush())
      {
         _parent.gotoAndPlay("瞬步");
      }
      if(skill1())
      {
         _parent.gotoAndPlay("砍技1");
      }
      if(magichit2())
      {
         _parent.gotoAndPlay("招2");
      }
   }
}
