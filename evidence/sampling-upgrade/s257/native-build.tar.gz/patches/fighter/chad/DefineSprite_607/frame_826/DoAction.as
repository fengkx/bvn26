_root.aiEvent("doaction_entry", "4031be98341074b49dacb3b7e659b514658f7cee9b317a6a516eeef5c104d43c," + escape(String(this)) + "," + _currentframe);
hited = 0;
play();
