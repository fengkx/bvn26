onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "f5ddfcbd42a855443885328f8524fb16ad7fc6905276d78c41d7b31a37dc8f1b," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 2.3;
      }
      else
      {
         _parent._parent._x += _parent.speed * 2.3;
      }
   }
}
