_root.aiEvent("doaction_entry", "09bd1586b3a350496381f6c936e12cd9c53f895c42267ffd083b9888f9ee6018," + escape(String(this)) + "," + _currentframe);
onDefence();
