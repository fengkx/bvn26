onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "fe99f7e7129f9c183967ad233a49ecea278ff55d886974e87fb440cbf42d7f72," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit())
      {
         _parent.gotoAndPlay("砍1");
      }
   }
}
