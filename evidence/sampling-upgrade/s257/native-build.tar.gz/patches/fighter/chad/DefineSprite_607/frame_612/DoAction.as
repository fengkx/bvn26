_root.aiEvent("doaction_entry", "611a5dd25641c5e3efffbc157a400e686d5047b42255a1d4d34e57e152f6d363," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
