_root.aiEvent("doaction_entry", "59f82c7b8128a920be5b315c2f1b5dd818f3957f38d6a09f3839ed62260ce083," + escape(String(this)) + "," + _currentframe);
动作 = 2;
