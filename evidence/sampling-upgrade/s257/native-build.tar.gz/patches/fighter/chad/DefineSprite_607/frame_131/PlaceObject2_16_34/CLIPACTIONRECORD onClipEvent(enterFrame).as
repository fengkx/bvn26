onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4a8d56c92be195ac82ae2e620a653f6fd998d4c9c9323419e987b7fdddd60da6," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent._parent._xscale > 0)
         {
            _parent._parent._x -= 1;
         }
         else
         {
            _parent._parent._x += 1;
         }
      }
      _parent._parent._y -= 1;
   }
}
