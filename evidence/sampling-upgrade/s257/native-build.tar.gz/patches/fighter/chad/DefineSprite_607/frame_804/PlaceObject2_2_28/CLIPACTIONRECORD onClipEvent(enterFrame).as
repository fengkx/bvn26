onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d666dc659c39e10e96e5f981dff0ca443d00b21c3edeea334c2d0d9ecfde49a4," + escape(String(this)) + "," + _currentframe);

   fangyu();
}
