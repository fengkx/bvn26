_root.aiEvent("doaction_entry", "c69a095e20f9a5a3add01479d472ac9af68c4c573cfa6410760d1937f1bfda44," + escape(String(this)) + "," + _currentframe);
动作 = 1;
