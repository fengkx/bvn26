_root.aiEvent("doaction_entry", "cd6255f1764ba2439a531b337b714d9802c9e2c4aa008a40c597d5e2793c49ed," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
