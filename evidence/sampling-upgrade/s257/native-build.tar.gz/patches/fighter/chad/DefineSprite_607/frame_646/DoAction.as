_root.aiEvent("doaction_entry", "b3ce6b5fc72891195acdac4f09dfccafce677447a00488982eb9d971036ea5f8," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"茶渡");
