_root.aiEvent("doaction_entry", "2bceef469ccd0dbff2ff7fee11baec769508a4ff53f24297b69aa8443097b287," + escape(String(this)) + "," + _currentframe);
动作 = 0;
