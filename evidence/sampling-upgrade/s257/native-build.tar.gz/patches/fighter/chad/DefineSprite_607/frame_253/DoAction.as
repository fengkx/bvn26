_root.aiEvent("doaction_entry", "78e19049f1889029497adc71b5a5c3837219f86a400693cf66deab11280486a0," + escape(String(this)) + "," + _currentframe);
动作 = 0;
