_root.aiEvent("doaction_entry", "f26e722a5c42e332430eef877ecc9e157572dec1812c72b82f09c94df0cfd13c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
