_root.aiEvent("doaction_entry", "c9ba66d9c83959fe1dd72e7bf61e832e4fd99d4bd724ac3946539f586072aaa2," + escape(String(this)) + "," + _currentframe);
_root.shine();
