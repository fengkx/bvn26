_root.aiEvent("doaction_entry", "cad1a92ba391b4a2cdc1124dd40dda4621a2cc812d944fa8c6f1c14d80a09752," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
