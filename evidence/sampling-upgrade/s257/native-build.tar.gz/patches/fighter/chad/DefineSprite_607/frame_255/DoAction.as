_root.aiEvent("doaction_entry", "a04f81eae46b4904119cedf1a4b5d71f8c655a8bbd003474ae0f574585bf24c3," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
