_root.aiEvent("doaction_entry", "692b1671bce272ac5e59947f73623d0dcdb264b4f68da2c26fb61b3dba8f6044," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
