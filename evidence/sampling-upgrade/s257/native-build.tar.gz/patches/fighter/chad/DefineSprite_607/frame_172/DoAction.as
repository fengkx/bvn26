_root.aiEvent("doaction_entry", "b87e896682255272f543d7bb93a22cd4b1f662b8f70a9a0db62e8882e30c4517," + escape(String(this)) + "," + _currentframe);
动作 = 0;
