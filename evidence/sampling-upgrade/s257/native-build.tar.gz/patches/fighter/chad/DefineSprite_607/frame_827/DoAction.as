_root.aiEvent("doaction_entry", "5a35dbeccfa05ec54af4ff92ffb093a9f04bbdf575185e7763fb93a7b122e974," + escape(String(this)) + "," + _currentframe);
onBeHit(true);
