_root.aiEvent("doaction_entry", "9fe7bd1acbebbc5b81c847fa0451d10aad2b5c732e154a93c5a1b1e814f3a337," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
