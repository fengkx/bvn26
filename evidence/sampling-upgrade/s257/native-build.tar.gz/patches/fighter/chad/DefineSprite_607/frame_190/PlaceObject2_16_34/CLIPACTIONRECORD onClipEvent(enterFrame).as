onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "a65abf2a55df91155cd88c77c0edfeefdc553166cfd27eb551980164eda09345," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍2");
      }
   }
}
