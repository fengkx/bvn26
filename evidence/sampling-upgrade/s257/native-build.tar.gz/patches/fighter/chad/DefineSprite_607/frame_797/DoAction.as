_root.aiEvent("doaction_entry", "10c6e8f3fc22b0baf25db0c75851f9203d5243ffa5e125e8798792bf403ff971," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
