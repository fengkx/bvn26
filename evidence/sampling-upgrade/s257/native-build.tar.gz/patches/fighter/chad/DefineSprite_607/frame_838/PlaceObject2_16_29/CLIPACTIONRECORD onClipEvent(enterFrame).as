onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "af4a09576ed25daed8c2cfeecea63197b284ebfffa133f772452f0e099549718," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false and _parent.sw == false)
      {
         if(_parent.kis(_parent.冲))
         {
            _parent.gotoAndPlay("起身");
         }
      }
   }
}
