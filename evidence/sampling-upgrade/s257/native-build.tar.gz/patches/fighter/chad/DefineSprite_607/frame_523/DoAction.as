_root.aiEvent("doaction_entry", "93be62fe20e1d0a6d64d675b4ac019f4495c8b290a8014c6f8f276645fb48251," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
