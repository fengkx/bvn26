_root.aiEvent("doaction_entry", "8f9ae01059f1de3e6e5af75e3bad055d3e936426851abf89ce5edf48a37f5174," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
