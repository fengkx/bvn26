_root.aiEvent("doaction_entry", "221d6b440fecff453cbb59d84113b6380bae842902b6c63d7ebb4577de1f4bc1," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
