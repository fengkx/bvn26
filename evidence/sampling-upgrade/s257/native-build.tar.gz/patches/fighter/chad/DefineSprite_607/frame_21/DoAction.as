_root.aiEvent("doaction_entry", "4eeb044ef31457346256be8996c24eeda5d572dc1ce991c36052f175c198027e," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
