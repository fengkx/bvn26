onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "48849d6bae5fa46cd9778688ee8c37d7eeb2b2bbac326935559d8ea0e6a0f7aa," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent.kis(_parent.斩))
         {
            _parent.gotoAndPlay("砍1");
         }
      }
   }
}
