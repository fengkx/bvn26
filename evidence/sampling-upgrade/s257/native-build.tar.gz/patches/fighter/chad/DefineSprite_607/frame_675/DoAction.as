_root.aiEvent("doaction_entry", "8df5a849d4620360b5e3b8d4732b0dbb20ae0387a42149a0d6008450dd3d5f58," + escape(String(this)) + "," + _currentframe);
_root.shine(1818876);
_root.shine();
