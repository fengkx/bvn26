onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d52d40070e94c1bb7be7adc32adf8158e5a0ed305d83944c264dc2e7bbf4df51," + escape(String(this)) + "," + _currentframe);

   beida();
}
