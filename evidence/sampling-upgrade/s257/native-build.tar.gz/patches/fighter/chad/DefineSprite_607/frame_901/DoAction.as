_root.aiEvent("doaction_entry", "81e9dc9e3f21b25d3c5564a0d728934907411d1e7295c5cf993749ccc3359ece," + escape(String(this)) + "," + _currentframe);
kcplayed = 3;
