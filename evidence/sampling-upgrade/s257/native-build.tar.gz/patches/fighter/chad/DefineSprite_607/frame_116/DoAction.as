_root.aiEvent("doaction_entry", "09fdabf640e510afb2c71838029b340a971e5543ad4dc29aac7cd4d57d8838f8," + escape(String(this)) + "," + _currentframe);
khit = 0;
jump = 0;
