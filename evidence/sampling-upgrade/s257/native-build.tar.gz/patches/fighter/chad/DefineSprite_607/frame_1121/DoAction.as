_root.aiEvent("doaction_entry", "92ea9cc0d0dcad99c06f53df032134e38d47d4f56bac1dc728b27c5251b4d731," + escape(String(this)) + "," + _currentframe);
stop();
