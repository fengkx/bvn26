onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "3ca7f1f6d1abf69bf558c89380f6d2e83ade48da9f7cc7c66eb88961dcfe584f," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(airMagichit())
      {
         _parent.gotoAndPlay("跳招");
      }
   }
}
