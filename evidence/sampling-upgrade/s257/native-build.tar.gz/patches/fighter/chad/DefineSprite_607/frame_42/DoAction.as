_root.aiEvent("doaction_entry", "ab0514c7546c22fb183db05b2704a8aa1cfadd573dc3f280b9fd06e0b177c61b," + escape(String(this)) + "," + _currentframe);
jump = 1;
