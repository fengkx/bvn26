onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "5350e413e1175dc621ee4781a12418ee2b8a6b45ab2f71296be73297e3b26b72," + escape(String(this)) + "," + _currentframe);

   onJumping(2);
}
