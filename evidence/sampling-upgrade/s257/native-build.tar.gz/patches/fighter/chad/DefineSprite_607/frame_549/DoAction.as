_root.aiEvent("doaction_entry", "ddfc4ebfa04ae02b23242d9a6cacc37df3c2b057d92793dc36fdc835b3e2e9b6," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
