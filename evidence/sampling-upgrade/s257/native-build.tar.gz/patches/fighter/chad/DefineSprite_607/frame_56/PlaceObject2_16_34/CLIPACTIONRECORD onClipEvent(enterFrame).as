onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "1386299faf1b2ab9a29046d66cd6b4e317f18148ec51b16981f5ef95496a6551," + escape(String(this)) + "," + _currentframe);

   onJumping(3);
}
