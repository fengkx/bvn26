_root.aiEvent("doaction_entry", "e4300af012f987724413b9720a99cc76de3a8ce07b7d50d86f1fb7e398d02d03," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
