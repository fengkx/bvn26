onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "176b0429416173019d4dfbccfd13fbce3a03d095d79715c2955c570e66d91cfb," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      moveX(15);
   }
}
