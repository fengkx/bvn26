_root.aiEvent("doaction_entry", "0a5a27251e63fd6a1f396e2ba88d6957b8eef8f77754ef9eb12c1221fced1065," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
