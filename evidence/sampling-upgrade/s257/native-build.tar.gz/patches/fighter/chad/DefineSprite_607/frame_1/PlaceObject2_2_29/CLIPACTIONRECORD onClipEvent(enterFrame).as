onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "3ce56b6fff054ae5cc45802c0e968a2ab0958901c8b23e1da401e828a0c6df91," + escape(String(this)) + "," + _currentframe);

   beida();
}
