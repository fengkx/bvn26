onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "5681c9407e4b2fce52f4206147c2b48d58295ca8822e9182c597129d96f914e3," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      moveX(10);
   }
}
