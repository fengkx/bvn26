_root.aiEvent("doaction_entry", "d70c9fc3ff66723ca85500effef76160f8dcb127a7499a22573dce5d1e2b8231," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
