onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "55537343464e0b49e6a3cd7e028569dd5fc8ac07fd1ce64d8e9b221aa7423a01," + escape(String(this)) + "," + _currentframe);

   beida();
}
