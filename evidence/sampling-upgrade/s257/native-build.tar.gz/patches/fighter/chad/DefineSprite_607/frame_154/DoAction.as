_root.aiEvent("doaction_entry", "f25e8f4bd8e4004af397ba91cc7e80ec2ade9021da2375aac8335cc0ffb6b69e," + escape(String(this)) + "," + _currentframe);
khit = 1;
jump = 1;
动作 = 1;
ql += 5;
