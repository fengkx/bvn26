onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0df5a695a1166772145166fa32c538317d7816413d855fb71473443eceb33c7b," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 1;
      }
      else
      {
         _parent._parent._x += _parent.speed * 1;
      }
   }
}
