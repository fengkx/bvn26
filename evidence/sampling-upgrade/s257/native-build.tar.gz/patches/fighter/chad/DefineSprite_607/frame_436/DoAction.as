_root.aiEvent("doaction_entry", "d4719aaf821d4afe157a89dffb0713b0462f029ea25bea568c449af0852aa731," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
