_root.aiEvent("doaction_entry", "a6167bfd86261be9f7239133de43bd2b3bac8f0714c6f36006fa7db86d86bb22," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
