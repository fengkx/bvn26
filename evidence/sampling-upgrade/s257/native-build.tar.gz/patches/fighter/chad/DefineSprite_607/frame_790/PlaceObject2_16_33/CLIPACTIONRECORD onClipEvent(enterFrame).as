onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c04ea340780afb0782683d69b200cbab277c6fceb527ee431f378a04318f8b75," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(defence())
      {
         _parent.gotoAndPlay("防御2");
      }
      if(skill1())
      {
         _parent.gotoAndPlay("砍技1");
      }
      if(magichit2())
      {
         _parent.gotoAndPlay("招2");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      doDropDown();
   }
}
