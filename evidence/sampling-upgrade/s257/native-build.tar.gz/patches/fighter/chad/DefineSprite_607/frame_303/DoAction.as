_root.aiEvent("doaction_entry", "6651da6c36dfdd4bd9f0ede3022b1a6f90ed0a3da665d305cfbda0a86709178a," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 15;
