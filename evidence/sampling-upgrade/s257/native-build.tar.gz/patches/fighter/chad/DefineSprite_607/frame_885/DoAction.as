_root.aiEvent("doaction_entry", "63f3aba1dfb5ccb7b12b551967861ab30aeacb6b00a033d7398233bcd8ef9946," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
