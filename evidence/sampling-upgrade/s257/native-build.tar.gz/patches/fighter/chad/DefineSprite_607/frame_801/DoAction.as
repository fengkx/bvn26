_root.aiEvent("doaction_entry", "6d1fbaaa9b61fd0b2170473ebd2376c206070334bf45547b82e42e476447ab28," + escape(String(this)) + "," + _currentframe);
play();
