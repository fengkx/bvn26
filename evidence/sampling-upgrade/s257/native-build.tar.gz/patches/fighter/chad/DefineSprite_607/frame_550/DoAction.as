_root.aiEvent("doaction_entry", "4cc18e32e34eeca932659b53b2445a70ea79af9ad27fa7330e74a9bcea7be3b9," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"茶渡");
