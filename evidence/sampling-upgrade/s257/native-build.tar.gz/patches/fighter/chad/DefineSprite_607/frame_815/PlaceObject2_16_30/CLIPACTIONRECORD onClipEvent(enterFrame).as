onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "3cf5ffe85dc327843c491982d52157a456520e2dfc17a7161bcdbcf69f6c0934," + escape(String(this)) + "," + _currentframe);

   _parent.beidax();
}
