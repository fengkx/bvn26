_root.aiEvent("doaction_entry", "644955bb1b8be0b326568470be362323f652bdeb461ef70d255532b95c3967b4," + escape(String(this)) + "," + _currentframe);
动作 = 0;
