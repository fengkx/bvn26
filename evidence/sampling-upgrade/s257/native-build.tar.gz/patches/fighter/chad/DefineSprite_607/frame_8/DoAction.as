_root.aiEvent("doaction_entry", "6fd8fea92e8ee06ab3a9ccb2a0922abba5d797d107a8058f4843fbc3e56549d7," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
