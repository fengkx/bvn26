_root.aiEvent("doaction_entry", "6db7272dd2e1d57835f2f5f379552b76a718bae298b8d08bd1f0d3d47862906a," + escape(String(this)) + "," + _currentframe);
kcplayed = 1;
