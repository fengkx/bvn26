_root.aiEvent("doaction_entry", "aa35fb2c39fe91bc536c6c0599bcccb20be73c3da939ac9db4b2fabb4d948339," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
