_root.aiEvent("doaction_entry", "510350e7e3d39f2820b3ba120f4cddd74c99e97fd49c3e2419d77889435d0c60," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
