_root.aiEvent("doaction_entry", "cc4b42a077c5134791780d4c0e27782bcafe6720c16c33c333dd414b97ccf04c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
