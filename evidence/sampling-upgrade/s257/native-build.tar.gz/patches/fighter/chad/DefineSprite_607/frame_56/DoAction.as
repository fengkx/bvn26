_root.aiEvent("doaction_entry", "4c6c54424aa331eb022bd8a0acf6460784a4447e57a28a5c8f71e57e7ebc03b6," + escape(String(this)) + "," + _currentframe);
jump = 0;
