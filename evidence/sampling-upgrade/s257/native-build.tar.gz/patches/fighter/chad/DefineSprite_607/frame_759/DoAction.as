_root.aiEvent("doaction_entry", "003722f44d50c773119fd7446081fd6870041a3cedad0e21e78f502087d28c8a," + escape(String(this)) + "," + _currentframe);
doZhaoHuan();
