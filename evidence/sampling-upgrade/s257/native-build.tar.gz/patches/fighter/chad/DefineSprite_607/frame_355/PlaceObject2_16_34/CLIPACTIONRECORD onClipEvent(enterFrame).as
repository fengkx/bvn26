onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "a59a9b6355baf0445a1cdca02945834e48476281d7923667c097081d37f6b3e7," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(bishaUP())
      {
         _parent.gotoAndPlay("上必杀");
      }
      if(skill2())
      {
         _parent.gotoAndPlay("砍技2");
      }
   }
}
