_root.aiEvent("doaction_entry", "fd083ff5720db140b55a9cd90dfd3a60386faaa8d91c7b8038bc18b5e7d4f527," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
