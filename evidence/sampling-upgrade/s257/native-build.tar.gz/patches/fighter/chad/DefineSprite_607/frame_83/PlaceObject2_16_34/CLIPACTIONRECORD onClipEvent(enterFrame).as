onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "caa582ea284345d4a2fba9b56fd07fb4a4ac8a94a86d311279a1eb2ff6eb27f4," + escape(String(this)) + "," + _currentframe);

   onJumping(5);
}
