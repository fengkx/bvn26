_root.aiEvent("doaction_entry", "af7530bfa6a7f85bcd346d1c67d813c3fc11020bfc011b882d735c625f737038," + escape(String(this)) + "," + _currentframe);
kcplayed = 2;
gotoAndStop("站立");
play();
