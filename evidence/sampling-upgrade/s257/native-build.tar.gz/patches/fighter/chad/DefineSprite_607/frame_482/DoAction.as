_root.aiEvent("doaction_entry", "f461d7146b5d5f57b3f64d39028b2d3a105760378e7a2db937a3be59d128ffe0," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"茶渡");
