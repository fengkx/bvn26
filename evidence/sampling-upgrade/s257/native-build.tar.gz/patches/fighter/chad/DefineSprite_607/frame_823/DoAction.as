_root.aiEvent("doaction_entry", "4798efbe55af559bcf582d4aaef94df559d5f4ce8d62ad70ddc5746016d2ae7b," + escape(String(this)) + "," + _currentframe);
jump = 0;
jumped = 1;
clearInterval(tdint);
gotoAndStop("站立");
play();
