_root.aiEvent("doaction_entry", "612740b29f236a7538ae376b02f783670d4ea34faeaae17ca1921bd35664543e," + escape(String(this)) + "," + _currentframe);
gotoAndStop("超必杀0");
play();
