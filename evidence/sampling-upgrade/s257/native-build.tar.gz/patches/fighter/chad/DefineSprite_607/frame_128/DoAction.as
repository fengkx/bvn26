_root.aiEvent("doaction_entry", "447ae24aef88740acc84d7a8cd8e3cd21ace991a56bc92ca88e5cff1de0b6aa9," + escape(String(this)) + "," + _currentframe);
khit = 1;
jump = 1;
动作 = 1;
ql += 5;
