_root.aiEvent("doaction_entry", "a9b426db233c441b07c0659e0ee8e04cf7ee3b91ecafd65ef5594061c19a5f6d," + escape(String(this)) + "," + _currentframe);
动作 = 0;
