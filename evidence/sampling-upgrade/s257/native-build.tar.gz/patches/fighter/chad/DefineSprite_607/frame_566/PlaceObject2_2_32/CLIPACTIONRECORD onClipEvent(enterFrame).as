onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "6bce91c29544531365f073f3919dd1ac002fb0bee1eedff88822a83d848ea719," + escape(String(this)) + "," + _currentframe);

   beida();
}
