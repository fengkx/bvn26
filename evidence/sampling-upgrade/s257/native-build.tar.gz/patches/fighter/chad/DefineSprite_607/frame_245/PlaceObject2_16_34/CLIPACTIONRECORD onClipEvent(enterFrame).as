onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "da71ecb5947d7c56ccc14f1e706565a8b5a3433c8f05ca3bccb8d92389ce9d21," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(_parent.kj10atm.hitTest(_root.game["p" + _parent.pn].mc.bdmn))
      {
         _parent.gotoAndPlay("砍技11");
      }
      else
      {
         moveX(_parent.speed * 3);
      }
   }
}
