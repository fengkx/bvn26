_root.aiEvent("doaction_entry", "10b2d8eb54f083bf23df870a877042a762cf895e6818a1864340cf361211b32c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
