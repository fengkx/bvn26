_root.aiEvent("doaction_entry", "36c744cbcab1a414298d2879029c8b44e8c473e59bc02d947ad6a873914583a9," + escape(String(this)) + "," + _currentframe);
_root.shine(1818876);
_root.shine();
