onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "810529561c0578b6941bd5a1300465e2262ffa9d6cffdd1c2eeb3bd0fd1af4ae," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 2;
      }
      else
      {
         _parent._parent._x += _parent.speed * 2;
      }
      if(bishaUP())
      {
         _parent.gotoAndPlay("上必杀");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      if(bisha())
      {
         _parent.gotoAndPlay("必杀");
      }
   }
}
