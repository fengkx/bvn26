_root.aiEvent("doaction_entry", "334f534f290815a9c27242e0230979f9fcd466c61e77822499d1f649025a57e1," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
