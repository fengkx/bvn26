onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "6ddfa2adb804e312f1350cc482e43a9334630555e9e386b786d6efb96a0f20cb," + escape(String(this)) + "," + _currentframe);

   fangyu();
}
