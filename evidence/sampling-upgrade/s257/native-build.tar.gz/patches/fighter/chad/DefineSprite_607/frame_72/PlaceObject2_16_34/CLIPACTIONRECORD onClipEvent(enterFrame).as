onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "6c96b5a78c2cc6ee026c368cdc61cce67a3da93914d3e9dc7e3627fa5f603630," + escape(String(this)) + "," + _currentframe);

   onJumping(4);
}
