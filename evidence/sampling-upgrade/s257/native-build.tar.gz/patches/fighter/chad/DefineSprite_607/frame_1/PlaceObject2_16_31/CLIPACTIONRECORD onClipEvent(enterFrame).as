onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "bb6a13a3379e88408fcfa67c7d99591e3ecd7eff29f7d21f08ac0349fe9f9e5b," + escape(String(this)) + "," + _currentframe);

_root.aiEvent("callsite", "bb6a13a3379e88408fcfa67c7d99591e3ecd7eff29f7d21f08ac0349fe9f9e5b,predicate_before," + escape(String(this)));
   if(gameRunning())
   {
_root.aiEvent("callsite", "bb6a13a3379e88408fcfa67c7d99591e3ecd7eff29f7d21f08ac0349fe9f9e5b,true," + escape(String(this)));
_root.aiEvent("callsite", "bb6a13a3379e88408fcfa67c7d99591e3ecd7eff29f7d21f08ac0349fe9f9e5b,call_before," + escape(String(this)));
_global.bvnChadObserve("caller_before", this);
      doAllAction();
_global.bvnChadObserve("caller_after", this);
_root.aiEvent("callsite", "bb6a13a3379e88408fcfa67c7d99591e3ecd7eff29f7d21f08ac0349fe9f9e5b,call_after," + escape(String(this)));
   }
   else
   {
_root.aiEvent("callsite", "bb6a13a3379e88408fcfa67c7d99591e3ecd7eff29f7d21f08ac0349fe9f9e5b,false," + escape(String(this)));
   }
_root.aiEvent("callsite", "bb6a13a3379e88408fcfa67c7d99591e3ecd7eff29f7d21f08ac0349fe9f9e5b,end," + escape(String(this)));
}
