_root.aiEvent("doaction_entry", "6fa1d986b78df3cfa86370cf41f0666aa47adf5f45fbeb95c8af461ff5cf3b99," + escape(String(this)) + "," + _currentframe);
hits = 0;
