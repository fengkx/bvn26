_root.aiEvent("doaction_entry", "c8fcd900f7f6aa99f3e4f07fac1d5408006893824b62a58158ea2222d8f8478d," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
