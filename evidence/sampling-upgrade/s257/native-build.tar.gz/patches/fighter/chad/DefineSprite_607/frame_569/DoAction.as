_root.aiEvent("doaction_entry", "c042c451af7de2be1ca10e3e1b76127582489baf1c285ed23b9ebe9523de7ded," + escape(String(this)) + "," + _currentframe);
_root.shine(1818876);
