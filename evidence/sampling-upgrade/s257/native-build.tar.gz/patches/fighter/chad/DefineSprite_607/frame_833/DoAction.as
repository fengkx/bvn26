_root.aiEvent("doaction_entry", "213919eff2cc49f72a5fbe90005ed23abcdde964198f81a90cbab9d418a54f1a," + escape(String(this)) + "," + _currentframe);
stop();
