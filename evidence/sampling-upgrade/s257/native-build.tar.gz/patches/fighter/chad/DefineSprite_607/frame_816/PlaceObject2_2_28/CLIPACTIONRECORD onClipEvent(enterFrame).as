onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "cf87af77707a74523a4e33f908d5ef9decdaf6770f62c655c9fc93d070e48799," + escape(String(this)) + "," + _currentframe);

   beida();
}
