onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "e622d45af5034ac7e9776fa60d6387fa48bbafbb708bf58de6a01a17d33356ba," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x += _parent.speed * 0.8;
      }
      else
      {
         _parent._parent._x -= _parent.speed * 0.8;
      }
   }
}
