_root.aiEvent("doaction_entry", "732e25bddf296cb904914745f224578b7e87e475ff46413eb6b355442b1543ab," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
