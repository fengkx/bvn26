_root.aiEvent("doaction_entry", "ba16ad32e6d138fcaa6139572d02e71166d8b6bd62c7ebbd8cfd98b3ce5ff4d4," + escape(String(this)) + "," + _currentframe);
动作 = 1;
