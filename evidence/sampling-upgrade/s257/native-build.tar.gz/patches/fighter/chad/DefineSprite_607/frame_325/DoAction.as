_root.aiEvent("doaction_entry", "2227bfb2f2e95491517e18a8fc976fc1bf5d62ad6614050597ce827fd5c28568," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
