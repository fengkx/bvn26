_root.aiEvent("doaction_entry", "6903ca07fe2c1c21ebc1d48b682cd1d1561ce599a0c5d4d9d2e04e059eb668df," + escape(String(this)) + "," + _currentframe);
动作 = 0;
