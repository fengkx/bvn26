_root.aiEvent("doaction_entry", "74b42830356acf4ebcbc9b46ed21133db66b3af4e0e1857bffc2989cca5bd0ca," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 15;
