_root.aiEvent("doaction_entry", "1ab25c347c4abd96603991ab042f408141e4bff82c940a5b22eb3cf1eede3c98," + escape(String(this)) + "," + _currentframe);
动作 = 0;
