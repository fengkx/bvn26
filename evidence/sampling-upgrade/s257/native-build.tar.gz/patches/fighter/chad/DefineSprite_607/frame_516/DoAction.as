_root.aiEvent("doaction_entry", "4f3edb5a611a35728a7e47eacb645e920904bae08f97b158eb641336c54cf96f," + escape(String(this)) + "," + _currentframe);
动作 = 0;
