_root.aiEvent("doaction_entry", "bf41a47cc4582b04d0694751d2271802b3a9cdfefdf48a058586aefe17bc5756," + escape(String(this)) + "," + _currentframe);
jump = 1;
jumped = 0;
