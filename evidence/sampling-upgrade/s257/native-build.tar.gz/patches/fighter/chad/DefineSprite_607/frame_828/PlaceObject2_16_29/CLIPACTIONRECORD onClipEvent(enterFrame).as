onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "44b84fb241ec7f96d6afbd796b0eb6a9e605342ddfc2fe5b45b41971b99d0e1f," + escape(String(this)) + "," + _currentframe);

   _parent.beidax(true);
}
