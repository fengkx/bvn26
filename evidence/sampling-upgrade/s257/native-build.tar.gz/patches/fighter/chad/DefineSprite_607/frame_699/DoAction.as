_root.aiEvent("doaction_entry", "89087f39a5f27604f68d2d33401a85740df57dbc714d7cbce423bf3167fe94cd," + escape(String(this)) + "," + _currentframe);
动作 = 0;
