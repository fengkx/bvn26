_root.aiEvent("doaction_entry", "8b8e2feffb959b4e9ff94e46548e2c25a8bb8271ae2cc45b86f6ea7f0764594a," + escape(String(this)) + "," + _currentframe);
动作 = 1;
