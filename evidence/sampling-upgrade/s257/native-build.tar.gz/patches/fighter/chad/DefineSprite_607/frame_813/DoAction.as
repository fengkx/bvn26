_root.aiEvent("doaction_entry", "e6014bde1ff267f25ebfcb40183ba429852ac509acebac28c6c214007cfb0c24," + escape(String(this)) + "," + _currentframe);
play();
