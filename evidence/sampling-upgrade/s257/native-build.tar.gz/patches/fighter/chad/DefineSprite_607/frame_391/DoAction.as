_root.aiEvent("doaction_entry", "33e68ae570493c85a1100653fd41a05a4e76eff46967978ab1880633d1683c42," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
jump = 1;
