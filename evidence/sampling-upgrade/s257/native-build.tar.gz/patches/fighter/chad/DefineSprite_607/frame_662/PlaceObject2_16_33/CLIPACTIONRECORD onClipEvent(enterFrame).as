onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c4e41ec76154d2d5554193c47cb9b6e7fe2b15d525ca72c0374893fe0b187d9e," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(_parent.zh20atm.hitTest(_root.game["p" + _parent.pn].mc.bdmn))
      {
         _parent.gotoAndPlay("超必杀1");
      }
      else
      {
         moveX(_parent.speed * 4);
      }
   }
}
