_root.aiEvent("doaction_entry", "84fdab01b98ccc1a2410d4b91d57fb836c3f2e7abe68950de27d248743616597," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
