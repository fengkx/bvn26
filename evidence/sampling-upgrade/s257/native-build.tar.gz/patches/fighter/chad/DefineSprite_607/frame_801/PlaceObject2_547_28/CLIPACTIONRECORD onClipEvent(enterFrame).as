onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c6f765017ac47374d6926465333c02bc0bcb99a8a7bfd0603664ed37fdf4433d," + escape(String(this)) + "," + _currentframe);

   bdfyxg();
}
