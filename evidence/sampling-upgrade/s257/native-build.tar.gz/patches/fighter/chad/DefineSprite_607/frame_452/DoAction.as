_root.aiEvent("doaction_entry", "59e9d01f3af6febb582a0d39463c0eadefe187f7c89a243dd1798f23b0ba36fa," + escape(String(this)) + "," + _currentframe);
动作 = 0;
