_root.aiEvent("doaction_entry", "01d5108ea5fa2e1cc308aac819aa6e1b97712b1009fd86b25a3c956b62765f30," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
