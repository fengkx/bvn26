_root.aiEvent("doaction_entry", "44b2538b360f636e9709745167344416c3b43b9af80cd7a1ddb35f0f9bbbb62b," + escape(String(this)) + "," + _currentframe);
if(sw == true)
{
   stop();
}
