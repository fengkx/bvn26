onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "206b89ac277239a172fe39610393ec351f2ed2363facbe899281abf66fb4b805," + escape(String(this)) + "," + _currentframe);

   fangyux();
}
