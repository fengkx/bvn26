onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "7f54abbab471798b1c5afd4c0d9df980d67e5638b40a30fec1a28380d365e168," + escape(String(this)) + "," + _currentframe);

   onJumping(1);
}
