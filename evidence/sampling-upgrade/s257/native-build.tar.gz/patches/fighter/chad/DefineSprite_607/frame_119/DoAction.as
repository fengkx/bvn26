_root.aiEvent("doaction_entry", "3199c1bd315e9aebc6ea40ba53def3a5c846fdedd54bdea9939247295e11a4a7," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
