onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "62953b8e9795ee8ac32c882d02504a47962365fa836946d06d0ccbaad6c6e51a," + escape(String(this)) + "," + _currentframe);

   if(_root.game["p" + _parent.pn].mc.sw == false)
   {
      if(defence())
      {
         _parent.gotoAndPlay("防御2");
      }
   }
}
