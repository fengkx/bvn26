_root.aiEvent("doaction_entry", "9b2221aaf34f483dad6c99b96a4bd2b35641577590d75b054282fc8ab931ec43," + escape(String(this)) + "," + _currentframe);
onBeHit();
