_root.aiEvent("doaction_entry", "372a3d41843f4fc5cf90cff1a5ff14cb1807c42be402d044b135f3efa4e5da8e," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
jump = 1;
