onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d4b09f9372910314b43aaaf88e98dfaa920a06b12079a86546f916294a93b092," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      moveX(8);
      moveY(15);
   }
}
