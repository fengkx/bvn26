_root.aiEvent("doaction_entry", "f3f0a24258241878de67047f19e460a4013a6bc3505d35698f46e5eb4919bb11," + escape(String(this)) + "," + _currentframe);
动作 = 0;
