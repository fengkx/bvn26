_root.aiEvent("doaction_entry", "28bbd65af72b01a0d04ce3d7bfa76c8cbafcc1edd2aabfccece2f64447a6f921," + escape(String(this)) + "," + _currentframe);
