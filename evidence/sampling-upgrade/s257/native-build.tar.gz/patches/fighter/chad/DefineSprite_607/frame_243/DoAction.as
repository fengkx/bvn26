_root.aiEvent("doaction_entry", "2ef8bf79b2bae28f8798a60e70ced64f76c8c7a134cbc8e6adc982fdcb47bf6e," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
