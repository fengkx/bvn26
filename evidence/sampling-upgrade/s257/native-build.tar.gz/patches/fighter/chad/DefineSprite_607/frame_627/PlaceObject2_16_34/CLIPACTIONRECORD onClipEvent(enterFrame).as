onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "a038ad31344d9e5c31e8595ae4bff424f1fa4cf12fabefc2c7aad15b550a3dd3," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent._parent._xscale < 0)
         {
            _parent._parent._x -= _parent.speed;
         }
         else
         {
            _parent._parent._x += _parent.speed;
         }
         _parent._parent._y -= _parent.speed;
      }
   }
}
