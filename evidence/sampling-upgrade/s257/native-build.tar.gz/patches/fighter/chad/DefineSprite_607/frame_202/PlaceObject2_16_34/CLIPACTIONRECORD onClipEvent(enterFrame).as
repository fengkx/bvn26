onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d9095d60efa0f0ba735dc58ec61d77699464f93b6bad707b39ae4bc5fa926a60," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 1.5;
      }
      else
      {
         _parent._parent._x += _parent.speed * 1.5;
      }
   }
}
