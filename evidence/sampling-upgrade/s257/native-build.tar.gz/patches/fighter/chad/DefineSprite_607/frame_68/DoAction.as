_root.aiEvent("doaction_entry", "0324b0936230a9a3751989a46115932289b48c0be549e60a31bcc251952c63fd," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
