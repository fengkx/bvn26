_root.aiEvent("doaction_entry", "45b44f2c33c58e03e4a70ed9a12117bbd3156f162f9e0de1fc8bb6f1ea1d5d40," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
