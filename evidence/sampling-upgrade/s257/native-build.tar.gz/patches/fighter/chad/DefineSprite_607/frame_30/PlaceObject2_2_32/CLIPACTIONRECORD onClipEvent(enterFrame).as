onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "ef4502143ec56c2080f2358ae96e13c4ad25d998a1c519ddcb33e85c7ec6e06a," + escape(String(this)) + "," + _currentframe);

   beida();
}
