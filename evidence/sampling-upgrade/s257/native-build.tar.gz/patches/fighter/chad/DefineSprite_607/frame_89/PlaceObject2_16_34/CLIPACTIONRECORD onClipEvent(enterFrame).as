onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "1a7d4335728db2fe3ac4257fbb23abf99ff4db469af1c60bd2f8ded5016737ef," + escape(String(this)) + "," + _currentframe);

   onJumping(6);
}
