_root.aiEvent("doaction_entry", "01beb4bbd11c041999ec758043fe943722cbced7ead1b6e3b4dee6598ebed110," + escape(String(this)) + "," + _currentframe);
stop();
