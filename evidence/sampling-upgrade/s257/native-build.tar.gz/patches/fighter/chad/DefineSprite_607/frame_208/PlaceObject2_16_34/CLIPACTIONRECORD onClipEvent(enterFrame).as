onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0b246a8b51af24d3df12980f2f0d266aab69de0d7148e77b168019214f3a6210," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(skill2())
      {
         _parent.gotoAndPlay("砍技2");
      }
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍3");
      }
      if(bisha())
      {
         _parent.gotoAndPlay("必杀");
      }
   }
}
