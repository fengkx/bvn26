_root.aiEvent("doaction_entry", "14d999489604a5a09c41d5ed5d946e72636df0afc18ace001cc1c9039c2b2cea," + escape(String(this)) + "," + _currentframe);
jump = 0;
