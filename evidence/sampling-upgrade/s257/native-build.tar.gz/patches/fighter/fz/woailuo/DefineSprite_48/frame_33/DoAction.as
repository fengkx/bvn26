_root.aiEvent("doaction_entry", "4cd240a9e78a2748b83af816c59b73016a43b6297478857395cd60415855bea3," + escape(String(this)) + "," + _currentframe);
stop();
