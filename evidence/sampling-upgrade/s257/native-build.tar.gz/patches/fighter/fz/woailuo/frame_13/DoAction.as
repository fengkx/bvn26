_root.aiEvent("doaction_entry", "209c25769ef3776f41ed8a43f5f1b4c722cc71f3f81868121bf4dfc8dcffd5de," + escape(String(this)) + "," + _currentframe);
动作 = 1;
