_root.aiEvent("doaction_entry", "21b4d5f18c44aabdcaa84f9a11816133843ceb2cb14dd1d2e05fdd01351878ec," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn,"XG_fzbs",true);
