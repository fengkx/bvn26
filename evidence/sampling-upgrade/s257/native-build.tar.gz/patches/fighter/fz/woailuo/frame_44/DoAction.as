_root.aiEvent("doaction_entry", "675e84a5d36d2c1d17abb1d676997c50153d3798e47be02f15cd70dc8c493649," + escape(String(this)) + "," + _currentframe);
_root.shine(9461816);
