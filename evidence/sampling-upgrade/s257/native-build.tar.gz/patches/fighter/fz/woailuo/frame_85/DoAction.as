_root.aiEvent("doaction_entry", "4eb448fda5ae0f08acb316eed0af6149aa713045fe4efeff0ca504b8f6b98edd," + escape(String(this)) + "," + _currentframe);
_root.fzccXg(this);
