_root.aiEvent("doaction_entry", "b039b5ed7af1e629f688d9b073ef2e5aef3c0f3faa6a37dca83d7f09e6870236," + escape(String(this)) + "," + _currentframe);
play();
_root.fzccXg(this);
