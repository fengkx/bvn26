onClipEvent(load){
_root.aiEvent("clipaction_entry", "cc1f8f012bc65dd72f93515fefd9fd6234385df25459107abcc4406ffe116e31," + escape(String(this)) + "," + _currentframe);

   if(_parent._xscale < 0)
   {
      _X = - (_root.game["p" + _parent.pn]._x - _parent._x);
   }
   else
   {
      _X = _root.game["p" + _parent.pn]._x - _parent._x;
   }
}
