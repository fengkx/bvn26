_root.aiEvent("doaction_entry", "eeacc7bdb76147c8afa53df2191522334a78a6ba84819861333af7bce5f1d8b4," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
