_root.aiEvent("doaction_entry", "565df7945d8ba5a2f60b2c2683c456ba57a0b063d9113d0370db27b5f4e100e2," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
