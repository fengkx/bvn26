_root.aiEvent("doaction_entry", "c465a75ec50c84669fdf9f693ec2bab26f8702710a5d357771b26f0c440338c7," + escape(String(this)) + "," + _currentframe);
动作 = 1;
