_root.aiEvent("doaction_entry", "79d1c6a341e918f524568255e2f4fff519cb86ff57df174c9cf6445e8ee0665d," + escape(String(this)) + "," + _currentframe);
_root.game["p" + pn].mc.ql -= 20;
