_root.aiEvent("doaction_entry", "9148a02ebb1feebd4b266cd0f5d49cfd818095ef6283d04d6bb0735b5da68e8f," + escape(String(this)) + "," + _currentframe);
动作 = 0;
