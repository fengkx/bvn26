_root.aiEvent("doaction_entry", "ecbed0a22d136b472b1a4d6e8de446f9b345c03db2ed958fdd46a06f5a576f8a," + escape(String(this)) + "," + _currentframe);
_root.game["p" + pn].mc.ql -= 20;
