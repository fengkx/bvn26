_root.aiEvent("doaction_entry", "0fb45593fb85fd372d0efbe01def3ea177df05d9c79bf085401bdc5869ade9c3," + escape(String(this)) + "," + _currentframe);
_root.game["p" + pn].mc.ql -= 20;
