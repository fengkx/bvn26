_root.aiEvent("doaction_entry", "f07470ea636e5ad22d464b0014a4b15246af42e735f1c08110acaaf3ad6cec39," + escape(String(this)) + "," + _currentframe);
_root.game["p" + pn].mc.ql -= 20;
