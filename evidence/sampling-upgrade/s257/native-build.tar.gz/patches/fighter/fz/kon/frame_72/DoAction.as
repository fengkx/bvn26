_root.aiEvent("doaction_entry", "48531ecfe4511df072995fe43a347f8cdde26cb933d3f94a12839ebba2c9039b," + escape(String(this)) + "," + _currentframe);
_root.game["p" + pn].mc.ql -= 20;
