_root.aiEvent("doaction_entry", "8e9fb8314114020ac2352388f8e21f7a48d66c717bf40bb03f8cb43d3b57cae1," + escape(String(this)) + "," + _currentframe);
_root.game["p" + pn].mc.ql -= 20;
