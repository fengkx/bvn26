_root.aiEvent("doaction_entry", "31c46c3ab7599acf8cb2125d3ed3044530379474a595a4de5432ff78a4015d32," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn,"XG_fzbs",true);
