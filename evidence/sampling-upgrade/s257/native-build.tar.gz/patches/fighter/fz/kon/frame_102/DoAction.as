_root.aiEvent("doaction_entry", "4287fad7c9696271c8f15ca93dd9653bdc85daebda67d1c547016ac3cb38e012," + escape(String(this)) + "," + _currentframe);
_root.fzccXg(this);
