_root.aiEvent("doaction_entry", "7e238326f8942179206fc820cf39d33758682ff5e215cfc1654b793cd3b985e2," + escape(String(this)) + "," + _currentframe);
play();
_root.fzccXg(this);
