_root.aiEvent("doaction_entry", "705ff48047579442130c43714fc0dab6385551325cc8563f0f372cb6007e9ea4," + escape(String(this)) + "," + _currentframe);
stop();
