_root.aiEvent("doaction_entry", "d205805618d7da98a8852621c70b4ce9b71a45e398d4de206c1e40d59874b6e2," + escape(String(this)) + "," + _currentframe);
动作 = 0;
