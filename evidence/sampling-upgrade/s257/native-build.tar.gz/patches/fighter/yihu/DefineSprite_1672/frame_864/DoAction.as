_root.aiEvent("doaction_entry", "af268cbf5bba5039bdeaf73353c368642f0595f614d459e35494c372d8a52a56," + escape(String(this)) + "," + _currentframe);
doZhaoHuan();
