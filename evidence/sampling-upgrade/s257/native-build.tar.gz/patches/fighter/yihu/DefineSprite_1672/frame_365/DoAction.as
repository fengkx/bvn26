_root.aiEvent("doaction_entry", "1407da75980217b572104166d89105869063c9036e0f8dcd635bae6322664406," + escape(String(this)) + "," + _currentframe);
动作 = 0;
