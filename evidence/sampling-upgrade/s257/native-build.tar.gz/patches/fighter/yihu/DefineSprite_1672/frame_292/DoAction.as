_root.aiEvent("doaction_entry", "657d26b3d6c87834ea39d9196eee0c95974226debaa822131dd6a87fb949b718," + escape(String(this)) + "," + _currentframe);
动作 = 1;
