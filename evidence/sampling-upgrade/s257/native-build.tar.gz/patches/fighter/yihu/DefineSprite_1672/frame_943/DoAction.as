_root.aiEvent("doaction_entry", "054214597d8b098f6c6cbdefed678e368efceb2c6ef6f1c6ccfd499d4258faf0," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
