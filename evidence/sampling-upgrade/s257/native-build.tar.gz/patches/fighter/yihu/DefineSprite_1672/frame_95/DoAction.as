_root.aiEvent("doaction_entry", "2c02a18f11c7bc96d37acff4586b20904b2d230c8e560520d5a60388b91b3bb0," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
