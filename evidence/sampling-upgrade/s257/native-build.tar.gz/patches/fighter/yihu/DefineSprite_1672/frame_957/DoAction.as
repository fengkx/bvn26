_root.aiEvent("doaction_entry", "cebf805b4a03b51517e93c55f94188576737b9d74d2747abc410812a08fd47f1," + escape(String(this)) + "," + _currentframe);
if(sw == true)
{
   stop();
}
