onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c363291cd5303dedb17b822786d7d98a901bc638526807b5a2a9349182b2c54f," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += Math.round(_parent.speed);
      }
      else
      {
         _parent._parent._x -= Math.round(_parent.speed);
      }
   }
}
