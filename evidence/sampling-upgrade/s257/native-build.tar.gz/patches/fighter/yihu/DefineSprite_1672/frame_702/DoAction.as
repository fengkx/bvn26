_root.aiEvent("doaction_entry", "20065444934e9565cee71348bc2a68bf22ea7ff58429a3fa0f6e71e81fd86f09," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
