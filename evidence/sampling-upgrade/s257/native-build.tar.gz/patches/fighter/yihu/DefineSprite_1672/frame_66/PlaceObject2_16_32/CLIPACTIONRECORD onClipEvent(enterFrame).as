onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "49b3109f3a68fc4efc08d1c2279b5ab20ea117877f7fe8bb7cd263529da21aeb," + escape(String(this)) + "," + _currentframe);

   onJumping(4);
}
