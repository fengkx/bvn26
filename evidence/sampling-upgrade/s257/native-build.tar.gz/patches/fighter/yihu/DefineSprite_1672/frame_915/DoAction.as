_root.aiEvent("doaction_entry", "db8f09a99e705ceb2458f2dcb658baea54ee4993d1e0ff12dc194b5508c8c837," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
