_root.aiEvent("doaction_entry", "ad18f066757f265edd70d291b51a101cdf273216e98469e6ea09dc56927afb25," + escape(String(this)) + "," + _currentframe);
khit = 0;
jump = 0;
