onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "2922fdc22fa14a78b8d64e3f48c02c7e3bbd402895c4eed09f147446e26a68f3," + escape(String(this)) + "," + _currentframe);

   _parent.fangyux();
}
