onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "efb7a097ca7d0f855d6fbc469406b6856bfe271c041105925d412ab62a9418cc," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      doAllAction();
   }
}
