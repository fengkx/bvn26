_root.aiEvent("doaction_entry", "1297115f70f93d29276de74fb74dabba5cf5da4e83cea697e5c53f210e0a8f65," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
