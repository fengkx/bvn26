onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "cbcea7fb715a48a748ec4fd2d877072a51068beadaa369a46c8e982a6c2ff7a4," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(bisha())
      {
         _parent.gotoAndPlay("必杀");
      }
      if(magichit3())
      {
         _parent.gotoAndPlay("招3");
      }
   }
}
