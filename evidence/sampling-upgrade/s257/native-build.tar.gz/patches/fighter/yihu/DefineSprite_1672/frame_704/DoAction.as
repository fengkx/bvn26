_root.aiEvent("doaction_entry", "273272cd0349dba0876b6df5b53fca578e04197ca234787eb85e1686e07aa586," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"虚护3");
