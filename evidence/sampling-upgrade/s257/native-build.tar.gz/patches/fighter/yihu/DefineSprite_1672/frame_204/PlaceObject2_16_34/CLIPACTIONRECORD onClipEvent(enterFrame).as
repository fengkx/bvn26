onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "37da48e8c43a75ae891c0a9e6b80eae8e21cb93bde698675b63f14141fbdec9b," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += Math.round(_parent.speed / 2);
      }
      else
      {
         _parent._parent._x -= Math.round(_parent.speed / 2);
      }
   }
}
