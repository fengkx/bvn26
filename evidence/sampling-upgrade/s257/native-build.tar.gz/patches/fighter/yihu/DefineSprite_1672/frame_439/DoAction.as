_root.aiEvent("doaction_entry", "67bd8b1c57b43e22f573ddd69164e75f9f308973597b2ffd6351b6880bc5977d," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
jump = 1;
jumped = 0;
