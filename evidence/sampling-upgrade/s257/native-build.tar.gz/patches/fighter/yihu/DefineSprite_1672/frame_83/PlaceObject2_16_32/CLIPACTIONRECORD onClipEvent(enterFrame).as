onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4ffe3174404faf79e37d83e90d1e5b7e9cff483f22b76c979476e95b4e0fe185," + escape(String(this)) + "," + _currentframe);

   onJumping(6);
}
