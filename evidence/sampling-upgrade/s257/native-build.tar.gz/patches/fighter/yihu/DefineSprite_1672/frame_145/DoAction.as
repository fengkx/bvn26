_root.aiEvent("doaction_entry", "45bb891a5adac65aaaab86a24ae3b72ac5fbf0011b943f01663271c50fe6938b," + escape(String(this)) + "," + _currentframe);
gotoAndPlay(146);
