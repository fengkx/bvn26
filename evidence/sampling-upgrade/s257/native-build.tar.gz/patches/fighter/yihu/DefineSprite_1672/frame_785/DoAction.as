_root.aiEvent("doaction_entry", "65eb54c37e290793f2b3a09e6b23ca73d7782f6ecaca480e6e6d692b15bbf10b," + escape(String(this)) + "," + _currentframe);
_root.shine(16727100);
