onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "08f54b07b4bfea1c3ab0845a07bedf77d26cbd2c51d905634d799fa93b9b24f5," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x += _parent.speed * 0.8;
      }
      else
      {
         _parent._parent._x -= _parent.speed * 0.8;
      }
   }
}
