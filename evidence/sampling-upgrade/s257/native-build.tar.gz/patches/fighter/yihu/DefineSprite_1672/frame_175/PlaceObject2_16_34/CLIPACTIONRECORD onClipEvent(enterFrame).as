onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0af8ea302d5d77c6cdae5d03aa700d4ac2e5849346b80d4c5557a8308ee7e3b4," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍2");
      }
   }
}
