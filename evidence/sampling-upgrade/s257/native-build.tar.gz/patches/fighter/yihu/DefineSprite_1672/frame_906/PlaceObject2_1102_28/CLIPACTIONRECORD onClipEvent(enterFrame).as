onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "71f3ffb4dc7ce6807f55fef5d7ca04c4521e7e673cab6575f0da2dbea6637025," + escape(String(this)) + "," + _currentframe);

   bdfyxg();
}
