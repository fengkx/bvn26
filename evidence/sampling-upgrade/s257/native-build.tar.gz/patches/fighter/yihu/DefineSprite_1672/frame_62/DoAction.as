_root.aiEvent("doaction_entry", "f6ad40bee64512753bc20f75b0d5a6664e328ceee6ef7f77b9eb2f7cc4e358df," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
