_root.aiEvent("doaction_entry", "ed99c83da1fdc553107d064a9fffb1bd1a3e722a754fdb5d69163624b4a03574," + escape(String(this)) + "," + _currentframe);
_root.shine(0);
