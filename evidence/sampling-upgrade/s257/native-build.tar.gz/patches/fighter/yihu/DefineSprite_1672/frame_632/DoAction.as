_root.aiEvent("doaction_entry", "e70af2c140eaff095217b3580fd6918dddda340a9734a4cce64dea785fda6fa7," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
jump = 1;
