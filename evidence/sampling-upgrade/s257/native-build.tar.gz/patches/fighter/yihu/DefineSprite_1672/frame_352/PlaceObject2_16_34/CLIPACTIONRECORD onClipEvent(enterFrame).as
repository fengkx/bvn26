onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "2cfb671d12e6d0ce5738192260a2db84b9cb06b70512bee5838190a8c9610800," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += _parent.speed * 3;
      }
      else
      {
         _parent._parent._x -= _parent.speed * 3;
      }
      _parent._parent._y -= _parent.speed * 3;
   }
}
