_root.aiEvent("doaction_entry", "c24d8f566f0f1855a5d35d4c6ce52109b31fc9dae5cc6cb50e1bf8c419b3bcfe," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
