_root.aiEvent("doaction_entry", "dd8723c9ff6c2a45e8392a2ba87994687cc7818b9f330e1ba4b1ee82cae8397b," + escape(String(this)) + "," + _currentframe);
khit = 1;
jump = 0;
jumped = 0;
动作 = 1;
ql += 5;
