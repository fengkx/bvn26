onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d496a75fcd58dfc555fc750bf5dc74f0d70b23936b6602c840dd03c7b3c9ffdc," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(bishaUP())
      {
         _parent.gotoAndPlay("上必杀");
      }
      if(skill1())
      {
         _parent.gotoAndPlay("砍技1");
      }
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍4");
      }
   }
}
