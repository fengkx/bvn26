_root.aiEvent("doaction_entry", "170611ab7a3751dbd9ae4864802081a218050633a00c4061758e65c99467f17c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
