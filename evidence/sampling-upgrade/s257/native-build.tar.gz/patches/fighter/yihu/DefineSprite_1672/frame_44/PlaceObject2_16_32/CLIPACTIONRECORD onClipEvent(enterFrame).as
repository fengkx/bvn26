onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "ec96fb66d048affc72d0b018746712a3aa40b6baa8b496298093575368ff34bd," + escape(String(this)) + "," + _currentframe);

   onJumping(2);
}
