_root.aiEvent("doaction_entry", "00b36bb3a808207d17c471c1d71a7cb056610ba3312bcada2c4341c339453d8d," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
