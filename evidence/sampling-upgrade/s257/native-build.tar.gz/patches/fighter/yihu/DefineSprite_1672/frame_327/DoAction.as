_root.aiEvent("doaction_entry", "fe29a2d93f9181f997f67da8ce76a3efb4a65e3f49862be0a3eb5cd9c968d9b4," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
