_root.aiEvent("doaction_entry", "f7e1a199cbf9386035b71ff61010f46c224b6e20932246f37d4e602dbb819608," + escape(String(this)) + "," + _currentframe);
wankai_end();
