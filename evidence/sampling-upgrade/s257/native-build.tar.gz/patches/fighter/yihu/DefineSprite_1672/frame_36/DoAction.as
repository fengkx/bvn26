_root.aiEvent("doaction_entry", "c133d63c03ebb76cdd85bc6dc3992aafa356c0e74d0bf0e1292f61ae79ec7cc5," + escape(String(this)) + "," + _currentframe);
jump = 1;
