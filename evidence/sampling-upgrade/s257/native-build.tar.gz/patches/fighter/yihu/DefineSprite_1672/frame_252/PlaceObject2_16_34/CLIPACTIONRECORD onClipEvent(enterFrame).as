onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "bddb0e45c3a32ff1e262e96d58aba874d134ccd5ba48bc7a2c7099a217b739f2," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍5");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      if(magichit2())
      {
         _parent.gotoAndPlay("招2");
      }
   }
}
