_root.aiEvent("doaction_entry", "1a63af436bc25921d54bd3eb1f70787c545ac7a49ae1ad787982117f9386bce6," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
