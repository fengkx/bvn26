_root.aiEvent("doaction_entry", "e6339768eea4e225a9bee1627142a16b644a4ca43ce63f23f7ea70345fedeeb4," + escape(String(this)) + "," + _currentframe);
play();
