_root.aiEvent("doaction_entry", "88818579a0e1782a84ff1db91f379ca8a2874de4c0210c6efdf028f7f55896ab," + escape(String(this)) + "," + _currentframe);
stop();
