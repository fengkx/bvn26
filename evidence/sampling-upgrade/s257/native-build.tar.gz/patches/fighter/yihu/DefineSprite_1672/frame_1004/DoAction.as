_root.aiEvent("doaction_entry", "7ed274cd165e7b217eeb7b4d112a5c11788cd7235cd0989b7615f7196131f98c," + escape(String(this)) + "," + _currentframe);
kcplayed = 1;
