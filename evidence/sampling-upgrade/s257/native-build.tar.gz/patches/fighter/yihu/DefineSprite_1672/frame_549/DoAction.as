_root.aiEvent("doaction_entry", "faaf89a5f3bb209f7fa62bbaf76aaa47ed04a8d52bf875256af8214ac91f90fd," + escape(String(this)) + "," + _currentframe);
ql += 5;
jump = 1;
jumped = 0;
_root.shunbuxg(_parent);
