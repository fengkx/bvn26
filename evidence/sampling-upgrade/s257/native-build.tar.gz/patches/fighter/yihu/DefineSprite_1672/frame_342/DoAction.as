_root.aiEvent("doaction_entry", "9679af36b04e193494e91354bec6c303900a6d337d019a639fd939406b731028," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
