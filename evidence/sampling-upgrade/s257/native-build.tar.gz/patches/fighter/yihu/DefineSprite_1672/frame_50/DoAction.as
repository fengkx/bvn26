_root.aiEvent("doaction_entry", "65b58807f40d9987d6b9c681f45300bd14d83734a768d206c6acea1dec8bf59d," + escape(String(this)) + "," + _currentframe);
jump = 0;
