_root.aiEvent("doaction_entry", "89ba24afb3a971383d47fe2c8c3446728446c3b2bc6d959000f0723e62cf30ec," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
