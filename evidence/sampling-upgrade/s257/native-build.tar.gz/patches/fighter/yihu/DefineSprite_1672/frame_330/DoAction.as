_root.aiEvent("doaction_entry", "4f45c6a2eba5776b8650ef16097bfeb0e0ee26b00b690eb264b88f5995f9e724," + escape(String(this)) + "," + _currentframe);
动作 = 0;
