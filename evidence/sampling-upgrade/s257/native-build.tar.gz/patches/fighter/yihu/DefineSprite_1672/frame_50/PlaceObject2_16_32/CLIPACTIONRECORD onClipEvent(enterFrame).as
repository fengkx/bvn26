onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "9d1637d11d32d981a0062aba4c0074fbf172bcef2f09e4fe3da96afb2156c4b5," + escape(String(this)) + "," + _currentframe);

   onJumping(3);
}
