_root.aiEvent("doaction_entry", "51a4a6d290112112846de48b70a2fc8a4a0340cfd15418d016347fc650ab7be6," + escape(String(this)) + "," + _currentframe);
_root.shine(394758);
