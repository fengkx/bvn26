_root.aiEvent("doaction_entry", "c5ad16895453c7b92a039415754544df25b587642a0868d620b06d57e74e0462," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
