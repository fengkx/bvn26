_root.aiEvent("doaction_entry", "5b13978a653c38cf73213c9d51076bfb433a824bc1a17f7c552804ea758e28d2," + escape(String(this)) + "," + _currentframe);
动作 = 0;
