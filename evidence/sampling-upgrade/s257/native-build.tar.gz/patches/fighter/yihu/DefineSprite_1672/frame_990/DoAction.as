_root.aiEvent("doaction_entry", "ddcde847145391ebd017ed29d60e5b9c0b326f6fa35bebc3186bbf2e86f6ef5b," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
