_root.aiEvent("doaction_entry", "30c0ce1f23583d82f90a473de915e6bf672184e9c00a276e2de4e5e9938ff9c0," + escape(String(this)) + "," + _currentframe);
kcplayed = 3;
