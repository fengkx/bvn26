_root.aiEvent("doaction_entry", "c1b1c4a7ae60033efd94df557a4c7f51c85ffba88bb2c169bbb11938bf8db76f," + escape(String(this)) + "," + _currentframe);
play();
