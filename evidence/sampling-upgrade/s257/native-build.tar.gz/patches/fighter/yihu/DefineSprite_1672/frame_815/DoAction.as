_root.aiEvent("doaction_entry", "7cc945fd5078e715bedf70832d5d1b67172a15bbb54b26f9a1b8364795012ed5," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
