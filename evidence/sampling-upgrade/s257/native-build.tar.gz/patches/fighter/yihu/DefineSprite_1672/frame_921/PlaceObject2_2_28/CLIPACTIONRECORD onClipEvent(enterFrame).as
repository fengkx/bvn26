onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "b4e52c95658f3e469f0153eef668c8ab54293a729c42d7b9515a20a00527b7e5," + escape(String(this)) + "," + _currentframe);

   beida();
}
