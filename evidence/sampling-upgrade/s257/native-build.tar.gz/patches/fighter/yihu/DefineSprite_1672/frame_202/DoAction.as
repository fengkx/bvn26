_root.aiEvent("doaction_entry", "092807446315f8bab0ebf552aa76aa5b9853ae0afdf6252a9bf01c925252e35f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
