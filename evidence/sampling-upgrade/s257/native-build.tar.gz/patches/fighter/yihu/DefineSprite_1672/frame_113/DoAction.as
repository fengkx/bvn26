_root.aiEvent("doaction_entry", "47515be5f6d2d346892353504fbca2fbcf812f953a7f289e3f1336873662dae1," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
