onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4a0e603131f4a17cbc28e809df91985af51bee15c6d69289c85bcdced98eb883," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍1");
      }
   }
}
