onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "f9c6ce0061138855355d7991f91bfc2d36161568d885ea5eb27c416783f7f1b0," + escape(String(this)) + "," + _currentframe);

   if(_root.game["p" + _parent.pn].mc.sw == false)
   {
      if(defence())
      {
         _parent.gotoAndPlay("防御2");
      }
   }
}
