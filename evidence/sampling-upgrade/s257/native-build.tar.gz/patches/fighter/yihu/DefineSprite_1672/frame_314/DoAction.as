_root.aiEvent("doaction_entry", "16adfae9dcac91d5bdbdb65b1c2aaabe2e54371760ac2b03bee2d6e045d690cd," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
