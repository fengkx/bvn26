_root.aiEvent("doaction_entry", "b4eb7c7b7b7b1f4527e67b601c7d184c58f85828a4bbeac715f210f5b8fb0120," + escape(String(this)) + "," + _currentframe);
stop();
