_root.aiEvent("doaction_entry", "cf978cc30f641017e005f4ced30f588feecb64e56b2bfa19e211a13db9dfb87d," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
bs = 0;
