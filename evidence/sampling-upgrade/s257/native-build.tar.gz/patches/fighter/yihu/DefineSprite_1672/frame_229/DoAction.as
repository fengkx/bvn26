_root.aiEvent("doaction_entry", "a49c7fc05c9ace932d15d6036d7626257f3b34d34d261427ded904daeae71898," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
