_root.aiEvent("doaction_entry", "e4e48924a816507dab5f49420c70c49136b84aed070d2041f28a2861509d5dff," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
