_root.aiEvent("doaction_entry", "38c0f720292f39407e4d91285eef41da435ef7873823848bf965e35ce22692c0," + escape(String(this)) + "," + _currentframe);
onBeHit();
