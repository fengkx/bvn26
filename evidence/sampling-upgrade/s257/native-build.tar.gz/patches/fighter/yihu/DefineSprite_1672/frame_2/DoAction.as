_root.aiEvent("doaction_entry", "fbea7814531b4d685e565b4a1049c4c54ef1b45a6a30ab3e30b60bfe9359bf95," + escape(String(this)) + "," + _currentframe);
hits = 0;
