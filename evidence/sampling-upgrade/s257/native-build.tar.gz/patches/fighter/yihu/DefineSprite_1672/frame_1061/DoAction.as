_root.aiEvent("doaction_entry", "85efdc0ec2797f2e7fca0859cf3b15fb363c2bcbe750052d53465bb73fb92de5," + escape(String(this)) + "," + _currentframe);
kcplayed = 2;
gotoAndStop("站立");
play();
