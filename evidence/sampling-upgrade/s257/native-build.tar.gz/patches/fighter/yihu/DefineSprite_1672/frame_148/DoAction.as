_root.aiEvent("doaction_entry", "213ebf8c05db3a92c6eaea61b626181bd1dfaf85b17366c96d275a7059f9344f," + escape(String(this)) + "," + _currentframe);
jump = 0;
