_root.aiEvent("doaction_entry", "666d2ede00b77c1c94ec6a6456262da455b1ba4ffa1c7282263df4b544b0c73e," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
