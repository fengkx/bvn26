_root.aiEvent("doaction_entry", "a059c7793d69e2b6ae03748f756c1449cd68e73bf071be917c5b2d830d95707c," + escape(String(this)) + "," + _currentframe);
onDefence();
