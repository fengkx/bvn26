_root.aiEvent("doaction_entry", "559a3201533954d8b9d70b823a5407a2a7d48996fb5a64e008b56b92ca8b500d," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
