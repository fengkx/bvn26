onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "7c8a18903a2d0e4ec7ff16584a99f97c4744f05069f43840e1696113f8444a4e," + escape(String(this)) + "," + _currentframe);

   _parent.beidax();
}
