onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0724c7fd5451b1cea43caf9b99164d3d2386ee1d5c3e7e1966cb922595fa4642," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(skill2())
      {
         _parent.gotoAndPlay("砍技2");
      }
      if(bisha())
      {
         _parent.gotoAndPlay("必杀");
      }
      if(magichit3())
      {
         _parent.gotoAndPlay("招3");
      }
      if(rush())
      {
         _parent.gotoAndPlay("瞬步");
      }
   }
}
