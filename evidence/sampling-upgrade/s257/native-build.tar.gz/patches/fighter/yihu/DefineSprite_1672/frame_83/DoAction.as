_root.aiEvent("doaction_entry", "f0198c4e62042e67f8b97aaa5fa6b7839b312278c76683a59d73342d527e662e," + escape(String(this)) + "," + _currentframe);
jump = 0;
