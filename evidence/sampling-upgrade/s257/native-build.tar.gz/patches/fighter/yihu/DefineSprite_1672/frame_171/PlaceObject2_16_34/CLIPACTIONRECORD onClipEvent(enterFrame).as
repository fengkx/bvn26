onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "523454ec78cdb2111f2c638aa00420aad61b379219b651d472dbd5eeb743612f," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += Math.round(_parent.speed);
      }
      else
      {
         _parent._parent._x -= Math.round(_parent.speed);
      }
   }
}
