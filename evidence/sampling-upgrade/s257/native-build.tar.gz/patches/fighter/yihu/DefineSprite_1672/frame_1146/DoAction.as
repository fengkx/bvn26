_root.aiEvent("doaction_entry", "5dd961eeae3dea6d6dd4acf8e9a95a9db7c06ba1bbf1f696617be2ccaa966fbc," + escape(String(this)) + "," + _currentframe);
stop();
