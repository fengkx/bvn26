_root.aiEvent("doaction_entry", "577d93e895b7ecec08a70ac7a3a9c4fd3a9c866f01f01559d68b25e13a639bee," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
