_root.aiEvent("doaction_entry", "9a594a1ff447627e46dc43d611600a57aa70594e582fc74654e570b021a85adf," + escape(String(this)) + "," + _currentframe);
if(_parent._xscale > 0)
{
   _parent._xscale = -100;
   _parent._x = _root.game["p" + pn]._x - _root.game["p" + pn].mc.bdmn._width * 0.7;
}
else
{
   _parent._xscale = 100;
   _parent._x = _root.game["p" + pn]._x + _root.game["p" + pn].mc.bdmn._width * 0.7;
}
_parent._y = _root.game["p" + pn]._y + _root.game["p" + pn].mc.bdmn._height * 0.5;
_root.shine();
