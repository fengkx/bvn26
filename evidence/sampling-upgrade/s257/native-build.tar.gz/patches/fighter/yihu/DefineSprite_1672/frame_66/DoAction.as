_root.aiEvent("doaction_entry", "4888d13bd45c27a6dbb6a0f5fd750920a8add13b14332010dfed173b5aa62a75," + escape(String(this)) + "," + _currentframe);
jump = 1;
jumped = 0;
