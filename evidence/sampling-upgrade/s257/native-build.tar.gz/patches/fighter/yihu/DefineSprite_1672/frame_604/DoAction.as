_root.aiEvent("doaction_entry", "ea9aca448daf398c4384bb1b9df963b5d335e971e0db5841428e2d02ae8499e9," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
