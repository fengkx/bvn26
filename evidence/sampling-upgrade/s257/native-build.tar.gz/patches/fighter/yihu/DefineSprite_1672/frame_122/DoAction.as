_root.aiEvent("doaction_entry", "b93b4db0713b2d03bee10d187b4dd8f3a6456290e28dcca7da483d1409bfe600," + escape(String(this)) + "," + _currentframe);
khit = 1;
动作 = 1;
