onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "e401bc37508d94df3c4fac86f7345a219cab28e809b90b6b2bd5b20c2ec259e7," + escape(String(this)) + "," + _currentframe);

   onJumping(5);
}
