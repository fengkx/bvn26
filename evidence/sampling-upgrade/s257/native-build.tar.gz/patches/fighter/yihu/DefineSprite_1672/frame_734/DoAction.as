_root.aiEvent("doaction_entry", "dbfb4fb883b5657ae3dc129bb745e50822b03f591ae111710b0a9abbfbb8a295," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"虚护3");
