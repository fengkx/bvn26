_root.aiEvent("doaction_entry", "928dbaea9bbebf130d0962a83930660c9ca540c424eed89d540b3cbb490ebdc9," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
