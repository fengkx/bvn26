_root.aiEvent("doaction_entry", "b13736d93883f3c5ee24b66518d4cd17037c506f50419d1338f2ef7d9221cf25," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
airBody = true;
