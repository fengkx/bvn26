_root.aiEvent("doaction_entry", "5621bd237ee53fd6e8580f8aae03ad02bbba1d60579d4f517e219b464276eda0," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
