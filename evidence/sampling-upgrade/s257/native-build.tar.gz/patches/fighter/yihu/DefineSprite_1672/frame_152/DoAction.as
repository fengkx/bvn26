_root.aiEvent("doaction_entry", "972e9e2725cf2014ef8a32f84c503305cc7bddfdeb5ba327c3459772e6e3c1d8," + escape(String(this)) + "," + _currentframe);
动作 = 0;
