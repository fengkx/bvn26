onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0d0ba7ba327fa820088e6989caef70dad3cd7f6a8713b94b686b9a5ee989d431," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit())
      {
         _parent.gotoAndPlay("砍1");
      }
   }
}
