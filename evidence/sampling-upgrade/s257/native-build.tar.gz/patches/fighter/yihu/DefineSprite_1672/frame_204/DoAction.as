_root.aiEvent("doaction_entry", "da2fb463abf78da319d39ad1c2fd72ff4d62e5d1db161c047274775eb378cc5a," + escape(String(this)) + "," + _currentframe);
动作 = 1;
