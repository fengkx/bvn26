onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "ab5be2ccc34b30d039da70e09b19298cb160fe5dbd3590950514ea9e99f9ce46," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false and _parent.sw == false)
      {
         if(_parent.kis(_parent.冲))
         {
            _parent.gotoAndPlay("起身");
         }
      }
   }
}
