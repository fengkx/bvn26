_root.aiEvent("doaction_entry", "1af5c719c7260145cb8431b6031f6c4b603e8d564c532ec907f00257fac8a218," + escape(String(this)) + "," + _currentframe);
_root.shine();
