_root.aiEvent("doaction_entry", "0c2570387849a118842d2bb46fef5778749d917239bf5583f70a5a61657aee51," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
