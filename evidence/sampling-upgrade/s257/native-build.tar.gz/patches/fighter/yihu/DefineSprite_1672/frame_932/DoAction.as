_root.aiEvent("doaction_entry", "698587e331fed02bdd9a526bbb1035ec8d840595c36ffd7780157187b76ea0aa," + escape(String(this)) + "," + _currentframe);
onBeHit(true);
