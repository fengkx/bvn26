_root.aiEvent("doaction_entry", "c7e26d020d568fd332b231ab53144f56f02f162398f0ebe85987251affe280ca," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
jump = 1;
jumped = 0;
