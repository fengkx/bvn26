onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "ba533a3da236d572e13ead98f01d3edde1bc6f1f367d9db78813089a49230a36," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent.zh10atm.hitTest(_root.game["p" + _parent.pn].mc.bdmn) || _parent.zh10atm.hitTest(_root.game["p" + _parent.pn].mc.jiao))
      {
         _parent._parent._xscale *= -1;
         _parent.gotoAndPlay("招12");
      }
      else
      {
         moveX(_parent.speed * 2);
      }
   }
}
