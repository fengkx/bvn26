onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "add2bffa543b8fa4f57a200a6492667a0b4d8f6a7f4822f8f7243645d71ee475," + escape(String(this)) + "," + _currentframe);

   fangyu();
}
