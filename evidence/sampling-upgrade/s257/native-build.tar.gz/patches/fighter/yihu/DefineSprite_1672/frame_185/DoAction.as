_root.aiEvent("doaction_entry", "4a560420eb816c3d8125ba262bca369b3cb880a284a4edd1df3bb3839ed35c69," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
