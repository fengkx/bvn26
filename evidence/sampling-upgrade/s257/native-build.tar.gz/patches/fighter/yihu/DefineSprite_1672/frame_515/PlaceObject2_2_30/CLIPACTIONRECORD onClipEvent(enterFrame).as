onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "ce0e67003b6bba7a9cb8d46125706295daad85ec3e1f8d3718ff2a4e6876eaa4," + escape(String(this)) + "," + _currentframe);

   beida();
}
