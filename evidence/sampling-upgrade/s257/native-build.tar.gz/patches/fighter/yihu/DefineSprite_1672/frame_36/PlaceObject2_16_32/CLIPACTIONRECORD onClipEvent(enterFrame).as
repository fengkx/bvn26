onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0a6a4594b5d12590ed6e1be460a1fb8710addb086d390719de2d4ab8c36d902e," + escape(String(this)) + "," + _currentframe);

   onJumping(1);
}
