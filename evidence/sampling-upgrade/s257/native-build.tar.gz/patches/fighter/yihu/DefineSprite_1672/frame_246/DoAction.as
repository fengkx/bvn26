_root.aiEvent("doaction_entry", "1d2bbbecdccb4318f44d6c840111ca1ca4362fecd007c086ea0552067bbcf2b1," + escape(String(this)) + "," + _currentframe);
动作 = 1;
