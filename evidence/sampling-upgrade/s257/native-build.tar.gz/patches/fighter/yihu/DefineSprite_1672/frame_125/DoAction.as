_root.aiEvent("doaction_entry", "1357ca2279118a775f1d53cdf270fadc777120b2a568461c4b77371541843a7a," + escape(String(this)) + "," + _currentframe);
动作 = 0;
