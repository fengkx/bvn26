onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "6bd67699707e84629dd974349c092b69e6db864a527ccd0896e50d7875fa1423," + escape(String(this)) + "," + _currentframe);

   fangyu();
}
