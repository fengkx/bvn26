_root.aiEvent("doaction_entry", "69f94a6914fea2d41c5c023e2b44e76c52faa02cb06d01700eeb6e51bb33bee5," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
