_root.aiEvent("doaction_entry", "5da20501322a35ded59ff1bbe536c9368976be803dc674f8e0a958a9da590713," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
bs = 0;
