onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "15852d205438f27066f642b23e1142cfe7d335f8ef1e64c7533dc3052da77bf6," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍3");
      }
   }
}
