_root.aiEvent("doaction_entry", "a814d490e6a319e6c8e0cef21ee54475fa00ddcf9ee9a8efa7bd925ee28889fd," + escape(String(this)) + "," + _currentframe);
动作 = 0;
