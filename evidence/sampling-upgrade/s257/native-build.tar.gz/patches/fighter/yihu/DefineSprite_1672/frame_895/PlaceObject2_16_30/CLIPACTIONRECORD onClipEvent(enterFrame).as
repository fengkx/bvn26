onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4ca9a6bc2ae7d683dcf3387b1091bd94bf1d620e087de327aea2d1e6c3b37df6," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(defence())
      {
         _parent.gotoAndPlay("防御2");
      }
      if(skill1())
      {
         _parent.gotoAndPlay("砍技1");
      }
      if(magichit2())
      {
         _parent.gotoAndPlay("招2");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      doDropDown();
   }
}
