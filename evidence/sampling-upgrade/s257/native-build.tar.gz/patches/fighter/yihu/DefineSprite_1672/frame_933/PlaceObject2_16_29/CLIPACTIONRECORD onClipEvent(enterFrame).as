onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "748ce14e84c5173f47dd5e9f08d7d2f05e28a462ef4fe4de3b999c6442642817," + escape(String(this)) + "," + _currentframe);

   _parent.beidax(true);
}
