_root.aiEvent("doaction_entry", "753cce050dc443c8bf6d6d85b536bd7fdcf73fa2f9382aa1c17ec1235076f2d7," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
