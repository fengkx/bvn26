_root.aiEvent("doaction_entry", "aade8303ef0b020195bbf7f885ba809478812289061165c66b8cd5b84c2537b3," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
