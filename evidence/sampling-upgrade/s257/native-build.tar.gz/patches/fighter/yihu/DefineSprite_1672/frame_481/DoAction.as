_root.aiEvent("doaction_entry", "ececdc0ad2170bd485680c853b633165f63539d844d477eaecfbb8936207ade2," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
