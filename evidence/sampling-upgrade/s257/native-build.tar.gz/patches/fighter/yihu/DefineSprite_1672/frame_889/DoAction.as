_root.aiEvent("doaction_entry", "8ce77546446958f7f50b3b25dbd832d62bc46ab32e968b3527b8fe7dd95ba268," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
