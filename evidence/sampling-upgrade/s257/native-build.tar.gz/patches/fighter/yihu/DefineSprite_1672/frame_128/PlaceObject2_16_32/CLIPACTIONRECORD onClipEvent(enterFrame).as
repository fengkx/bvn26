onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "90f097bca742a18df3baf599f4d828b1308554795985960810445228b1224961," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(moveLeft())
      {
         _parent._parent._x -= _parent.speed;
      }
      if(moveRight())
      {
         _parent._parent._x += _parent.speed;
      }
      if(airMagichit())
      {
         _parent.gotoAndPlay("跳招");
      }
   }
   _parent._parent._y -= 1;
}
