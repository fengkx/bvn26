_root.aiEvent("doaction_entry", "e3c84729022f82064189af4decb12629f9b2a3aa51d7346f58572dbbde7b91e2," + escape(String(this)) + "," + _currentframe);
if(_parent._xscale < 0)
{
   _parent._xscale = 100;
   _parent._x = _root.game["p" + pn]._x - 100;
}
else
{
   _parent._xscale = -100;
   _parent._x = _root.game["p" + pn]._x + 100;
}
_parent._y = _root.game["p" + pn]._y;
