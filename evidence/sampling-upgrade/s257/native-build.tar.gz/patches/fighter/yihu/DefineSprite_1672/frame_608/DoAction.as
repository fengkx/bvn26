_root.aiEvent("doaction_entry", "5b98770e3b936aa7ab5284ccb8e46063ab7b9ce5abf5ea71216a1fdd4e8e36e8," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"虚护1");
