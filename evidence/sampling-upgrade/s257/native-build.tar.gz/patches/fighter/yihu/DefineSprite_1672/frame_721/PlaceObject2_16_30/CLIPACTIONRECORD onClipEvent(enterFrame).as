onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "90528b3d1191bedb9bf3a4492c28a8cdba22bf017ee03a3cfaaeb564241723f3," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += Math.round(_parent.speed);
      }
      else
      {
         _parent._parent._x -= Math.round(_parent.speed);
      }
   }
}
