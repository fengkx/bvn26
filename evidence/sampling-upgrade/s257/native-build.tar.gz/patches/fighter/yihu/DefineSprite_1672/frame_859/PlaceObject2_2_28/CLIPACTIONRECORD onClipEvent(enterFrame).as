onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "18a566879d4b56052ca98fdddf643c6af1ec2fd4c51311690e21bec7235339c2," + escape(String(this)) + "," + _currentframe);

   beida();
}
