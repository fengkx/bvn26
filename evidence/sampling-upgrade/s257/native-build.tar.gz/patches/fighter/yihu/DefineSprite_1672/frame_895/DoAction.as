_root.aiEvent("doaction_entry", "36b8744631257a98048efef3fd75245ff8603a2744aad5bb9bf8992b7ad2d314," + escape(String(this)) + "," + _currentframe);
动作 = 2;
