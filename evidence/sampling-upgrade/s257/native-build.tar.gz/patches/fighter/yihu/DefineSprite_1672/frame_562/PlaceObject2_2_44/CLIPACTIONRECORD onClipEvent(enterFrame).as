onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0269fe38e796b2e1f800c101d2127542117866f1fd5895b7ad5e8859e9ee572b," + escape(String(this)) + "," + _currentframe);

   beida();
}
