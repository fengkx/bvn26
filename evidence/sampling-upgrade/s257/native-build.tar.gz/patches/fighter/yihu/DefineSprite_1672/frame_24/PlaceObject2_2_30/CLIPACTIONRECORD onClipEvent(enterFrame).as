onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d80ca13904db30ad2990becedf62ceedf861b7dff8e2dfca93040e1de57100bf," + escape(String(this)) + "," + _currentframe);

   beida();
}
