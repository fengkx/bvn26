_root.aiEvent("doaction_entry", "317bf5a9b3aea5df78a155f71498e5fac3b3263ca641dd6e09528a624df93774," + escape(String(this)) + "," + _currentframe);
jump = 0;
jumped = 1;
clearInterval(tdint);
gotoAndStop("站立");
play();
