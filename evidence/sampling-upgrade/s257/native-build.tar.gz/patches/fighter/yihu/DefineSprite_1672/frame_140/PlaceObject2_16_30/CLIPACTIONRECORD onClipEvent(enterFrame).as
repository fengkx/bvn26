onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "bbf65a6a5d84925758f517f3b80a2b61fba7940fbec5cadefc1f4c36d06e1a32," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 2;
      }
      else
      {
         _parent._parent._x += _parent.speed * 2;
      }
      _parent._parent._y += _parent.speed;
      if(_parent.touch == true)
      {
         _parent.gotoAndPlay("跳招2");
      }
   }
}
