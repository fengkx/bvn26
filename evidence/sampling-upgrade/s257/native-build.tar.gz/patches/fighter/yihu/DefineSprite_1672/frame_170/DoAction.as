_root.aiEvent("doaction_entry", "667f7170c7a5384b3dc3f8fb672ecf6f07aedd6bcc96aeb4a1fb178c2ee46959," + escape(String(this)) + "," + _currentframe);
动作 = 1;
