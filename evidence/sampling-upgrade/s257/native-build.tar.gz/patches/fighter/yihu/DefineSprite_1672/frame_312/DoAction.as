_root.aiEvent("doaction_entry", "3516a37c60a0fdde7602305e1b02d5e5f4f1eac4d89c052a401f1c3dac7147f6," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
