_root.aiEvent("doaction_entry", "9bc79ead72c5b9c14d7750eb9d81464e633df541166ad831e870030948dc26f4," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
