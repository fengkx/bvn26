_root.aiEvent("doaction_entry", "6472eb033ea58c638ba3d1dc7732824bb14850a42d22b2884408a411f13089db," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
