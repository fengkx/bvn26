onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "e9b465f384a913e21884f5ad983a994f7382ea30eff9c3c35dcc0862a9884302," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(moveLeft())
      {
         _parent._parent._x -= _parent.speed;
      }
      if(moveRight())
      {
         _parent._parent._x += _parent.speed;
      }
   }
   _parent._parent._y -= 1;
}
