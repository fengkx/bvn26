_root.aiEvent("doaction_entry", "9e5956d6978f8cc4ea0f94692becd37d62769c3027ca89ad62d06f95f845eac0," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
