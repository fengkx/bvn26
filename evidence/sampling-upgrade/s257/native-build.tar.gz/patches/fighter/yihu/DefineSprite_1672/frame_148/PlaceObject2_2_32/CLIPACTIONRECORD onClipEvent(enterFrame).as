onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "41b5afd4bb62f8865b7fad1436ef742e5cf57ad58105c6cff1e0d94bbfd41ea8," + escape(String(this)) + "," + _currentframe);

   beida();
}
