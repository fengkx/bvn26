onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "9c9baf272f6b4a8e11d10f9c0d6f424c814c366a06f5905dc854b2c99e40c6db," + escape(String(this)) + "," + _currentframe);

   beida();
}
