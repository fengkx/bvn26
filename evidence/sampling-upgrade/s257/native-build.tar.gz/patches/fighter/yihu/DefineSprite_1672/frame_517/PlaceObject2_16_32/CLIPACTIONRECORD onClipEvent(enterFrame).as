onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4d7f7528ca2e1c855083ce83c8cd9ce392f6e62ba8e59e6b85c3ee2d7adbcc69," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent.kis(_parent.斩))
         {
            _parent.gotoAndPlay("跳砍");
         }
      }
   }
}
