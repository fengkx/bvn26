onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "8a47eb9902b1ed87f12e70904d45bc244d36a9627cdd1bb07ae7afc7223bd7d6," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent._parent._xscale > 0)
         {
            _parent._parent._x -= 0.5;
         }
         else
         {
            _parent._parent._x += 0.5;
         }
      }
      _parent._parent._y -= 0.5;
   }
}
