_root.aiEvent("doaction_entry", "d0a8e3477ef776b55e51879386cf37d3eca0d533052a77c7890b5f48f36663e5," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"虚护2");
