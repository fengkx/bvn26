_root.aiEvent("doaction_entry", "a73843924a4dc6e980bb350bb77f24d213d02b79eae8c6a216d1ca92af1dcd3f," + escape(String(this)) + "," + _currentframe);
动作 = 1;
