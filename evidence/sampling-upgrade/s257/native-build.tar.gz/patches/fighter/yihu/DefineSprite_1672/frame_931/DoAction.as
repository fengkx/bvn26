_root.aiEvent("doaction_entry", "7a80b60527c89785107ebe447c21ea64d9405f9938fe9f9dbbf5947919902a0f," + escape(String(this)) + "," + _currentframe);
hited = 0;
play();
