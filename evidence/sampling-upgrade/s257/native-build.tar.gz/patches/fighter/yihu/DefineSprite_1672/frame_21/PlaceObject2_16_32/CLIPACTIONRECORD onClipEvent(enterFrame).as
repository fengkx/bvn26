onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c1442d61412ea1d2691c7cbb6b63091841fd663c9806b0955a596515c42c2815," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 4;
      }
      else
      {
         _parent._parent._x += _parent.speed * 4;
      }
      if(bishaUP())
      {
         _parent.gotoAndPlay("上必杀");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      if(bisha())
      {
         _parent.gotoAndPlay("必杀");
      }
   }
}
