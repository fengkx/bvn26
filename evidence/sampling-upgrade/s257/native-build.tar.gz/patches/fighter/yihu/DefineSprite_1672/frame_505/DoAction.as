_root.aiEvent("doaction_entry", "dd449a966a86a5d61e87904063fd6a87bdcc5e259cb2342d3a6dfc488a3d5679," + escape(String(this)) + "," + _currentframe);
jump = 1;
