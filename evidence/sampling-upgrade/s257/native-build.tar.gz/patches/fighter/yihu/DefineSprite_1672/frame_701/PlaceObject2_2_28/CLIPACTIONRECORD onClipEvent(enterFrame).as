onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "72a37cd4cc724a9ce1c1376b8edf4e27dd6d0265d4c0e1de6561bc341e26eeb1," + escape(String(this)) + "," + _currentframe);

   beida();
}
