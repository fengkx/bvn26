_root.aiEvent("doaction_entry", "68197d317efad06c00f4c3f76d471f075bd5f0c1d3edae3ee5b7f24ad54b01e4," + escape(String(this)) + "," + _currentframe);
动作 = 0;
