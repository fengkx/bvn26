_root.aiEvent("doaction_entry", "1f1553f960e69d5f9558b4fd68c4b49d61f1b38a42daa09903aa33851bc6fac9," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
