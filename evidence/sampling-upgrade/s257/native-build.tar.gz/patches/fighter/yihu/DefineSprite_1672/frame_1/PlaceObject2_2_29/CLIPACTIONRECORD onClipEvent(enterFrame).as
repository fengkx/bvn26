onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d7e17d4f5019ba28c0176b4da2a13b923c40b85242dc16595584829681cd27d5," + escape(String(this)) + "," + _currentframe);

   beida();
}
