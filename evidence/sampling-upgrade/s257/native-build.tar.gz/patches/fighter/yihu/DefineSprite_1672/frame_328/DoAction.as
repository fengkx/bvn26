_root.aiEvent("doaction_entry", "9874de845ba770006972d319123536e35eaff0985b0a4deedd9beb11287e749c," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
