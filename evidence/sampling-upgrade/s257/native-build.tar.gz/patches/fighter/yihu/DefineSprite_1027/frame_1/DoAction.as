_root.aiEvent("doaction_entry", "e9213334290daeec452ee61e540e7d313ca6dd8ebd46dca9962c013cdecbcc38," + escape(String(this)) + "," + _currentframe);
_root._y -= 5;
