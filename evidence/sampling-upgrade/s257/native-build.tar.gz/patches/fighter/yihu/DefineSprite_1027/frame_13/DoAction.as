_root.aiEvent("doaction_entry", "4c7c60300d6604d6a9db9c2385ffe46ed23d140744be5893a227b1f7f999580a," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
