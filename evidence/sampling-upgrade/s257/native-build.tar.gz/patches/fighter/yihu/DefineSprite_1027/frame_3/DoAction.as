_root.aiEvent("doaction_entry", "46a894cee0ee7132f62201612ba3eb8d1b3d90cc41dfdb20c25064409b1518c9," + escape(String(this)) + "," + _currentframe);
_root._y += 5;
