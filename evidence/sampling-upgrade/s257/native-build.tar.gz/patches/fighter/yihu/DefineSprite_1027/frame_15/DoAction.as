_root.aiEvent("doaction_entry", "effcda92b88d152ab982efaf96a6222885c5ffbd2b92a8f28b31f14f03632bfd," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
_root.shine();
