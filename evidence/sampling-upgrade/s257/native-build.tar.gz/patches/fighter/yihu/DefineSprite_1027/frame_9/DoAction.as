_root.aiEvent("doaction_entry", "8627951632d830873535350178ca6965f879cd4c88ce9acd8db2f2d318d1a807," + escape(String(this)) + "," + _currentframe);
_root._y -= 3;
