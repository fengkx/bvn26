_root.aiEvent("doaction_entry", "2d1dbce2aa7ed0806a6df6c687d5ca57bace5c34690778e271449c0e6aa5425d," + escape(String(this)) + "," + _currentframe);
_root._y += 3;
