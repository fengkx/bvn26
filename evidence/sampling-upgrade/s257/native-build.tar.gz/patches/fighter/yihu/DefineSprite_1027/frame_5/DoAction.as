_root.aiEvent("doaction_entry", "f9cf8c7b4d945a675665495a8bc81ecbab380eec8a8db4f1d217b93a5f0785dd," + escape(String(this)) + "," + _currentframe);
_root._y -= 4;
