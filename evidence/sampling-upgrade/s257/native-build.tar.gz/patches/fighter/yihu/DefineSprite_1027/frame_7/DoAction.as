_root.aiEvent("doaction_entry", "ef4ec639078e4a36450c1e74c7f86404361cc851c515f3ca7d75ed58f1a84282," + escape(String(this)) + "," + _currentframe);
_root._y += 4;
