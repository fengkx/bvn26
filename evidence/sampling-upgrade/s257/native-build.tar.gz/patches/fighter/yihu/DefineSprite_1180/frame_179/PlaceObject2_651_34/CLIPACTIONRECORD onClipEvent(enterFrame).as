onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c583fed71e24caedc47a1ff5f11bc4f2f2c4049765ad06e5312ea3902235226f," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍2");
      }
      if(bisha())
      {
         _parent.gotoAndPlay("必杀");
      }
   }
}
