onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "626de056fc250d8598b5cb790843f5a44de43aa50d4fc63a8034e6bad136fbce," + escape(String(this)) + "," + _currentframe);

   beida();
}
