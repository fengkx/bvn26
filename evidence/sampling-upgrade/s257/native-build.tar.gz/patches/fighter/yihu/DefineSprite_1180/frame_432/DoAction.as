_root.aiEvent("doaction_entry", "3ee35d2ad180dcd5a76c40fa5353e75ecf9e865eb0afccb804e3305786e269d4," + escape(String(this)) + "," + _currentframe);
_root.shine(0);
