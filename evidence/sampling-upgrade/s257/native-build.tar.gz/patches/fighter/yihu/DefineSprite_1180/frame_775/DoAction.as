_root.aiEvent("doaction_entry", "25a8a61d7a85edce3bb1dd3ca3487e7fba2bc8f0418d193a266a10096b606324," + escape(String(this)) + "," + _currentframe);
onDefence();
