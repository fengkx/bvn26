onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "7a5b9b8f64625198a7442b250a144a11cc234e26cb6a0f0d47d1f8fa2929f1d2," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(moveLeft())
      {
         _parent._parent._x -= _parent.speed;
      }
      if(moveRight())
      {
         _parent._parent._x += _parent.speed;
      }
      if(airMagichit())
      {
         _parent.gotoAndPlay("跳招");
      }
   }
   _parent._parent._y -= 1;
}
