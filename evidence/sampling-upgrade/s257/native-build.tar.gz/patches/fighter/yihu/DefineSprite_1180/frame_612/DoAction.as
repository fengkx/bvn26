_root.aiEvent("doaction_entry", "f1ff44c2ce97f78777c5af88a3bf826d83d87e1f5ff29afe5ba7d62e7b3d1bcc," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
