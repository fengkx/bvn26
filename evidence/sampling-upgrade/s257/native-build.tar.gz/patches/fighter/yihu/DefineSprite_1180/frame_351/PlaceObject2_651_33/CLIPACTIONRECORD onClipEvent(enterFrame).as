onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "35ff2f8d11f77fc033d5da9d6a87878d227c348f30924a135712c1136b1bb694," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 6.5;
      }
      else
      {
         _parent._parent._x += _parent.speed * 6.5;
      }
   }
}
