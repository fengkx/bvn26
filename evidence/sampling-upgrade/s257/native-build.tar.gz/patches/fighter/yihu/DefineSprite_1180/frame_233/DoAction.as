_root.aiEvent("doaction_entry", "d31e29b5b210e29c5359fd2d03db2d6dd2de65b3762b505fd3aa052cab4de80c," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
