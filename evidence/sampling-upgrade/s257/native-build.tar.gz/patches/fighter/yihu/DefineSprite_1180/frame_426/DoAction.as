_root.aiEvent("doaction_entry", "1314a0dc87cadd879810383de578b83e53f4aceddbc156e7bb75f3f38164d306," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
