_root.aiEvent("doaction_entry", "9cc31ecf80a48469b87013eda1edb335cf84aeb802ccf09a5a2034c17ee7dfb9," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
