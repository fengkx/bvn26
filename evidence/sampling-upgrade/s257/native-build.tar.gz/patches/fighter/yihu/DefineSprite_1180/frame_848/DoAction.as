_root.aiEvent("doaction_entry", "2a444abd1643813a60cb6e78b083822bb915c7ca5fa451683a5db796ba41615f," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
