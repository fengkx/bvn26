_root.aiEvent("doaction_entry", "336ff19ed252b1d981906dd86b695de7054a83c96e790c43ac8a95a3e9f51e03," + escape(String(this)) + "," + _currentframe);
jump = 1;
jumped = 0;
