onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "a17ca6e09ab2c78d27fccd08bfe4bc5434438dd6673b385801191a26ac15ecc7," + escape(String(this)) + "," + _currentframe);

   beida();
}
