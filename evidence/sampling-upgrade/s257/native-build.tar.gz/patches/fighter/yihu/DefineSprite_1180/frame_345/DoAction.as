_root.aiEvent("doaction_entry", "abb06da069031e29121f44051a4ad0126d8b6648daa1cb0be0c8fc1afbe81fd0," + escape(String(this)) + "," + _currentframe);
_root.shine(658063);
