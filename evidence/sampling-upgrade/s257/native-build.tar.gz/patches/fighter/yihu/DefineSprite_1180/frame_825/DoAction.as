_root.aiEvent("doaction_entry", "14cafaec21a6021f435653896d891281237c9054a4b5a54c3dc787eda8b94338," + escape(String(this)) + "," + _currentframe);
if(sw == true)
{
   stop();
}
