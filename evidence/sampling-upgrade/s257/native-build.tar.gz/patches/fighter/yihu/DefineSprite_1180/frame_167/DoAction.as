_root.aiEvent("doaction_entry", "30274f82f238561e71a7695590e1933130652cdae5f371e4fa628f4d7a00b3e5," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
