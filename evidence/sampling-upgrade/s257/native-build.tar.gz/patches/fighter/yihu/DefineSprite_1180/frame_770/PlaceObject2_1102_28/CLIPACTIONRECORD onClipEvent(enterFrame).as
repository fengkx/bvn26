onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "6ece2dc7ee39bcf44a2123a62c524eb5fea09bbfca243fda44defef1480a98f5," + escape(String(this)) + "," + _currentframe);

   bdfyxg();
}
