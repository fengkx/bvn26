_root.aiEvent("doaction_entry", "978bc8904334ac844bb7e0658278be33d18de41b8375c020bbf31e61c7deb457," + escape(String(this)) + "," + _currentframe);
kcplayed = 1;
