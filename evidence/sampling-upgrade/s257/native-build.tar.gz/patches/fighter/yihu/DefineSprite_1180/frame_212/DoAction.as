_root.aiEvent("doaction_entry", "edc56112963d38bf3ae7ce0872d4636c06593b14eb032f822dbb2f75f8134b31," + escape(String(this)) + "," + _currentframe);
_root.shine(0);
