onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "212fb2c3216c343b3852b9cd0e0d54cc8368dce402c7f49d3e32e28bc5a957b9," + escape(String(this)) + "," + _currentframe);

   if(_root.game["p" + _parent.pn].mc.sw == false)
   {
      if(defence())
      {
         _parent.gotoAndPlay("防御2");
      }
   }
}
