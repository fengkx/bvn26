_root.aiEvent("doaction_entry", "5f3715ad1b8afeaa81081126726a7cf36b936c8edb1c2a2ca24a1c5df28297a4," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
