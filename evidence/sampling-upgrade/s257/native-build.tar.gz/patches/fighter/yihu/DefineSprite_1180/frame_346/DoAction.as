_root.aiEvent("doaction_entry", "adf3319af41f4637b4bdd3a76791f3d6bbc3c665f1289a5f8f864ef8c4c9d4dd," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
