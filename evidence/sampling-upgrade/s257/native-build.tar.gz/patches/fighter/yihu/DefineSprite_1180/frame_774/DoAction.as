_root.aiEvent("doaction_entry", "a605e288996893d7dcea46346b6067c7babfd106fbbd6219548c5cdf920452ed," + escape(String(this)) + "," + _currentframe);
play();
