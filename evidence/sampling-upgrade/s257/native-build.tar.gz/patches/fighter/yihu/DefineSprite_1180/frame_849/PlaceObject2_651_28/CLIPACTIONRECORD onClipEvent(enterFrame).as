onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "47a44cd90fe08278071413f27506a3f9dbad3058ec27d7d9e1da895e5540950d," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x += _parent.speed * 0.8;
      }
      else
      {
         _parent._parent._x -= _parent.speed * 0.8;
      }
   }
}
