_root.aiEvent("doaction_entry", "0371c8ebcae15a0f2e8a41687ff5db2b50a2dfc5be6d9b3141f63988ab929472," + escape(String(this)) + "," + _currentframe);
_root.shine(1183014);
_root.shine();
