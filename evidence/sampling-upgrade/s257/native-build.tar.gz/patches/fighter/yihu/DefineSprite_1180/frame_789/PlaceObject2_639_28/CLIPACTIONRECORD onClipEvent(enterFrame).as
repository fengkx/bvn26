onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "dd61d9cc512cc900985fecabe50d2e2bf70c9cdbf6fc4b764bc9775a8f67d403," + escape(String(this)) + "," + _currentframe);

   beida();
}
