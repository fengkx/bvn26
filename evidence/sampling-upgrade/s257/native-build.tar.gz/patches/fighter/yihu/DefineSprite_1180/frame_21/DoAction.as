_root.aiEvent("doaction_entry", "9025837c977fcb95db5885886b0a25be5646c6b0d56c5bbed016b685074b384f," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
