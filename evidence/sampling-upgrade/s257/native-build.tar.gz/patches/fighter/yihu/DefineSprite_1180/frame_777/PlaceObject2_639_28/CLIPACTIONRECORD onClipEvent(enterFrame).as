onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "8ae7019e4245410758e96e5c9017c6a3ebb314ef4913d65d9ebe91e161f7cf37," + escape(String(this)) + "," + _currentframe);

   fangyu();
}
