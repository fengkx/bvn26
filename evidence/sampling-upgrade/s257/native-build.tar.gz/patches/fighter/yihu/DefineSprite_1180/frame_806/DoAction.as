_root.aiEvent("doaction_entry", "d884448e140074a23b621050ea8ba77933c42f0d796c3c72c73729082d42a856," + escape(String(this)) + "," + _currentframe);
stop();
