_root.aiEvent("doaction_entry", "c7a42b88394180ac3f0834c09f29ee3fbee890dfa94cfc5b464424aab7d9eabc," + escape(String(this)) + "," + _currentframe);
动作 = 0;
