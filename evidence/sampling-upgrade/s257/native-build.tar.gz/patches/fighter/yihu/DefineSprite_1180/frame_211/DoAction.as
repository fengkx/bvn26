_root.aiEvent("doaction_entry", "82a97080c7ba927f620735e5a49d03f312a98a655449362b4da6415542edcf6c," + escape(String(this)) + "," + _currentframe);
动作 = 1;
