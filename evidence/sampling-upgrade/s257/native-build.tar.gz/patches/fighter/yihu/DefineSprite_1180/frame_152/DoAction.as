_root.aiEvent("doaction_entry", "667db4bedee8adb27e9366bb047631a7ebe739098e6905b451ee0d706b7c56ff," + escape(String(this)) + "," + _currentframe);
jump = 0;
