_root.aiEvent("doaction_entry", "9f8247dbd2a453a4f50ff1f82f9ccf219c8c5f050faf4050618b69a4863d6a12," + escape(String(this)) + "," + _currentframe);
_root.shine();
