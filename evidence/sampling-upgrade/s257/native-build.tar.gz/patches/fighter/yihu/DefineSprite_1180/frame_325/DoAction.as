_root.aiEvent("doaction_entry", "49754000d3084716f59ca2e7242234861f324f4ff4154d90f5cb757e04dd6a0a," + escape(String(this)) + "," + _currentframe);
动作 = 0;
