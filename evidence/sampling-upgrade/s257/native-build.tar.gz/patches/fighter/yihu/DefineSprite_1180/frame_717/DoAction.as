_root.aiEvent("doaction_entry", "77bd05af2b6789d57a36d53bdcd8e5f8a0d24c54487bf6682ef4c2751e1d30be," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
