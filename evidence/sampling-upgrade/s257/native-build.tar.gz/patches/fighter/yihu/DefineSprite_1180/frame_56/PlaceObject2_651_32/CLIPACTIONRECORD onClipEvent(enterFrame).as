onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "bffe92a1db010f67987a0218eabe860da961993200c8e3b722875cc8a50ff138," + escape(String(this)) + "," + _currentframe);

   onJumping(3);
}
