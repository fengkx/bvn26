onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4626564f38fbcfdd71c02ec5942b120d89b6dec84d7991b2b4a2ca5bfb881cdb," + escape(String(this)) + "," + _currentframe);

   beida();
}
