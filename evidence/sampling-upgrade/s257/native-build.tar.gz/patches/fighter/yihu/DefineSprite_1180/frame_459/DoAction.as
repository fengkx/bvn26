_root.aiEvent("doaction_entry", "bcea25c5b916fed1b32572f7c410d393e64e134faa9dc6e3c843d5221400145a," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
