_root.aiEvent("doaction_entry", "c5a135bc3cda6c3bb87aab0b1cfc8539e455518af463a6e04956005e612f2347," + escape(String(this)) + "," + _currentframe);
stop();
