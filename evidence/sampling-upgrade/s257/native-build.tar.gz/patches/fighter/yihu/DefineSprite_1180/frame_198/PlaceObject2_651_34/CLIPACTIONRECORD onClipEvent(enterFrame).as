onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "4cdd66ebc5be9f47895107e076968fe818fe700b319aedaa7d7c46aa2bfbad25," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(skill2())
      {
         _parent.gotoAndPlay("砍技2");
      }
      if(nornalhit(true))
      {
         _parent.gotoAndPlay("砍3");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
   }
}
