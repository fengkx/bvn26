_root.aiEvent("doaction_entry", "15842d46b08812e12f2d671c9b5236458632b4aedf4e7433e87fd5fe9389d4b7," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
