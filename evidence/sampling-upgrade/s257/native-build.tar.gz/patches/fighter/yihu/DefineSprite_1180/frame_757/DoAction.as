_root.aiEvent("doaction_entry", "83148f4703ec64aeb2f56db9d22f85f6335b78cc4bcc94692e619f9fb47be126," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
