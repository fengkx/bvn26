_root.aiEvent("doaction_entry", "ef90b388e0b2d1d7a2e91515792edf61dc2c224f3654b406b40452c10c349594," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
