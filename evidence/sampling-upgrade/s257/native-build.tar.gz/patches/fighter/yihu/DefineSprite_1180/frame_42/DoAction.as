_root.aiEvent("doaction_entry", "b515bc0d5f40838f174bf5e4bf5686257985e2696ad62e64238e1778a88a7e1d," + escape(String(this)) + "," + _currentframe);
jump = 1;
