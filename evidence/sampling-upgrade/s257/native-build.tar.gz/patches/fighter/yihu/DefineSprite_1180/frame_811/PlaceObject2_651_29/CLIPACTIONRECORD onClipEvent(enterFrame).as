onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "502952318fc0cb095c86f3541b5e15194e9cb8890d84a3ad965226997f0c6487," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false and _parent.sw == false)
      {
         if(_parent.kis(_parent.冲))
         {
            _parent.gotoAndPlay("起身");
         }
      }
   }
}
