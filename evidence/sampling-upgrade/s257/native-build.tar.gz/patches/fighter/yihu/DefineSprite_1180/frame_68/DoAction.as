_root.aiEvent("doaction_entry", "f19135dc38067c28191591dc1c6977234fd0d533689c3a06982a4f2a0b32c507," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
