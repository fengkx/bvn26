_root.aiEvent("doaction_entry", "99e1af2268b1c153a711cbc4649c5fe51eebc45e9dbba278e283ca432dfdf55e," + escape(String(this)) + "," + _currentframe);
动作 = 0;
