_root.aiEvent("doaction_entry", "cfbd0a2acbd67157e3cf35208f4663b8dded7d315bd9ec167e42ce2709f9a44b," + escape(String(this)) + "," + _currentframe);
hits = 0;
