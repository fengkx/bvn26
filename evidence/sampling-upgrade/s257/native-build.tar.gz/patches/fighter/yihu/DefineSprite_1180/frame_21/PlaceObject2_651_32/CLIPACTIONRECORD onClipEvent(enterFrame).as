onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "0e7d9b573828b01e149f13a499781277a0489807c2a392b3ad83c9b09adfabbf," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 2.3;
      }
      else
      {
         _parent._parent._x += _parent.speed * 2.3;
      }
      if(bishaUP())
      {
         _parent.gotoAndPlay("上必杀");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      if(bisha())
      {
         _parent.gotoAndPlay("必杀");
      }
   }
}
