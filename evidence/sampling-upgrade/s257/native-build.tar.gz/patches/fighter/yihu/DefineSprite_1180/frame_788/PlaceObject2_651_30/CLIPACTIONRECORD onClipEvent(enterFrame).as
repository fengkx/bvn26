onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "b55a7d5f202e5e53c527075e7db155a094ad2726dad871fec813788461a75e04," + escape(String(this)) + "," + _currentframe);

   _parent.beidax();
}
