_root.aiEvent("doaction_entry", "dc0843c383acfb4d9d9720cd7ba029376a69234a9810410554e0371a9db2ef40," + escape(String(this)) + "," + _currentframe);
_root.shine(658063);
