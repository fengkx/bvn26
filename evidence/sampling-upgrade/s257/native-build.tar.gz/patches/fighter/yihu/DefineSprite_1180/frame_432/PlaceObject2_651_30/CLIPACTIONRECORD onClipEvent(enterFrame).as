onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "b25d0aae9c92e0f0b09fc2475a0da1116d8477066385dc33654013c1097c8b25," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale < 0)
      {
         _parent._parent._x -= _parent.speed * 1.5;
      }
      else
      {
         _parent._parent._x += _parent.speed * 1.5;
      }
      _parent._parent._y -= _parent.speed * 1.5;
   }
}
