_root.aiEvent("doaction_entry", "a9439059fe5b4387b6e85d75a6fdd50f7d51ba4921db0e8208d2b918c0e1b3a5," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
