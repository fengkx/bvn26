_root.aiEvent("doaction_entry", "bb136b2b1b0af3c5caa3d13f6912d6d80be96a5ef10e93c441f31ac9ec2082c4," + escape(String(this)) + "," + _currentframe);
动作 = 1;
