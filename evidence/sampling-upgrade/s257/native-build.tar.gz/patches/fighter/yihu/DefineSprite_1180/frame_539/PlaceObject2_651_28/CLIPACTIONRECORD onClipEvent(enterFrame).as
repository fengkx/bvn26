onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "e221cd1bfbc1ac6177cc888d12480c869912b0072e11b0f258a389455d712ffb," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent._parent._xscale < 0)
         {
            _parent._parent._x -= _parent.speed;
         }
         else
         {
            _parent._parent._x += _parent.speed;
         }
         _parent._parent._y -= _parent.speed;
      }
   }
}
