_root.aiEvent("doaction_entry", "10d29462e095e61b21aef09a7ea641c96a5af88bd9b79fbc19179904e6024c70," + escape(String(this)) + "," + _currentframe);
gotoAndPlay(146);
