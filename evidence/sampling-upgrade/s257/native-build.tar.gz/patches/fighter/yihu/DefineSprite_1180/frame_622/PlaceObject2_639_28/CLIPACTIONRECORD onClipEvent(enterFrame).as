onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "7143293e47a2d3e438c8829e07f2989b5a68a86de0de079f43b677962ec40764," + escape(String(this)) + "," + _currentframe);

   beida();
}
