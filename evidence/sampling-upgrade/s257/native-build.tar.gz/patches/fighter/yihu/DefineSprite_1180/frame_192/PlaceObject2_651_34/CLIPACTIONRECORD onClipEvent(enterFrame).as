onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "bae307e9bd123694f8630c5457f10fe13118ccc9949bba7eae20476e8899615e," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += Math.round(_parent.speed / 3);
      }
      else
      {
         _parent._parent._x -= Math.round(_parent.speed / 3);
      }
   }
}
