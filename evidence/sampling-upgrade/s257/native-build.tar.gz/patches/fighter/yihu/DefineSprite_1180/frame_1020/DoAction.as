_root.aiEvent("doaction_entry", "f517fbeeb16a9936f7971360d848858792bdcc7d652468cc3774fa375c34429a," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
