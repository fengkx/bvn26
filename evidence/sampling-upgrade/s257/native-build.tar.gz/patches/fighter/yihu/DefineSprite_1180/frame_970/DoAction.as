_root.aiEvent("doaction_entry", "bede8ac084fee210dff757a96e24bb087f1b1f66babd2580980eccaca00f4189," + escape(String(this)) + "," + _currentframe);
stop();
