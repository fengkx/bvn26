_root.aiEvent("doaction_entry", "e15ebadc776f5462742205c32354318c4e550383fe9ffc4f16e1247995c5d43d," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
