onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "222a2df778b28cdcb988e62e74e012b63a3ca7a4d31dc0222d3b44b9ce0aed88," + escape(String(this)) + "," + _currentframe);

   onJumping(6);
}
