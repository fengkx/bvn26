_root.aiEvent("doaction_entry", "b75214a7046c28ee47a3e4b08eb2641d7fc302c31e218914c80969d10a93feac," + escape(String(this)) + "," + _currentframe);
hited = 0;
play();
