_root.aiEvent("doaction_entry", "74d670ce8bbce7355dd0ee590e1971b24272debe421e4c8fe54d2893affaac35," + escape(String(this)) + "," + _currentframe);
动作 = 0;
