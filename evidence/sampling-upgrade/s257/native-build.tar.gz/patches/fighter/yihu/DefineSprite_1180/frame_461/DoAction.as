_root.aiEvent("doaction_entry", "3ce9fbf9845d40819a81bbf92123f622e90dad0d08f9c7d8961354bc7dea725d," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一户1");
