_root.aiEvent("doaction_entry", "4573bd8e9e88877e8174ff1537927fee779d40d1db392f08d09dc956bab6d780," + escape(String(this)) + "," + _currentframe);
khit = 1;
jump = 0;
jumped = 0;
动作 = 1;
ql += 5;
