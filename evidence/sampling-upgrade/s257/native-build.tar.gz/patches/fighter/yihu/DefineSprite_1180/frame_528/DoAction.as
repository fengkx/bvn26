_root.aiEvent("doaction_entry", "7e1204d48e591e1d83d6929debde3323047847359ce08245b92a8e962773af7f," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
