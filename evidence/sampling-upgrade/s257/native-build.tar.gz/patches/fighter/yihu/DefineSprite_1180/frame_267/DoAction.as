_root.aiEvent("doaction_entry", "9c431964ea6631e471052ff4a979d39aa86407aea15e4c02a2886690f6005a3b," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
jump = 1;
jumped = 0;
