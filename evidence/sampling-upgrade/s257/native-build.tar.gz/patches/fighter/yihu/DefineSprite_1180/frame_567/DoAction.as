_root.aiEvent("doaction_entry", "81b86f3a286fd5413130d25c108807b4405a5bacd12a0faa794cd2544e4458c4," + escape(String(this)) + "," + _currentframe);
_root.shine();
