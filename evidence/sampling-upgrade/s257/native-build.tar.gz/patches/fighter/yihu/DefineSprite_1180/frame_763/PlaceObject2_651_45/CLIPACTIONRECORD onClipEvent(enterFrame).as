onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "1baa9f055c30d1dabc3606185b89bf6d5b8fbe5996f0fa3ea8e17477a93848c8," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(defence())
      {
         _parent.gotoAndPlay("防御2");
      }
      if(skill1())
      {
         _parent.gotoAndPlay("砍技1");
      }
      if(magichit2())
      {
         _parent.gotoAndPlay("招2");
      }
      if(bishaSuper())
      {
         _parent.gotoAndPlay("超必杀");
      }
      doDropDown();
   }
}
