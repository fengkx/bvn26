_root.aiEvent("doaction_entry", "966a6f308d5bf240c3b19ae709f212d5459fa4e642fbb67cd2c2d0a53b9963b0," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
