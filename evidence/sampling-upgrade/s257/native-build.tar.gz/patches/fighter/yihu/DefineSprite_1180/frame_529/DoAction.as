_root.aiEvent("doaction_entry", "32eeb81f4e4d8eb5582463aab083723c67350b49822dd608ff60b24b691e404f," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一户2");
