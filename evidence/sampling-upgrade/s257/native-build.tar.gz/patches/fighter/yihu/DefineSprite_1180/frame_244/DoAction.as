_root.aiEvent("doaction_entry", "1757c3b0b0553a39eeeef220360463ac2095b2ac067c57d94f4d79b8baf5baa6," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
