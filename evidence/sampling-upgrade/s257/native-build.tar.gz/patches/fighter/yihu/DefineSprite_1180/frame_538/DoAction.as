_root.aiEvent("doaction_entry", "3b8c8681f0cf662d429d42d5dcc2539c514108b1383f88a348bf5e02a7049dde," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
jump = 1;
