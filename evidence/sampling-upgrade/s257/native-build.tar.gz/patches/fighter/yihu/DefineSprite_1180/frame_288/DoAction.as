_root.aiEvent("doaction_entry", "4dd2d0bba19bfc463e73723e65aac7e8b4b2425d6fa128e78e083770f45df537," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
