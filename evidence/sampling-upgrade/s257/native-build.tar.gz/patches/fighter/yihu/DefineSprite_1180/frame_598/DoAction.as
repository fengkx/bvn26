_root.aiEvent("doaction_entry", "786f0bd0c322b9757ac8fc8741d700597799792e2b30aece2b3d09e1399480f7," + escape(String(this)) + "," + _currentframe);
动作 = 0;
