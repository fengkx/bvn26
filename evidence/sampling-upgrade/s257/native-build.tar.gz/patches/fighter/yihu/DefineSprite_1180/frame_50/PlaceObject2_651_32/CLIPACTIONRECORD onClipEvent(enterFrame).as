onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "e81168fa591499118f2e970048d0212c66efb4944a0a5f3dd431fa38fd0ed5ef," + escape(String(this)) + "," + _currentframe);

   onJumping(2);
}
