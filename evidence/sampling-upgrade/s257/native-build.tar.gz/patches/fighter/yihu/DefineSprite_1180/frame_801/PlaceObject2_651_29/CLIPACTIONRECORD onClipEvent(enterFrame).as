onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "a66bb669670afeca03baf9223c5902583dd151f630d431be60bf6245712a0e35," + escape(String(this)) + "," + _currentframe);

   _parent.beidax(true);
}
