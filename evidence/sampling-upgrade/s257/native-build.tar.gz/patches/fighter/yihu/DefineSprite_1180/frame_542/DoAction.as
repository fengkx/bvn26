_root.aiEvent("doaction_entry", "cfb13763e64c715cd7512befd63356ffc9d777b904bf20470e9d52cd5e20e14f," + escape(String(this)) + "," + _currentframe);
_root.shine();
