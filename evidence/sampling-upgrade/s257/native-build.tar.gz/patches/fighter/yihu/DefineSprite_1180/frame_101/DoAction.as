_root.aiEvent("doaction_entry", "7c968c1cdc0fa4ebb93fd38451852c93cecf245c32533d814484ab5700d02dd3," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
