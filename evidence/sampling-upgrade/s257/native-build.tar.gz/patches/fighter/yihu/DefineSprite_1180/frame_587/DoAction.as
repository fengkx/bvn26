_root.aiEvent("doaction_entry", "6c6e9624a6ff70b11cea35d2266ad9c7ff2eeb4ca2ddb63b76eab4a7ba7e05cc," + escape(String(this)) + "," + _currentframe);
_root.shine();
