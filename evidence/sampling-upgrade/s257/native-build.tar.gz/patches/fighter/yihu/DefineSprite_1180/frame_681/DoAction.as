_root.aiEvent("doaction_entry", "fa08b4b7ff0287b30f032fdaf502aba8957ec603613982c6497d3a174dfabb74," + escape(String(this)) + "," + _currentframe);
动作 = 0;
