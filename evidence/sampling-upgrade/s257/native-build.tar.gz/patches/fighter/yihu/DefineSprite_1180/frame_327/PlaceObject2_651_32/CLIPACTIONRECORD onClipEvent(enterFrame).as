onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "75776a2f93c7805abc8731a4bf8f98f8aad82aed914249d3f438749f927c904a," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent.kis(_parent.斩))
         {
            _parent.gotoAndPlay("砍1");
         }
      }
   }
}
