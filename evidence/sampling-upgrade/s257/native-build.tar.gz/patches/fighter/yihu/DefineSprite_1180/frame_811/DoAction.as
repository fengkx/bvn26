_root.aiEvent("doaction_entry", "ef78650d39f147d0bebee0aefd64b14c8241493edfd5993a65e45e5a722fd5f0," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
