onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "5ab13dbc4d02ee7d394c119fdc204bb700447a37103d7ac9cf4a72e2823282bb," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit())
      {
         _parent.gotoAndPlay("砍1");
      }
   }
}
