_root.aiEvent("doaction_entry", "d45dfd530b569ec9ac33d195f891324ae68dc8ff2455638a3d7dde8a8b3e56fd," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
