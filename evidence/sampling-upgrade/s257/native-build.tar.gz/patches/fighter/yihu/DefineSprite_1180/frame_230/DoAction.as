_root.aiEvent("doaction_entry", "f10d20475580575b0ecc9fd6558102e95c21e1da62eeb61eeb376925eeaa8210," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
