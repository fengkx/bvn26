_root.aiEvent("doaction_entry", "1f1c1bd416abc19fe1607f8e6bd357b5a2995f351c243bee86f597a7e5aba452," + escape(String(this)) + "," + _currentframe);
onBeHit(true);
