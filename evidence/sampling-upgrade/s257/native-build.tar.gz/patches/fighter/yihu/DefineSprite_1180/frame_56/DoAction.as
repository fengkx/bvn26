_root.aiEvent("doaction_entry", "433d56218d3a77dfde74ac9bb1d0cce355c57200f80283a46ca4e42f72b6613a," + escape(String(this)) + "," + _currentframe);
jump = 0;
