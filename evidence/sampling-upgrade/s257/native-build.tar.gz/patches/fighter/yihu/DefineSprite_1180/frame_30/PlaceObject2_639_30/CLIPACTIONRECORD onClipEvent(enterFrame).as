onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "e119b9d1f452a70420889da0a4fca63b6b9be315538e16c72fb55f6290a64603," + escape(String(this)) + "," + _currentframe);

   beida();
}
