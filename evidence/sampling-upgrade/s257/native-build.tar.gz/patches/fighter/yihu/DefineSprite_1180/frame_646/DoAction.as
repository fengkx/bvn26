_root.aiEvent("doaction_entry", "d1d0ab00401c95ef2526edd6f03e08aee722e0530473c88d08a67d42704cc358," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
bs = 0;
