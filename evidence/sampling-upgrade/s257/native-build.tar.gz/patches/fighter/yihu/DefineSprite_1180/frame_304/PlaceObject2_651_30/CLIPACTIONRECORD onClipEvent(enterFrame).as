onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "061c89b10b047c4231933a4304a71a5d1d3efbe0e3e0790a0f6183d11278d115," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent._parent._xscale < 0)
         {
            if(_parent.zh10atm.hitTest(_root.game["p" + _parent.pn].mc.bdmn))
            {
               _parent._parent._xscale = 100;
               _parent.gotoAndPlay("招12");
            }
            else
            {
               _parent._parent._x -= _parent.speed * 2;
            }
         }
         else if(_parent.zh10atm.hitTest(_root.game["p" + _parent.pn].mc.bdmn))
         {
            _parent._parent._xscale = -100;
            _parent.gotoAndPlay("招12");
         }
         else
         {
            _parent._parent._x += _parent.speed * 2;
         }
      }
   }
}
