onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "ad441b5aeec81abe92011d70f11cd1b495a7c873ebf8b7dff1c6990bb521da72," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      _parent._parent._y -= 15;
   }
}
