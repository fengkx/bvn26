_root.aiEvent("doaction_entry", "3c5efde71b8d9abf473dd65b292520e660bb530d3a635cc712b95a2972bfe542," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
