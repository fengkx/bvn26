_root.aiEvent("doaction_entry", "f1e824e95b253ef2115a99dd11991f5ef91458c51454a18fba63651c1007ff61," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
