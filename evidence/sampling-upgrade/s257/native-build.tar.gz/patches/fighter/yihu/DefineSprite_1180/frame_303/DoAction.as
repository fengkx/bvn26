_root.aiEvent("doaction_entry", "5973cc466da48f478168eb57cf242faafa6ce12861fb682fc2b8cbe0965f6177," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
