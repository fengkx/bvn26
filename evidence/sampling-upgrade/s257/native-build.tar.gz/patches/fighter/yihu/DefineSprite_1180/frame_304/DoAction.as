_root.aiEvent("doaction_entry", "688b2bb5ce0e4e8ec0d07a325274b29b8e854c5c5733d85990bb5b3ccee86966," + escape(String(this)) + "," + _currentframe);
_root.loop++;
duplicateMovieClip(_root.game.xgch,"xgch" + _root.loop,16384 + _root.loop);
_root.game["xgch" + _root.loop]._x = _parent._x;
_root.game["xgch" + _root.loop]._xscale = _parent._xscale;
_root.game["xgch" + _root.loop]._y = _parent._y;
_root.game["xgch" + _root.loop].gotoAndStop(2);
