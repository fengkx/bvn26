_root.aiEvent("doaction_entry", "eef498ee029b20cd01b38ac70cb32746925bb67393562f903fa6b60b12315dff," + escape(String(this)) + "," + _currentframe);
doZhaoHuan();
