_root.aiEvent("doaction_entry", "54bbd5ee564bcc6957eba9c716d1d69b015bd2b52f1a3fbb5d3d6642ac6c7838," + escape(String(this)) + "," + _currentframe);
onBeHit();
