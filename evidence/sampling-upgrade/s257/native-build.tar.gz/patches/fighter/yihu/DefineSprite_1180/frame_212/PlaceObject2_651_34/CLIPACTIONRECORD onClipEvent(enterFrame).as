onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "c840db570347dc259381cb63f8a5e17ccc275a98ea9d5425eb1ee13ce57f2160," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += Math.round(_parent.speed / 4);
      }
      else
      {
         _parent._parent._x -= Math.round(_parent.speed / 4);
      }
   }
}
