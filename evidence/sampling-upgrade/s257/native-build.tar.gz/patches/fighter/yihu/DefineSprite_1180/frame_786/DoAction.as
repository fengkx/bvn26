_root.aiEvent("doaction_entry", "4c80d2f0874e4a1eadaf1e5e87cd53c60583c0f9839a5bb7583b81a66c028d4d," + escape(String(this)) + "," + _currentframe);
play();
