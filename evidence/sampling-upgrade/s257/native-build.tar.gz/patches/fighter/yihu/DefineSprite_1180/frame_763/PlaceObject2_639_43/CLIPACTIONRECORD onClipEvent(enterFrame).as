onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "db4dda768081defad87a8de403690c69b32397b1714e88f0fa4eee870d142cc4," + escape(String(this)) + "," + _currentframe);

   fangyu();
}
