_root.aiEvent("doaction_entry", "ba962e6a6882550b28da502beb97cb5b619d29aabd8631e94044e56253f5c21d," + escape(String(this)) + "," + _currentframe);
jump = 0;
jumped = 1;
clearInterval(tdint);
gotoAndStop("站立");
play();
