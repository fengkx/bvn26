onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "b476a81b23903fc977d8535e6527205ccbbd5f4c0109d2428b4cd262c47c37d1," + escape(String(this)) + "," + _currentframe);

   onJumping(1);
}
