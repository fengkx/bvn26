onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "7b7ef2858f4b33f9d74bd04a1113c0eecdbeb78b38a8c8e8182f1dbd9e419594," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_parent._parent._xscale > 0)
      {
         _parent._parent._x += Math.round(_parent.speed / 4);
      }
      else
      {
         _parent._parent._x -= Math.round(_parent.speed / 4);
      }
   }
}
