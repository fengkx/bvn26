_root.aiEvent("doaction_entry", "4eefed79ae1fb14ca580ee17c9825a54805c84e512af34442e9073393235c128," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
