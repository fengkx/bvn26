_root.aiEvent("doaction_entry", "60a6dbbe8d142e8ebea588c97874f5ff4f944bad8d01c8daf88e1dffb06e681e," + escape(String(this)) + "," + _currentframe);
动作 = 0;
