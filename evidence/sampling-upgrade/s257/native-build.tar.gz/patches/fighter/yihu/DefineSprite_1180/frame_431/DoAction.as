_root.aiEvent("doaction_entry", "d2cb8883ee6b33cd9f1b3584c625b9c803a0113a1f3301c08954453bd3656b03," + escape(String(this)) + "," + _currentframe);
jump = 1;
