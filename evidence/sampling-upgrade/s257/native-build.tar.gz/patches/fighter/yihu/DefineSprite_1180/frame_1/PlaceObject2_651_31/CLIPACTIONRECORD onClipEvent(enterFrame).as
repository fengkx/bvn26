onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "8e505daf8cc01d703e1876cf75996721b2da02bca06aad96eafe1dcfba8e4e0f," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      doAllAction();
   }
}
