_root.aiEvent("doaction_entry", "2bc7678b7275fb968a18058d11940e7550bbeb7b38906d2337535ca2efdba1c5," + escape(String(this)) + "," + _currentframe);
动作 = 0;
