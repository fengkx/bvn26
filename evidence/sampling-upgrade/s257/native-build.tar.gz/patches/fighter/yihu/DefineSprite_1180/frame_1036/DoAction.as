_root.aiEvent("doaction_entry", "cd7260c1aa91c4bda224ada392366871d24b8cba049c97360bc1f9088204dd12," + escape(String(this)) + "," + _currentframe);
wankai();
