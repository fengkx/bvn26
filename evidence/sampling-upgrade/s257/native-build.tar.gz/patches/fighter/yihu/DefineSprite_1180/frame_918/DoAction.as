_root.aiEvent("doaction_entry", "19aa6d29198e1d97fcd09d05c7fd5fc44434716467f66a501b5f9e28e227ff7a," + escape(String(this)) + "," + _currentframe);
wankai_end();
