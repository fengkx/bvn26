_root.aiEvent("doaction_entry", "e2f1c5ae795b2ad00af712a78a2e74ce148e3e6930730fbd76188ff8720d9f94," + escape(String(this)) + "," + _currentframe);
动作 = 1;
