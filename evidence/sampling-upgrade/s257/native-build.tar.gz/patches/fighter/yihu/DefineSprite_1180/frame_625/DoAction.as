_root.aiEvent("doaction_entry", "731c1f67e0f8e451da856bb7bbd7192a6da93eeef29663499c1d170a29eb8880," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"一户万解1");
