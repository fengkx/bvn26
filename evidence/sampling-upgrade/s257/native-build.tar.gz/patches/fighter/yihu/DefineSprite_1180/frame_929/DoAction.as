_root.aiEvent("doaction_entry", "e2d68cbac8fbb952b06c9b764bd302956ae3f2203ccc2f1828537317b0d71eba," + escape(String(this)) + "," + _currentframe);
kcplayed = 2;
gotoAndStop("站立");
play();
