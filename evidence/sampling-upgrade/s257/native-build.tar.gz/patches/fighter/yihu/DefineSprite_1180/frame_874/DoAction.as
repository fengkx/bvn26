_root.aiEvent("doaction_entry", "f278da934d3e9c8c80647cb48fb0637335149b229f0aaad8f54f4017e5b52e72," + escape(String(this)) + "," + _currentframe);
kcplayed = 3;
