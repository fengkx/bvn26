_root.aiEvent("doaction_entry", "da1532366ed2ca8807b37db07a33f816cf46b880412fb228c843d70a8947010d," + escape(String(this)) + "," + _currentframe);
khit = 1;
动作 = 1;
