onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "34ade38ff62d390456b7726747257dc33bbd031330c160eac6cb2d5d1f215db2," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(bishaUP())
      {
         _parent.gotoAndPlay("上必杀");
      }
      if(magichit3())
      {
         _parent.gotoAndPlay("招3");
      }
      if(rush())
      {
         _parent.gotoAndPlay("瞬步");
      }
   }
}
