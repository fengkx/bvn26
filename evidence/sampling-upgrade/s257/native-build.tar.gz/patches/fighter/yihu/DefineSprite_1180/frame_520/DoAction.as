_root.aiEvent("doaction_entry", "ad8bbca019960bf0f3412b9ed5734fb265ed34f7dd26f96452af97cc7e75dc36," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
