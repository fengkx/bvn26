_root.aiEvent("doaction_entry", "e80de9e5ae93303507284fd9e11e4eb1eb17fe101c9c71a37b469a1b674ac1c4," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
