onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "05699a4435ee6e5941409524a31aca5e81f291bd6ec7c4f73501cfc9f58d9d0a," + escape(String(this)) + "," + _currentframe);

   beida();
}
