onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "438e25fec5ee67109d1ea42485e36f636c87ff04d8502e27287458123c63ed4d," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(moveLeft())
      {
         _parent._parent._x -= _parent.speed;
      }
      if(moveRight())
      {
         _parent._parent._x += _parent.speed;
      }
   }
   _parent._parent._y -= 1;
}
