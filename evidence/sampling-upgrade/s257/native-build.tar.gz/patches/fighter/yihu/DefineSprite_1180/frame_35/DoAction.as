_root.aiEvent("doaction_entry", "c3fe75efa322a0b05b235f27554582191d04a39bd4bd5c3ffe74fea185fa220c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
