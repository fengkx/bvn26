_root.aiEvent("doaction_entry", "9d37a2f6b9d5211bb2ca45e405cc23af3ac1513cc6df98d5991d2c8526bda1c5," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
