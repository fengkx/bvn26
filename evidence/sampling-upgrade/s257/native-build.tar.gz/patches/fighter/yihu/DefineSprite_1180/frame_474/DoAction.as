_root.aiEvent("doaction_entry", "dd04a7e5edf93cf19fa370221fd9dd4e8d69f97ec608ad383ed57b787ac02216," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
