_root.aiEvent("doaction_entry", "412db5141f25232980a146ff7ec8554b5bdd567344d3707515aa4b565cfb751a," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
