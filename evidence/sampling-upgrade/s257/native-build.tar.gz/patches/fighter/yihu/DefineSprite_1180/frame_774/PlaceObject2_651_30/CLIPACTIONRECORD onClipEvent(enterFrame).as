onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "2198b761850a797cb1b3b41ef667425ce41fa19811b4803e71faf90da39a7a6f," + escape(String(this)) + "," + _currentframe);

   _parent.fangyux();
}
