_root.aiEvent("doaction_entry", "684a6668f9a82901284444f9a345ff782dc6d6586b40334428f0d744e50d422d," + escape(String(this)) + "," + _currentframe);
_root.shine(1183014);
_root.shine();
