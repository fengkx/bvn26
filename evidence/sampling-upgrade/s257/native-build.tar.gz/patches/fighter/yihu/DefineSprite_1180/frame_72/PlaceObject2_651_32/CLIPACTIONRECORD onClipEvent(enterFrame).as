onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "688878db25997b74da77be8fb2a623d008cfb33a8a76ae1a41653e1ac151865e," + escape(String(this)) + "," + _currentframe);

   onJumping(4);
}
