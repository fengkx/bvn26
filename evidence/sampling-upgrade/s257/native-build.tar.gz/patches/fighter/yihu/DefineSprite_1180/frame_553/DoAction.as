_root.aiEvent("doaction_entry", "8ab66be28d72d5bcf2be76d9cf994aa59ddad928195f02b1af9f437e34b7664c," + escape(String(this)) + "," + _currentframe);
_root.shine();
