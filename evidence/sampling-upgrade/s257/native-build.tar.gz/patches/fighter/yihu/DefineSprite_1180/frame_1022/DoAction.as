_root.aiEvent("doaction_entry", "46da77894c13d8a0fefe963dac1bae3a7e78c46613700a358e56a5ee9298dd76," + escape(String(this)) + "," + _currentframe);
wankai_start();
_root.showFace(pn,"虚护1");
