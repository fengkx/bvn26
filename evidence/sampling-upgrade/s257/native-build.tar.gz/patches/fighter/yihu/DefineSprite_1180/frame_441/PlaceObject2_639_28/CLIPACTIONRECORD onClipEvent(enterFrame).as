onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "babe8dcb1e0db645689ab19bdf1a2f11af07a9062f2d4cfba6246b8846aa5b58," + escape(String(this)) + "," + _currentframe);

   beida();
}
