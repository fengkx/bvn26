onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "a373d3703a863876b9c6101a3e92810c87bd331da46cc2c7abbb9484a86a6487," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      _parent._parent._y += 10;
      if(_parent.nn >= 1)
      {
         if(_parent.touch == true)
         {
            _parent.gotoAndPlay("跳招2");
         }
      }
   }
}
