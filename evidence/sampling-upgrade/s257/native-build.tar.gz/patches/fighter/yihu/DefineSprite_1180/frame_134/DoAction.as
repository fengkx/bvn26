_root.aiEvent("doaction_entry", "e9d7f2d4c4dd467ad4fb8d86a9cca7ebd8a043b45ba64d0634b48ff36350951b," + escape(String(this)) + "," + _currentframe);
动作 = 0;
