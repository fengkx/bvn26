onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "38f43d5f677af2ce57f3316befb6c3cb742f31bfbe603db9623eea0a4a641921," + escape(String(this)) + "," + _currentframe);

   onJumping(5);
}
