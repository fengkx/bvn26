_root.aiEvent("doaction_entry", "2d7960dfbb548d09b3205c8d5d167698f00b1dba768bcfc1e308bce36bfc3b21," + escape(String(this)) + "," + _currentframe);
stop();
