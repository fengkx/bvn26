_root.aiEvent("doaction_entry", "3a45ecf45eabd1781370d642cbdd7c19e5cbec72394f9dc7a8a41c6deb17de58," + escape(String(this)) + "," + _currentframe);
动作 = 2;
