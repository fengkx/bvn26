_root.aiEvent("doaction_entry", "73f3f8a3e4aab5a0eb6667d944a2b942bd3086fd62197d51d620b73b75cba458," + escape(String(this)) + "," + _currentframe);
khit = 0;
jump = 0;
