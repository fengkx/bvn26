onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "d104ac134c8b1af9152d4c81d23ac25ac610bcc2c55c8fa3032ecbb85eeae0b8," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(_parent.kis(_parent.斩))
         {
            _parent.gotoAndPlay("跳砍");
         }
      }
   }
}
