onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "993ffd95c035e582129cf86075e83ed27da1d4d5e392cdc1d19c7064fc93e926," + escape(String(this)) + "," + _currentframe);

   beida();
}
