onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "3686d543e39370da087e4ef1772da239843bf6f1bdb81b70ccbbb816ed234eae," + escape(String(this)) + "," + _currentframe);

   beida();
}
