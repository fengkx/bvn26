_root.aiEvent("doaction_entry", "5fbeee626584596fd0cbbece3f9aab23e3a1fadda195fc1bc3745ff0d85faf20," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
