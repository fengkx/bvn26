_root.aiEvent("doaction_entry", "0a6c2d9ae79690b44ac76aa913d99ee270a64dc5e9702fdf207c18ae1516efdd," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
