_root.aiEvent("doaction_entry", "606ecbecfe5859a64096cda7a7d8eb2a0249eb31989bc5b8dc2ad38ec67d23c4," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
