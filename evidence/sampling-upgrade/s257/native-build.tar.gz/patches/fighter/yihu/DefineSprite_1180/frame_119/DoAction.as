_root.aiEvent("doaction_entry", "4181d1f56765726e80e7e8f3ed94937759779c46d0c9c964a7dded0f63a4e09c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
