_root.aiEvent("doaction_entry", "9504b24c67629544e2be1fdb15953620f8130fc0e90d7140f1a3c9bf668ab433," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
