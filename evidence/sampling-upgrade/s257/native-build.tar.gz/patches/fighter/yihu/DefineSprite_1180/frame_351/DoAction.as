_root.aiEvent("doaction_entry", "f102631a8049bd57045df48201ecc9f88b0fa6e369a3e504c2950ba87775366e," + escape(String(this)) + "," + _currentframe);
_root.shine(1183014);
_root.shunbuxg(_parent);
