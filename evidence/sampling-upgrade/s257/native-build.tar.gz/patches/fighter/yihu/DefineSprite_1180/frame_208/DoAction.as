_root.aiEvent("doaction_entry", "2a5cc13a9bc36633b243d00730807420f1afba4f909a6fd8605dfebd75cdd78e," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
