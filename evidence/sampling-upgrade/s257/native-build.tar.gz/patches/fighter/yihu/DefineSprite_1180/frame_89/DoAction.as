_root.aiEvent("doaction_entry", "f921171608e14bc917e2b4f563707b3e02e29363218dd8a86b78a4276d4159ac," + escape(String(this)) + "," + _currentframe);
jump = 0;
