_root.aiEvent("doaction_entry", "bb19f7569866ec587e3a70cde0a7f34a79c7ad2a38a08c301f2e3f17cebb9540," + escape(String(this)) + "," + _currentframe);
_root._y += 3;
