_root.aiEvent("doaction_entry", "8ef911d6dba0dcac90a92a04ab27a6287c01d6c18eced836c9d0e7aa8c741269," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
_root.shine();
