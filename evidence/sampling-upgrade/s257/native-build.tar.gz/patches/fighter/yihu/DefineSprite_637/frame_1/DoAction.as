_root.aiEvent("doaction_entry", "a6a4b9089ccd416e9481ca1153c597472f06e1fe7376a49bf613b649450b9cb8," + escape(String(this)) + "," + _currentframe);
_root._y -= 5;
