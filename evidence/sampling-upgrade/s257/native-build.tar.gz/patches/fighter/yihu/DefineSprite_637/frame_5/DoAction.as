_root.aiEvent("doaction_entry", "3c75d2a65fee99822721bb504b25989cc194b022dcd671bb7cab9d92af72551d," + escape(String(this)) + "," + _currentframe);
_root._y -= 4;
