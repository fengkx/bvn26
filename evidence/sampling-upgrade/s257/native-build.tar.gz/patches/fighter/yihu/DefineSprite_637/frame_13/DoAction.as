_root.aiEvent("doaction_entry", "f9150576235b7a6e43c3398012755ff23a673c439ef51952ab7d1e8046180e5b," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
