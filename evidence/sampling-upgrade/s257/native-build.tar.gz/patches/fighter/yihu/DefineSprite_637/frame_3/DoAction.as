_root.aiEvent("doaction_entry", "64ca8a082d90f4bdfbfbb2a9bdf9b48acf0eac37f7fd11b0987a96c0294a0744," + escape(String(this)) + "," + _currentframe);
_root._y += 5;
