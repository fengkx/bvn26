_root.aiEvent("doaction_entry", "4218e45d0b1137da0f95bc73a19809c6e6485534fe535a886a28a40eb8596227," + escape(String(this)) + "," + _currentframe);
_root._y += 4;
