_root.aiEvent("doaction_entry", "0fdc9e888b0cbe66ee4b1a0612db2c4dac11c38c9571f2f6e835915038d182f1," + escape(String(this)) + "," + _currentframe);
_root._y -= 3;
