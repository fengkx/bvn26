_root.aiEvent("doaction_entry", "97c92408e45e027bb15c13f134774ca80585dc61fab6cf66bbe0a4270fd1c615," + escape(String(this)) + "," + _currentframe);
stop();
