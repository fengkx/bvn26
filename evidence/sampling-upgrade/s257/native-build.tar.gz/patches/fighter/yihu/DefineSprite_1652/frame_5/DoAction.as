_root.aiEvent("doaction_entry", "ac91720980973525e47560152f86727cde2a9b00e931e3cb776fc3d6232bceb1," + escape(String(this)) + "," + _currentframe);
_root._y -= 4;
