_root.aiEvent("doaction_entry", "32416066e1d76ea328079d243877c388496270b24118a3459894e7bcbb8ce51c," + escape(String(this)) + "," + _currentframe);
_root._y -= 5;
