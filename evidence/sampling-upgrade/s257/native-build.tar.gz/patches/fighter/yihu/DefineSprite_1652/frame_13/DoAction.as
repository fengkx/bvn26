_root.aiEvent("doaction_entry", "8db9ce2e82ee549b274001f34af5d0c6af9fba646c56167d0ed57bf50c31c1dc," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
