_root.aiEvent("doaction_entry", "21cd149d7adb80c1673e011b8542710593bde71bf4d110f66c305f11f11b9010," + escape(String(this)) + "," + _currentframe);
_root._y += 5;
