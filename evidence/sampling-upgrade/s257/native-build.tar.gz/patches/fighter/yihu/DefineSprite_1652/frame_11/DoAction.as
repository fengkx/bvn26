_root.aiEvent("doaction_entry", "e36b6762ef6860be96c327b1bb4ebbe7df1e9a59250e056943f70c38f6e45c31," + escape(String(this)) + "," + _currentframe);
_root._y += 3;
