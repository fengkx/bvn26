_root.aiEvent("doaction_entry", "c5bdbbb23bbd3be7e88ae2d4b1843a8b53d7f49f64cfdec716f69f3bd154e811," + escape(String(this)) + "," + _currentframe);
_root._y -= 3;
