_root.aiEvent("doaction_entry", "32b87f741480c7550ca95dbc69763130be32e672708f38d2eb999fb04a721092," + escape(String(this)) + "," + _currentframe);
_root._y += 4;
