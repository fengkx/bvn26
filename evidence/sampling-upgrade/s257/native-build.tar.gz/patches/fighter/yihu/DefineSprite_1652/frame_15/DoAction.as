_root.aiEvent("doaction_entry", "828143a41b8174c191d2463590f4ef19be857a627e5182356505e76ba1e0188e," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
_root.shine();
