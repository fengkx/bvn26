_root.aiEvent("doaction_entry", "3a644cebfa6dd22e170243dff2e4978747bc277a6af414c635de4d065df3be58," + escape(String(this)) + "," + _currentframe);
动作 = 0;
