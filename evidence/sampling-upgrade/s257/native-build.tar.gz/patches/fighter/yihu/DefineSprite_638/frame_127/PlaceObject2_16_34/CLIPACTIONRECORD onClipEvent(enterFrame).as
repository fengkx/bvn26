onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "abc1b6d22c8cca17e0a90fb5dd8a2ff20c56b2791c78b9a0437ff6bc29eef242," + escape(String(this)) + "," + _currentframe);

   if(_root.zhanting == false)
   {
      if(_root.game["p" + _parent.pn].mc.sw == false)
      {
         if(moveLeft())
         {
            _parent._parent._x -= _parent.speed;
         }
         if(moveRight())
         {
            _parent._parent._x += _parent.speed;
         }
      }
      _parent._parent._y -= 1;
   }
}
