onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "070342a73be6194b40ae2b00a6b4267884fa3265c3df93c86e9ca8d4185d0642," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(nornalhit())
      {
         _parent.gotoAndPlay("砍1");
      }
   }
}
