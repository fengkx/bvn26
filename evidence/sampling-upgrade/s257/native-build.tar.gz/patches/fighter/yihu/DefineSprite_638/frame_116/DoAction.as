_root.aiEvent("doaction_entry", "90cf310ed457c1d2803149c39f87c6d6b99a291eba60c12a35e770e9b1331bc3," + escape(String(this)) + "," + _currentframe);
khit = 0;
jump = 0;
