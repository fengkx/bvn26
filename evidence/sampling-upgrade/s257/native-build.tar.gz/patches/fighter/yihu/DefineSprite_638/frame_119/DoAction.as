_root.aiEvent("doaction_entry", "861091ea8129f8f66132c3db74eb69eaa50ab1760c59c45f2100f02ae2bcd4c5," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
