_root.aiEvent("doaction_entry", "76bf93f4602983628bcce6c7f39a4012050b341a23840489d087f823c5b2dfa1," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
