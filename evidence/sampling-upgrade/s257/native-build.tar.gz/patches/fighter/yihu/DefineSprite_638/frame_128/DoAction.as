_root.aiEvent("doaction_entry", "8dcb03377e3576052f0b9f19248ce767bbecec53d50f2e6f13e5ef169de41960," + escape(String(this)) + "," + _currentframe);
khit = 1;
动作 = 1;
