_root.aiEvent("doaction_entry", "208e8147a6d754b410fc647734b4bdda562313f8855586f82fa6493a66c2a982," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
