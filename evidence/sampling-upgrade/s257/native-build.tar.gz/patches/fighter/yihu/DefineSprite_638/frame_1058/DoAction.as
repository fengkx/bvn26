_root.aiEvent("doaction_entry", "6ed09a24fdcdb05e5aee58ac835f68d094f95f569106c6a23173b44cddad2e50," + escape(String(this)) + "," + _currentframe);
trace("hz");
