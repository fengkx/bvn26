_root.aiEvent("doaction_entry", "07177775fccf1c8ad521739d60f459a68bd791067824873c0ac6ebf9a8ddcee9," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
