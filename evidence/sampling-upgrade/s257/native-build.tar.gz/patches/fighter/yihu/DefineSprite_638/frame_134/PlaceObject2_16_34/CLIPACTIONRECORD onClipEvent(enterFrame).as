onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "15a21b603ea2f386f017188a2027137e58d43410c36c9fd7f9c028b32e38ad72," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      if(moveLeft())
      {
         _parent._parent._x -= _parent.speed;
      }
      if(moveRight())
      {
         _parent._parent._x += _parent.speed;
      }
      if(airMagichit())
      {
         _parent.gotoAndPlay("跳招");
      }
   }
}
