onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "836a495aa5e42aead7bf12cce8c73b508f15188ffb56146111ed1ee69dbb8b37," + escape(String(this)) + "," + _currentframe);

   if(gameRunning())
   {
      doAllAction();
   }
}
