_root.aiEvent("doaction_entry", "760e5ed9734896d018c3b3e99460b082273987b021fc8d154297a73754e879e6," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
