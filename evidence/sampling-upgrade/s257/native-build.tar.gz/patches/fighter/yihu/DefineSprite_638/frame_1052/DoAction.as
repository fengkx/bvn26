_root.aiEvent("doaction_entry", "55c80c47f452616727c30093f0762fe57ac6a756dfa20a091d6128067a8096e9," + escape(String(this)) + "," + _currentframe);
wankai();
