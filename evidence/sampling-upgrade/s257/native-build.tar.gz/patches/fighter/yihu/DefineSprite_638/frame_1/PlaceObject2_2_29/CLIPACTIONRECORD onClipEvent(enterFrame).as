onClipEvent(enterFrame){
_root.aiEvent("clipaction_entry", "419041ec6f957ed818305813813a020634dd3151a04b4090ea1a279de51a682d," + escape(String(this)) + "," + _currentframe);

   beida();
}
