_root.aiEvent("doaction_entry", "32e87b8a0263312d6d19969b090d8bb7a1dba4c818c2fef49456b1e658a2ef32," + escape(String(this)) + "," + _currentframe);
_parent.gotoAndStop(2);
