_root.aiEvent("doaction_entry", "6a489816919d3d7b1a3afd40a5026e0b88a09edb35203bcee55869d296ec9e70," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
