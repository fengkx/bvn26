_root.aiEvent("doaction_entry", "280e6396ef4a199a2882c285cf87fea477cf96cf830be2f2fa9e54cddc1040d8," + escape(String(this)) + "," + _currentframe);
_root._y -= 5;
