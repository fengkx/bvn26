_root.aiEvent("doaction_entry", "4b420f4436c74b7ceb090be14a4558a4aa75ceded443d5b85aa61d13483ba65f," + escape(String(this)) + "," + _currentframe);
_root._y += 3;
