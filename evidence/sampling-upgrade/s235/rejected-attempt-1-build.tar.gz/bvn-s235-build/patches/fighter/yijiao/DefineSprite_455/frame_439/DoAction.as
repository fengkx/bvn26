_root.aiEvent("doaction_entry", "4ffde9d0d4fd3158328016701e598d169594e9cd67f057e29d2abb4adb6979d5," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
