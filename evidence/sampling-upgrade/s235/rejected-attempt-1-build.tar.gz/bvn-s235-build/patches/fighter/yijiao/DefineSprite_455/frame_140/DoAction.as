_root.aiEvent("doaction_entry", "f4bc75067bb55612a92a182b6061301d6fc5f28da1b3db90ce6ba039e2b3711e," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
