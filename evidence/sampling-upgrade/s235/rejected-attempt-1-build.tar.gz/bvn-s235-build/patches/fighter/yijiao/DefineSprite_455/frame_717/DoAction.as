_root.aiEvent("doaction_entry", "cfa908a91d7c45af3e5a6439421606658aebd27d1e2fed7ab47c4f9d001d8154," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
bs = 0;
