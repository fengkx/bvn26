_root.aiEvent("doaction_entry", "7eb0eb00bf2838ba8bab984638aeb43c02b656b159ae94f93331b746b7cf4939," + escape(String(this)) + "," + _currentframe);
动作 = 0;
