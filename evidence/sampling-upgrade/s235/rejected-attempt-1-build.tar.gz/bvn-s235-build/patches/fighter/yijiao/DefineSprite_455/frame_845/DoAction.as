_root.aiEvent("doaction_entry", "613c7b2816ca7deea56bf80ebf254fa6a3a7c81a7f50f3e0e52437ed2334bb5f," + escape(String(this)) + "," + _currentframe);
hited = 0;
play();
