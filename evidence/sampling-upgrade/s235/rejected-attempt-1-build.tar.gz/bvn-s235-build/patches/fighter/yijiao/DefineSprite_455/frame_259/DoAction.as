_root.aiEvent("doaction_entry", "e1c492810c91f5da6913e36df3cd143e6b688e07a0ad995edfd495e3366da694," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
