_root.aiEvent("doaction_entry", "5f83562655a6c009e2fb93ee375c8b76c39287b51007340e164ee3aba1b7edb8," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
