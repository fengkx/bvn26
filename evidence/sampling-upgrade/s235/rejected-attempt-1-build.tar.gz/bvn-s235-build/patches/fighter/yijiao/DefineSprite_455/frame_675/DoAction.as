_root.aiEvent("doaction_entry", "b19bd771c642ba5b6981348bd4b6ea2b7325818318dcfb878e0301a319881776," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"一角2");
