_root.aiEvent("doaction_entry", "665b297c55b150f12f04cf3844e378bdd9f408fc7c670ca668cce0c3c38bf528," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
jump = 1;
