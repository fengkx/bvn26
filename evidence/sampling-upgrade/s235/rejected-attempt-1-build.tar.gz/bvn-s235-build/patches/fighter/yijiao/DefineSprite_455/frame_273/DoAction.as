_root.aiEvent("doaction_entry", "f2511104b736c27481a5e9f9c53b764994219984bf84884bb8a720ce23fec0a4," + escape(String(this)) + "," + _currentframe);
动作 = 0;
