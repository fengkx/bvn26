_root.aiEvent("doaction_entry", "fae0703c02d6089d40d093f47d80c41ac602827ae9f066d4359a48770e03acd3," + escape(String(this)) + "," + _currentframe);
stop();
