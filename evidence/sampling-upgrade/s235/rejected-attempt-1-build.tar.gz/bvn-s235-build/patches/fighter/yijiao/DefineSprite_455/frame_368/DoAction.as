_root.aiEvent("doaction_entry", "efb7c2b45018159151cda9f5588854611ad2c30dae912b3520392e6502c9501e," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
