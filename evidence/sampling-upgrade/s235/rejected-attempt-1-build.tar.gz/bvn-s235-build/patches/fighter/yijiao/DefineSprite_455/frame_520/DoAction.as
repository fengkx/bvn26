_root.aiEvent("doaction_entry", "2c2341b7e8fd728376431846f2eb77e4371f42ce607877b83870332622058712," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一角1");
