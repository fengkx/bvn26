_root.aiEvent("doaction_entry", "3d4167bd95a5a10ce85157b4af1f0889af41c8c012413fe4e9da0ea78d9fd404," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一角1");
