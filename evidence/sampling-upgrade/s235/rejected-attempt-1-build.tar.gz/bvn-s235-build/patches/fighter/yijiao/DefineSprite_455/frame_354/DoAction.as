_root.aiEvent("doaction_entry", "461f1d5a6081a4041e74c18b441f2c1950caef679877b04c58279e75e8c8fe44," + escape(String(this)) + "," + _currentframe);
动作 = 0;
