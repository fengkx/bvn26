_root.aiEvent("doaction_entry", "09efd09c40fb188fd06d09ec45d4eea8d6a1a9baae50ebdedab949250ddd3146," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
