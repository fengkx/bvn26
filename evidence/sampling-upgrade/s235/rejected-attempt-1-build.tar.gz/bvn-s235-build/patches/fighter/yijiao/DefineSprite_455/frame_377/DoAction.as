_root.aiEvent("doaction_entry", "d53b253b30c6a249b5195809df26cb3acfa5cf940478b87c1ffeab30e350c090," + escape(String(this)) + "," + _currentframe);
动作 = 0;
