_root.aiEvent("doaction_entry", "ba3a43c9bf49b5e39afb271c526c776c10d58dec07b3384ec06cc9f5335625be," + escape(String(this)) + "," + _currentframe);
动作 = 0;
