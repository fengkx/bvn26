_root.aiEvent("doaction_entry", "d8249f1d8c2748edfc23549ca906e328df1af27dc8b6f4bf2ed2980ad4193603," + escape(String(this)) + "," + _currentframe);
play();
kcplayed = 1;
