_root.aiEvent("doaction_entry", "03e0e49891eb23092152fbd730be30c127fdd9bd28b9d61f08499d0a3c78e97e," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
