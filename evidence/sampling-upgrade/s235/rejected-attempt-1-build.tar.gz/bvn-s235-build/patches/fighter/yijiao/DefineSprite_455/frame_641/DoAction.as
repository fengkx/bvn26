_root.aiEvent("doaction_entry", "bc5efd4891c2a065d57abaccdebf3998b7348be0f190ac0338fd82f8a16058a9," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
