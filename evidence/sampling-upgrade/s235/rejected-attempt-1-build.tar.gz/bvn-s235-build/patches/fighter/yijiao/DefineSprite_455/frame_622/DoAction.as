_root.aiEvent("doaction_entry", "b037d2c7790d2da47847389ba99aacc5bd60ce6c03ba4ff6a525caa404269253," + escape(String(this)) + "," + _currentframe);
动作 = 0;
