_root.aiEvent("doaction_entry", "ebf2ffdf6ad7fda3220cdf140d80c69b06c15471d52795ef5a69d09e948e5321," + escape(String(this)) + "," + _currentframe);
_parent.moveX(150);
