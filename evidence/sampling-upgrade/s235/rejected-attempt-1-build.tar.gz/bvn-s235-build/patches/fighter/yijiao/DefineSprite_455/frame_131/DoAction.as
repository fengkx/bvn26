_root.aiEvent("doaction_entry", "72b5b219042a680055fe1586d300a5e5ce2026ad38a66fa1c583db8366f417ac," + escape(String(this)) + "," + _currentframe);
_parent.moveX(5);
_parent.moveY(5);
