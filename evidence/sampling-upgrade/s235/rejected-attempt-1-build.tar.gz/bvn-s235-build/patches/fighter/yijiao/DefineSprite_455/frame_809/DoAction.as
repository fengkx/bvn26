_root.aiEvent("doaction_entry", "95a638eb29253fa0c25bc0d3c002e88422ec645bd5ebc6d6e353d4ffd27688fe," + escape(String(this)) + "," + _currentframe);
动作 = 2;
