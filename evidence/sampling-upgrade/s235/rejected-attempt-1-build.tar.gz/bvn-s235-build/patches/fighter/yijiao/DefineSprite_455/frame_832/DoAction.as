_root.aiEvent("doaction_entry", "4fde3dce5d433cbda57bcbf2c9092e6f1bff288ea9ba52b800f2d06c4617e1af," + escape(String(this)) + "," + _currentframe);
play();
