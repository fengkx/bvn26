_root.aiEvent("doaction_entry", "410c06a5132f85379ec8dfe1d988b7be76a881d9653d75ea962af7870990f7fa," + escape(String(this)) + "," + _currentframe);
kcplayed = 2;
gotoAndStop("站立");
play();
