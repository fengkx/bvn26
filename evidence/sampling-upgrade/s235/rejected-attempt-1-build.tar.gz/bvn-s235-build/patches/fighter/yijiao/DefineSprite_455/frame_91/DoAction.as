_root.aiEvent("doaction_entry", "bfea0e716968497c356fcdac0830e2ea073f98296f79b363ec24f1a2d0589e3d," + escape(String(this)) + "," + _currentframe);
jump = 0;
