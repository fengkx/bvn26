_root.aiEvent("doaction_entry", "1750432d0b0063a087095557c955f02b0c45b1f8625981d5e904245d6a3d9aff," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
