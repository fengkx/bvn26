_root.aiEvent("doaction_entry", "3ef075077b7aac5b95901f066db5877bedf194634c412329bde530014266f2be," + escape(String(this)) + "," + _currentframe);
khit = 1;
动作 = 1;
