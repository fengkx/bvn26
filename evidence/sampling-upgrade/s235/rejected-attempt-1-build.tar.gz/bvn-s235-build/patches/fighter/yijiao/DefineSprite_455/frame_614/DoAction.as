_root.aiEvent("doaction_entry", "8556e9c384c9ff8f6742d7b0e91d3fdfc499802542cd30c1d9e0ff5438db3e07," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
