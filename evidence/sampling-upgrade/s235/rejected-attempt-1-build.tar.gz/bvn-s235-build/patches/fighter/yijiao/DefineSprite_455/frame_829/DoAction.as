_root.aiEvent("doaction_entry", "892be04aa6ff56b688e1d0e9bd920fdf8a766c6deb272a14790c87becc5ac480," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
