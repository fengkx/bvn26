_root.aiEvent("doaction_entry", "e6d7283cc5ecea32e6871ddbe6236b639eed5c2d3748f8f2342111cd04994def," + escape(String(this)) + "," + _currentframe);
_root._y -= 1;
