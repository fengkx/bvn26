_root.aiEvent("doaction_entry", "841aa56c90c8dde37388289092f4e0cde91bb3106afb35398a861a6a074b586d," + escape(String(this)) + "," + _currentframe);
play();
