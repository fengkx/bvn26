_root.aiEvent("doaction_entry", "ded577b5e04f6745493f526c662be1c0377d8dbc53b46fbd078d6066f28a772f," + escape(String(this)) + "," + _currentframe);
_root._y -= 4;
