_root.aiEvent("doaction_entry", "3fc46327dfb041ff8121d53f81511ad545fb0e55840961b16838d9a3fdbbcf40," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
