_root.aiEvent("doaction_entry", "49d9ed88948cf83240f30b5f95ccf3fce1d75632ce457eb7899ab0c7e21270cd," + escape(String(this)) + "," + _currentframe);
khit = 0;
jump = 0;
