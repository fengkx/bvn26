_root.aiEvent("doaction_entry", "fc2ff66952e04a19b4098c04596e2843f4b7d0ceae1b0d50178296e21ce8b389," + escape(String(this)) + "," + _currentframe);
play();
