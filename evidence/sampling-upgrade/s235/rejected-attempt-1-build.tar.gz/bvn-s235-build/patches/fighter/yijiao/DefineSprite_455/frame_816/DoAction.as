_root.aiEvent("doaction_entry", "f26f931ff38d930b31c3daee5714536024bd84ae14139c6e70556caaa44a5c3f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
