_root.aiEvent("doaction_entry", "731cb82caa7794fa59e1065dcce934bf9c9cfad88ac747e315acd67327b5327b," + escape(String(this)) + "," + _currentframe);
动作 = 0;
