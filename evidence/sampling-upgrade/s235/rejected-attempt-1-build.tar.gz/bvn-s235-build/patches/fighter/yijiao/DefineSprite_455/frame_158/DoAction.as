_root.aiEvent("doaction_entry", "67f148eb9b505c2455fb0876426757e900ce6c0f5f98b92cfebe5afebc06b9b3," + escape(String(this)) + "," + _currentframe);
gotoAndStop("跳招0");
play();
