_root.aiEvent("doaction_entry", "ff9b0e583ab0af2d13009b0b47c47e9d8601017d633724014fb7daff835f2e07," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
