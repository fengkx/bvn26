_root.aiEvent("doaction_entry", "591d7326208b29a387aaa13b2a98fe9cb0da673044154daa30dc52100e1fc575," + escape(String(this)) + "," + _currentframe);
stop();
