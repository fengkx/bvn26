_root.aiEvent("doaction_entry", "78bdec4be3049a90d6b29e03adf6ea83b0e7f66bbe61be1b8a437da056a6d035," + escape(String(this)) + "," + _currentframe);
doZhaoHuan();
