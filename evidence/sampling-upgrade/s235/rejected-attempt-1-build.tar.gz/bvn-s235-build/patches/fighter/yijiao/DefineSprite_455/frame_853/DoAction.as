_root.aiEvent("doaction_entry", "5fe211068ab1ca330adf42d011de4400a93f20d1242082eae1d6523877c7a60e," + escape(String(this)) + "," + _currentframe);
stop();
