_root.aiEvent("doaction_entry", "fcadd5d3e5231c5a6e1f171e194c214fdd20b109b04cfa9a88bf74dd7c15df36," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
