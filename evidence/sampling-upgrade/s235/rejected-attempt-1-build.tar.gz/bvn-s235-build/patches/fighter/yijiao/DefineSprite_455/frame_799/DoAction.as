_root.aiEvent("doaction_entry", "050dc44e60ccc629b87829c4ccb43848a145d99349a47ba074698b8ce55b13f6," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
