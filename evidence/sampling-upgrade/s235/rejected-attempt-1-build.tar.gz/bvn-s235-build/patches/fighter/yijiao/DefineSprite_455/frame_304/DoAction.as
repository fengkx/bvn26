_root.aiEvent("doaction_entry", "f25d92f0a65df8bcdf4c903020ff02c31b268fcd206c02cbaf72f92706b90585," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
