_root.aiEvent("doaction_entry", "71168189298978679f8454542ca47d4acb984aef7917d63d15f2ff7564dc0587," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
