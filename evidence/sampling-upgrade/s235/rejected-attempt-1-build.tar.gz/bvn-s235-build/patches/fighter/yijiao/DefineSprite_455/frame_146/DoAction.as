_root.aiEvent("doaction_entry", "bd306b8c7e5471601f37574080dd70f880e5763d4c7603a8e07a73e361f4bad0," + escape(String(this)) + "," + _currentframe);
khit = 1;
动作 = 1;
jump = 1;
jumped = 0;
