_root.aiEvent("doaction_entry", "836984e430682f9dc93b17873e34fd46e9585eac85813a26789f8c37f1c78429," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
