_root.aiEvent("doaction_entry", "3762b0a7c30cbb3cb077c07c1032a0789ada04e56f90ddd409ada84cc039f1d4," + escape(String(this)) + "," + _currentframe);
jump = 1;
jumped = 0;
