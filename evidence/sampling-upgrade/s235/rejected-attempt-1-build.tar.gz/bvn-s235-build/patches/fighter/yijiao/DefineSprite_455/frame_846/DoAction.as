_root.aiEvent("doaction_entry", "771685e30b3b34fc7a23ae2e43162823e650f52d51d24e68375a1b96f7fa1022," + escape(String(this)) + "," + _currentframe);
onBeHit(true);
