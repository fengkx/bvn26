_root.aiEvent("doaction_entry", "734603db4d7253f8e55b29ce61acccf7d2b1db790fdd8965ad94e80aa341e762," + escape(String(this)) + "," + _currentframe);
动作 = 1;
