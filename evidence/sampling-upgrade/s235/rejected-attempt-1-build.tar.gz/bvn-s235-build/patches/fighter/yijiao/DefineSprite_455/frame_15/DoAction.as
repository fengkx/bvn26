_root.aiEvent("doaction_entry", "d1f8df7c0aff6298126208b2fb9846f6873d73cfba682e91d84c34996653a64a," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
