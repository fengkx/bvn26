_root.aiEvent("doaction_entry", "cf4f97b3b9f392b37954b33188bc407ad2aebd9a20e8e7b8353045fc2aba74d7," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
