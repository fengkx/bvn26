_root.aiEvent("doaction_entry", "8f41721c8ade9c258db35eb7cd62bf674b7f949c21bf7b08ba0858c6f1be575d," + escape(String(this)) + "," + _currentframe);
_root._y -= 3;
