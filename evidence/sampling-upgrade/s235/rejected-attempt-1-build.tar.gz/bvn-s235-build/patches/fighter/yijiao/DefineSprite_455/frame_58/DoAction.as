_root.aiEvent("doaction_entry", "55f5dd7040cf37b6d4e42f84191d81e6dcfe76b884214cf551ada6827df13cd2," + escape(String(this)) + "," + _currentframe);
jump = 0;
