_root.aiEvent("doaction_entry", "d891efa43cac17ecc298ff49798ae754408a4e52231c3def57c2b2f323570a0d," + escape(String(this)) + "," + _currentframe);
_root.shine();
