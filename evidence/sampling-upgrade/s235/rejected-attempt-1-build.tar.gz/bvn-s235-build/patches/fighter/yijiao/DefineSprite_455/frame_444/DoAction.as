_root.aiEvent("doaction_entry", "f86d37824566a428f40cfc0622da407164d1adf264cb46ecc8fc1723b5e72dfb," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
jump = 1;
jumped = 0;
