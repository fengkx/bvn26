_root.aiEvent("doaction_entry", "2627cdfe5e2d49780a010b533f340071ac2795f475494d9d96fca0140af5dce5," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
