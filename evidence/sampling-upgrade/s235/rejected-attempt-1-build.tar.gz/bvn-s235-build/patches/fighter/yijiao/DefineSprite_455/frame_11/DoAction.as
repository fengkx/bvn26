_root.aiEvent("doaction_entry", "b68d1056d52ded2b7c03af5c3d40cf3cec5bb4f1b049b31dd97dadee898d8243," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
