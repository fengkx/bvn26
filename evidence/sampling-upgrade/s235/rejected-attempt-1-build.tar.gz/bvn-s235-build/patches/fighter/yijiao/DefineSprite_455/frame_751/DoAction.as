_root.aiEvent("doaction_entry", "53341714bf7177c0d591cb2e59260dba479bda0c80c5c2ceda3813fddb7f4221," + escape(String(this)) + "," + _currentframe);
动作 = 0;
