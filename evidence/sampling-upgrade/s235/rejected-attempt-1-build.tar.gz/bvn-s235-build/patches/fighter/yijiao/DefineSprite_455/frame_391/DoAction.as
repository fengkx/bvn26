_root.aiEvent("doaction_entry", "94b3f8344919d343077dfbe65cc71eca25d7bfca4787af3274b4643466572383," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
