_root.aiEvent("doaction_entry", "fda98bbf5acff8fdb415efdd392be98903e5fd5a0bb29df45c7247830fbe9ab0," + escape(String(this)) + "," + _currentframe);
动作 = 0;
