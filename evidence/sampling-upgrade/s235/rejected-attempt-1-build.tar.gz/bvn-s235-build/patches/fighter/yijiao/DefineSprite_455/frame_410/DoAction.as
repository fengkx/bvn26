_root.aiEvent("doaction_entry", "b863601a948565b179d0919ae0c0f435ff57ec028e695214a6a2f605fb3c937e," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
