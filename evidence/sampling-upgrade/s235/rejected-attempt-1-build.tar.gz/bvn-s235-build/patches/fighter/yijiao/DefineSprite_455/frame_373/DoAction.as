_root.aiEvent("doaction_entry", "6c82268de4d0edafc7d3aca87e44748c2a2abbd9f4383ef5216682b77fc2fd40," + escape(String(this)) + "," + _currentframe);
_root.shine(16776960);
