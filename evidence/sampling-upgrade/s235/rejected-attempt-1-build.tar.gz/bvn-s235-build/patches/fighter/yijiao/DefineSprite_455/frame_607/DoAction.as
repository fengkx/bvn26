_root.aiEvent("doaction_entry", "1b890222566951c2957557b886d3e8fd779ea3ceff9218db1c7a1a7c88a88b66," + escape(String(this)) + "," + _currentframe);
_root.shine();
