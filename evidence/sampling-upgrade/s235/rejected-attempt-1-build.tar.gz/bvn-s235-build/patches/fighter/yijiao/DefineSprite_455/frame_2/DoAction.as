_root.aiEvent("doaction_entry", "3dd8205dbd122cbb27b046f3e4373c058acf8566f40bbc722f59371b8d176dc4," + escape(String(this)) + "," + _currentframe);
hits = 0;
