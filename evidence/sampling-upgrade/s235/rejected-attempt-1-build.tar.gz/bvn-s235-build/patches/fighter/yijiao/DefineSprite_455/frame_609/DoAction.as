_root.aiEvent("doaction_entry", "f651155a92d76bbbed4de4f45b51735386770a64632cc7dd9f777f5046a7ffdc," + escape(String(this)) + "," + _currentframe);
_root._y += 5;
