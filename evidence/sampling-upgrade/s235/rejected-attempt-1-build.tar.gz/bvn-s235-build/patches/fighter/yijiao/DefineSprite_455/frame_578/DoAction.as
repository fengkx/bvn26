_root.aiEvent("doaction_entry", "f8754a908fd3cfe987956eeeed1f72deb8e668e938afbe5c8015cc2b564fcd0d," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
