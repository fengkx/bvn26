_root.aiEvent("doaction_entry", "29ab3a4b1ef86ecc1c7a6d385e50b32cd10a713342cb3955cafbb3fdfc8edb98," + escape(String(this)) + "," + _currentframe);
kcplayed = 3;
