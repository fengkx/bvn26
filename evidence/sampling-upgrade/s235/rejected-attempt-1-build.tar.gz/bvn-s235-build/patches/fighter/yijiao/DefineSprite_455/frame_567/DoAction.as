_root.aiEvent("doaction_entry", "810707500fdc8916427e482f20e644c597a66a411bdc0b365f9fb9810c9ddfbc," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
