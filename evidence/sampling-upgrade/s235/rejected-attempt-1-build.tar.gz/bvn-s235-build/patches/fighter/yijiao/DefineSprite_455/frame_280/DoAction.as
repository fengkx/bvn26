_root.aiEvent("doaction_entry", "2a8b648cac44d65e0e1039c691dbe675fbb4ff53b042f4d83cc88ad5f5c47651," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
