_root.aiEvent("doaction_entry", "dadd0640873a0a02146cb1278f16a00b6f05c22e24c8eab6227c6437ad0b76b3," + escape(String(this)) + "," + _currentframe);
jump = 1;
