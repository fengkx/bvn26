_root.aiEvent("doaction_entry", "4b269f526a056e2268a1f6fe8a9163c9674cf680fe6e4163676679335d41c861," + escape(String(this)) + "," + _currentframe);
onDefence(2);
