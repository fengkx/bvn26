_root.aiEvent("doaction_entry", "3aa2e9d82150fe013e747fc209172eaa7d1ce8ffc0e5a5168393ffccefb5360c," + escape(String(this)) + "," + _currentframe);
jump = 0;
jumped = 1;
gotoAndStop("站立");
play();
