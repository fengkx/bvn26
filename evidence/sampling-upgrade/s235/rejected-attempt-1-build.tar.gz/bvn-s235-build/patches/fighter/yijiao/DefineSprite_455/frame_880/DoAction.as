_root.aiEvent("doaction_entry", "17456459b29263f6c28158ef7aed7f70ea95d130d1b1a3ccd587ffec159ba1ab," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
