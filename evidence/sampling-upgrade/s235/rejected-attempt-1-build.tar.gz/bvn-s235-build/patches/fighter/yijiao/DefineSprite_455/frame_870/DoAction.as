_root.aiEvent("doaction_entry", "7994db1090582778ea81d3237164f8130bc6b4c41cc02a0630951e3038a67d85," + escape(String(this)) + "," + _currentframe);
if(sw == true)
{
   stop();
}
