_root.aiEvent("doaction_entry", "404c3a37e0cdce9c9e2a5ff97198557caf1a1144717658c44451f26868e78584," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
