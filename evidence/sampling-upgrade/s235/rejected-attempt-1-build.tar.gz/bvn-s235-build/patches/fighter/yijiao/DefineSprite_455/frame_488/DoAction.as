_root.aiEvent("doaction_entry", "ae49fb1ee5e7bb58a6b2e3e1a15a9fbb55d8d4e982de8b1622d13995f912cb69," + escape(String(this)) + "," + _currentframe);
_root.shine();
