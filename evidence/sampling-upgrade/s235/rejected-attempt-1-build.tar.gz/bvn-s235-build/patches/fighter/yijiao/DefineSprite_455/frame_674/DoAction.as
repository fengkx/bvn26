_root.aiEvent("doaction_entry", "6b77f3835293074ac29b5b40b25bccbf8abb5a4ffca545b5b54d0cc1303de2d4," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
