_root.aiEvent("doaction_entry", "ae127bd73f418ca2b6a226b9d4eccd0e0f36b525f732e5b7aff3984b76928286," + escape(String(this)) + "," + _currentframe);
动作 = 0;
