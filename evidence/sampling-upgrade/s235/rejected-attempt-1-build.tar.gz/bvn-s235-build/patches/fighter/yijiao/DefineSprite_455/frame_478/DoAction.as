_root.aiEvent("doaction_entry", "7939d02e2969d043a215ed7cb6e12bda286409653783970d03424ac07d5c2a39," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
