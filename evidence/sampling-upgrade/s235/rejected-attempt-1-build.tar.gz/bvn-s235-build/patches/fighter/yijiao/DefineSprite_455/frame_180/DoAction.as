_root.aiEvent("doaction_entry", "d88e9dd8afd6ddb479d19e8829fd09f4e9604a7fbfb8ebe8c51069e88a7e6aea," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
