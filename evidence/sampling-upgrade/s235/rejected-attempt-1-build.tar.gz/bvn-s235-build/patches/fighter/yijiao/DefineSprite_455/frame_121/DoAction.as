_root.aiEvent("doaction_entry", "257fce063b2cc3b4cf11a92f18e80054d50611b0715c14382a561170063d73eb," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
