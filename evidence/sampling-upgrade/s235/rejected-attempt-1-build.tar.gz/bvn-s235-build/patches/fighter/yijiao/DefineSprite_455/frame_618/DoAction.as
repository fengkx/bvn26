_root.aiEvent("doaction_entry", "718600771e81c33b6a129f434f4d8c7ee70ad8e32639d13c1e107b2141c203a9," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
