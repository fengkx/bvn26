_root.aiEvent("doaction_entry", "33a1007d6119feff9a1adf9b7eea50f0c6e1bc50bb90ec1b30b197eb31e8bd6e," + escape(String(this)) + "," + _currentframe);
stop();
