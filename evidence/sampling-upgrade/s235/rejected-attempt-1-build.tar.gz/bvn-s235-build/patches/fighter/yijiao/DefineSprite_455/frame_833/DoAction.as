_root.aiEvent("doaction_entry", "e54d7bc4398d2019822d3f387d197621bf2ca41359e1d8b7e4e44d46746af840," + escape(String(this)) + "," + _currentframe);
onBeHit();
