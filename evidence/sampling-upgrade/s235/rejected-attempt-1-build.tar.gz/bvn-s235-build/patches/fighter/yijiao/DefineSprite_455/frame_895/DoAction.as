_root.aiEvent("doaction_entry", "8f566b66d583f118c1c25a653af44a819160bebb49b48d9f0800e299b4bcdf72," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
