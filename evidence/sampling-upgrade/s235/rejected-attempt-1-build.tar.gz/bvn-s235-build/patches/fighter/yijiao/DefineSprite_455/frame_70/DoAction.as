_root.aiEvent("doaction_entry", "9e71edf5e7ae99c57e82fb6625e996b8b1b265769e60521a0e606f3b395119dd," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
