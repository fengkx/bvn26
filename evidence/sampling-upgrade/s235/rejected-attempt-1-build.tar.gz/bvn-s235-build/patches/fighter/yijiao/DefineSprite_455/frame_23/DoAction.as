_root.aiEvent("doaction_entry", "4eb6ce5dc9f914715f3a9a4039b9b6b634e31f82e3b7ae8e574d1640b0e0a3f7," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
