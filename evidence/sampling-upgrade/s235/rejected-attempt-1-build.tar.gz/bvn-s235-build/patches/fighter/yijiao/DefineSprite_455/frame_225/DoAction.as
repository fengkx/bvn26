_root.aiEvent("doaction_entry", "aee4d0214b70f6e075efcb9b992c677a38b897f6270412ddad3c1302303ff710," + escape(String(this)) + "," + _currentframe);
动作 = 1;
