_root.aiEvent("doaction_entry", "6742e7cabee06c7035e8b12e9095819b5976e27be97d5bab296e3773fad2064c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
