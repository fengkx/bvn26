_root.aiEvent("doaction_entry", "a12945c1f75c418339137bf3021fe81f31de81a717eb03054608eef207d83adf," + escape(String(this)) + "," + _currentframe);
动作 = 0;
