_root.aiEvent("doaction_entry", "15380d0ee808180ae9dbb6bd717c4d0bba3c39ad8b6f75ea6878f63882d6362c," + escape(String(this)) + "," + _currentframe);
_root._y += 1;
