_root.aiEvent("doaction_entry", "6e4fd41ec943249c7b9c2d6013c3766bccc64eb773bd200af200ac4a4f74c0b9," + escape(String(this)) + "," + _currentframe);
stop();
