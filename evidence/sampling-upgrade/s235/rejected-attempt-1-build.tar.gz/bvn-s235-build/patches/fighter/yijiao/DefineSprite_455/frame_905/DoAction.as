_root.aiEvent("doaction_entry", "3e13a84f792a30a3a06f53232110d60cff6fe5f4c4fd70c48de11d393bd51e84," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
