_root.aiEvent("doaction_entry", "4f88d70b40da9dfe91da74e6d855c5cf2506d391ce699cfa5bd8457dd256f7ee," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
