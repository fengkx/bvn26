_root.aiEvent("doaction_entry", "c63e00ef9fbcacbb820a04386218bba86acd0aa11214c5c3dc4c660e85340e5e," + escape(String(this)) + "," + _currentframe);
动作 = 1;
