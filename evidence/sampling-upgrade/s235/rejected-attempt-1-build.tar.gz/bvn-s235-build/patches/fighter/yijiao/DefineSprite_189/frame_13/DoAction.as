_root.aiEvent("doaction_entry", "bea1c14c375c4e47c2f59b193a5dfde24d776b20e105f85fbc8c377dd78efe0b," + escape(String(this)) + "," + _currentframe);
stop();
