_root.aiEvent("doaction_entry", "847dcf8cbb00b1c789bcec79ea9de9a09169b17d185d8a4d750ced482a933e80," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
