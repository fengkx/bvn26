_root.aiEvent("doaction_entry", "da0fe0432fac1bfdaf9f0360b7ea859dae0ca75676199e195d714152b20dbeb6," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
