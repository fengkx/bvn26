_root.aiEvent("doaction_entry", "e033603cc0c9bfdd110b4fb08777516015826faec0b1a00e366f0994d75c206f," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
jump = 1;
jumped = 0;
