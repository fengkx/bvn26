_root.aiEvent("doaction_entry", "0e18a00b11a40339575fe205dfae004ca8ba592e370d022ebf5e1baf8edf62a6," + escape(String(this)) + "," + _currentframe);
stop();
var movspeed = 18;
var played = 0;
