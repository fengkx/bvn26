_root.aiEvent("doaction_entry", "8bdb7b537577c32fc2720811e9c3307f308c8e6e6e6bfad136535b848a7d7968," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
_root.shine();
