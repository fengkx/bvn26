_root.aiEvent("doaction_entry", "4f4d20bb88b8048f41803ae9eee372829f30b2e3ee7a585485d0935ce56b580a," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
