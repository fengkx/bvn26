_root.aiEvent("doaction_entry", "68dc5a97322e5b076d120b6cb9762a4488d5cdb200f47b115dd6ff7e477463c6," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
