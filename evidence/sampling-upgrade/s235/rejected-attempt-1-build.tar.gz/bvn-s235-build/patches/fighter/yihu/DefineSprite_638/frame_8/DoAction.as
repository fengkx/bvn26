_root.aiEvent("doaction_entry", "10328054b7623c1431745ee1f00f599dabe10ba17b3f93dbb42082b1ea8e071f," + escape(String(this)) + "," + _currentframe);
_root.aiEvent("intro_body_enter","8," + _currentframe);
gotoAndStop("站立");
play();

_root.aiEvent("intro_body_exit","8," + _currentframe);
