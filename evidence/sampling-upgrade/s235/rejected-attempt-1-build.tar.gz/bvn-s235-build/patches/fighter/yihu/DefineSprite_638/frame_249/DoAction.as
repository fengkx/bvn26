_root.aiEvent("doaction_entry", "07fa225b6034d2ab45f4768bcd6a66e8b0c1d62107093241ea499f334ee8be62," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
