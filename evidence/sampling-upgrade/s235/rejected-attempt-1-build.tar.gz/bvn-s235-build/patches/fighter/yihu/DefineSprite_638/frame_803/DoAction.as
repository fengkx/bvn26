_root.aiEvent("doaction_entry", "32673fc6a5b74907d1e6644ec22edceccf47f9d7c1cb805dadcefc10e2b33e71," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
