_root.aiEvent("doaction_entry", "525ce7e6a1b90a31877c52bf542b995b2b7d02aa016d99430d515dcb504d806f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
