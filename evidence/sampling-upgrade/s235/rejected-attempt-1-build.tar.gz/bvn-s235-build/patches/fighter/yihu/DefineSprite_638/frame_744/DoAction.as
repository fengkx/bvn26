_root.aiEvent("doaction_entry", "3c21470ae3bce14781542f639a87b319c70e79967fa9e8f2b42ba5571498a877," + escape(String(this)) + "," + _currentframe);
stop();
