_root.aiEvent("doaction_entry", "13430452c0cc8842233112b02788d36de03c94cfabe9605bd99576a35bf1fa79," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
