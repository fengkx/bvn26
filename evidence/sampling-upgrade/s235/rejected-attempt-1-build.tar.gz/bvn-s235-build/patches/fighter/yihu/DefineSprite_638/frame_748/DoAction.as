_root.aiEvent("doaction_entry", "495b0d6e2501ffc765e092d0a702c9ca0ccb7717d5638c0901764f7763236b16," + escape(String(this)) + "," + _currentframe);
jump = 0;
jumped = 1;
gotoAndStop("站立");
play();
