_root.aiEvent("doaction_entry", "1ce172dd872790676e90aea28fa6d86d2daf0f68c6826523d74cf6468e2ac3f8," + escape(String(this)) + "," + _currentframe);
jump = 1;
