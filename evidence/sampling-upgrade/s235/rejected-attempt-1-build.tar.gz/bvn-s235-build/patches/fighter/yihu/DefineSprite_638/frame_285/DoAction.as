_root.aiEvent("doaction_entry", "603c91855195dca252b765bd8cc78727c679a14cd81e2d8b4937b8e9a37a837e," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
