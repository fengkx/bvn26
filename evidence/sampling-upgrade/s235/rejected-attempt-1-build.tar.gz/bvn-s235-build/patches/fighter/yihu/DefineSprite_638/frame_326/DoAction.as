_root.aiEvent("doaction_entry", "9d88de39bb591a9881e6fbd012d567188ad2a14b02d666b7c78e39d5967ba47d," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
