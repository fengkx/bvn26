_root.aiEvent("doaction_entry", "db7d0d77d6be311863f137f3afaacde66aedf0e8e9250933bbb040b371fd27f8," + escape(String(this)) + "," + _currentframe);
wankai_start();
_root.showFace(pn,"一户万解");
