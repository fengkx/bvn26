_root.aiEvent("doaction_entry", "00962984380892a2c99b282d2fac0351a99cc26a12ca4f074036f689d474e7e9," + escape(String(this)) + "," + _currentframe);
hited = 0;
play();
