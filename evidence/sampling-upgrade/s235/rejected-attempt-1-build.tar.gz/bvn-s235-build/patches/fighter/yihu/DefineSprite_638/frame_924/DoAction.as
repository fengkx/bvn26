_root.aiEvent("doaction_entry", "d70823b69da52e630338bac8a83207a3c0167db49136e728085e723f8b6247a4," + escape(String(this)) + "," + _currentframe);
stop();
