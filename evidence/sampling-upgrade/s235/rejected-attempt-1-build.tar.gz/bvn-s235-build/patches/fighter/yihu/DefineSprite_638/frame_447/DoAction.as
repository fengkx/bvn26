_root.aiEvent("doaction_entry", "0cd5661badeb0151d5daee18dd8b047ace3b31a3ae8e106467b335f2a2f731e9," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
