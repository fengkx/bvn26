_root.aiEvent("doaction_entry", "2950590e7b9378e8d6e8bb8c8b5b7266035c93cde9bc786fd8ab9f1625af7cb6," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
