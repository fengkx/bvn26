_root.aiEvent("doaction_entry", "ba6efe748bab687f5bdc7eff68066965ae0449f19041fd6a662d2625fe426282," + escape(String(this)) + "," + _currentframe);
动作 = 0;
