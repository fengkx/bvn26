_root.aiEvent("doaction_entry", "ab0fcf516f491a359e9198785cfd44c75065aaaaa808ed7249d87938e77e68fe," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
