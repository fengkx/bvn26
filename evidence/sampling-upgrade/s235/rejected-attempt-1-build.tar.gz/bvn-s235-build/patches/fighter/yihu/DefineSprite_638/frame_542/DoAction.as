_root.aiEvent("doaction_entry", "b21382ef71b02978e894bd6eca0c84666f53b16636ace143cbe91e7f80ca33f6," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
