_root.aiEvent("doaction_entry", "0ad9bcea68a69d1aa28212091175e4825da37500c78e03f9cf8af87c8871ca26," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
