_root.aiEvent("doaction_entry", "bff6ea27abc2db190a17cc293ae7de85a9d2390112fca9b9ec0538c56e5cf903," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
