_root.aiEvent("doaction_entry", "92b3f5e049b9963207f8f85209fd21f5710f88a4f9f78bf7a5868551083ff5ea," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
