_root.aiEvent("doaction_entry", "33a2fd7ea2a3711a0ab996a08e8ed46f266ab6ee18928962972a493a2bfbf487," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
