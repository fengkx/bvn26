_root.aiEvent("doaction_entry", "35f18aa71b513e4b795197f536e69c7cf7acec66ffebe0a136c0834810908259," + escape(String(this)) + "," + _currentframe);
_root.aiEvent("frame_state_enter","390," + _currentframe + "," + 动作 + "," + ql + "," + sw);
gotoAndStop("站立");
play();

_root.aiEvent("frame_state_exit","390," + _currentframe + "," + 动作 + "," + ql + "," + sw);
