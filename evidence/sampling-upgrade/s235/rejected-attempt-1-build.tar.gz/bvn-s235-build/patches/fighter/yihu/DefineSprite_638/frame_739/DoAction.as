_root.aiEvent("doaction_entry", "9c45d564fb54f3c96e4e909ca9da924c1518a55b304ccfde46657577645ee98b," + escape(String(this)) + "," + _currentframe);
onBeHit();
