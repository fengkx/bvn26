_root.aiEvent("doaction_entry", "cd4835433428506004d5fd7555da79a6eacb37da6f0d85410691d439c13cae73," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
