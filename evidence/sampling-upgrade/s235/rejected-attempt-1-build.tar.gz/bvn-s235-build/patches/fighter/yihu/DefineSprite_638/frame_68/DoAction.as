_root.aiEvent("doaction_entry", "33ded3287845c09acd5aab7d4197fb1328f59f4d46b45ee08efa37de166773fc," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
