_root.aiEvent("doaction_entry", "def61ca99a12ec1c41539507744e420b5c70a64a4e4019003316d4e78e936111," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
