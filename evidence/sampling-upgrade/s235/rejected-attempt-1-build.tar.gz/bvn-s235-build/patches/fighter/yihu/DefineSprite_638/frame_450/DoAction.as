_root.aiEvent("doaction_entry", "49232b3f605474d9d36314eb8dbcd2b85094a1eec782c3933d4f68d4e0492265," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一户1");
