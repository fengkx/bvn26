_root.aiEvent("doaction_entry", "d51155df2e3758a13f0b91434c32012e181b8767464d5fe25a289d1601ea63e6," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
