_root.aiEvent("doaction_entry", "7fad284fa60d5a04749e4d99c48d68d0b58ba93fa069bbb69ad67a7f410a408d," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
