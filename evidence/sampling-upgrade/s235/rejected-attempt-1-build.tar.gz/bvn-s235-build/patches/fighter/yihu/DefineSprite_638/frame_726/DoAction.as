_root.aiEvent("doaction_entry", "481ae6b3a5660021b59601c579fe3ccced0f3ed2e56cf47d60d71db67a6555a6," + escape(String(this)) + "," + _currentframe);
play();
