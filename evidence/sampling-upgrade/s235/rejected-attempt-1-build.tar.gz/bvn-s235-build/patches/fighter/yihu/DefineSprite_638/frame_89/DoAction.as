_root.aiEvent("doaction_entry", "7cda47ec3ae6e8aaa9a0799337bb120532d4538ac13556bd085c0e00fc0ab595," + escape(String(this)) + "," + _currentframe);
jump = 0;
