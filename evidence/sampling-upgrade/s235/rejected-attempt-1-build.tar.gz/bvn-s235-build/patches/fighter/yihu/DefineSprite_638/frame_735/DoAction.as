_root.aiEvent("doaction_entry", "2732c0edaca4da7449bed82007e154c151b1aac119dd5bee5e64972ddc8a0b0b," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
