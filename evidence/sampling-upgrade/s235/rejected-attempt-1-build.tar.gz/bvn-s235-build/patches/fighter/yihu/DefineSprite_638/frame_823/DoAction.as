_root.aiEvent("doaction_entry", "136ef9145648f32137a2d55260a6a199f70fac5d41cdf7031e195c49e44fdf76," + escape(String(this)) + "," + _currentframe);
_root.aiEvent("intro_body_enter","823," + _currentframe);
kcplayed = 1;

_root.aiEvent("intro_body_exit","823," + _currentframe);
