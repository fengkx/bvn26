_root.aiEvent("doaction_entry", "8741fa7bbbe399e53141d449628c558ae070025631b627d5ce4cd72ff1ea9d89," + escape(String(this)) + "," + _currentframe);
onDefence();
