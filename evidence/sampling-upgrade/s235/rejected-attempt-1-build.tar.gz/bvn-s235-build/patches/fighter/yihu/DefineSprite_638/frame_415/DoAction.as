_root.aiEvent("doaction_entry", "468fc9cba37dbba3b5d420984c6be789b3e06f7abb863f4cd3022bba058841a8," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
