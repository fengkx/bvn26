_root.aiEvent("doaction_entry", "3313988f40209ff5c95ffd37fa0f5c00a9f86603eb97dd84da8cd0eb4078b251," + escape(String(this)) + "," + _currentframe);
kcplayed = 3;
