_root.aiEvent("doaction_entry", "f7296cac2af7a39e122fae83c35223b69b8b18243b4df4ec1cd183c91ab4a9cd," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
