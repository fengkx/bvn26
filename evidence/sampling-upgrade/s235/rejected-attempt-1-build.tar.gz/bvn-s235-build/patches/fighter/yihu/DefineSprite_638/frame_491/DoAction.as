_root.aiEvent("doaction_entry", "7168d304fe25f9820cc2ed1b5b93f5389869211fb36fec508c51914dc6a8f9a3," + escape(String(this)) + "," + _currentframe);
动作 = 0;
