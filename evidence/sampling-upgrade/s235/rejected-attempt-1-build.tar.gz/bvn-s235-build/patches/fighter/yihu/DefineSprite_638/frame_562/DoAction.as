_root.aiEvent("doaction_entry", "e344f5f38beb96fb78a3326797f743491815a684e10bf0c78855d6008ba945ab," + escape(String(this)) + "," + _currentframe);
动作 = 0;
