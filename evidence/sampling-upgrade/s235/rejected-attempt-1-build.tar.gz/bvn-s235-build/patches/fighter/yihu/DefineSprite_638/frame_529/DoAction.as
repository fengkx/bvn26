_root.aiEvent("doaction_entry", "5c9fdaf9b74df67621323a72de9eb40947e96655245b442f641493eeec011120," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
