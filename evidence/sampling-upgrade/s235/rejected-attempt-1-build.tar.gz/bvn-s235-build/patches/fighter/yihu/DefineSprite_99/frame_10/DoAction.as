_root.aiEvent("doaction_entry", "43fdd77ba68f486afdbe1a422c5c5bbe741f65614a6951b4853fabebb777771e," + escape(String(this)) + "," + _currentframe);
stop();
