_root.aiEvent("doaction_entry", "095cbc4840bf2a88349ce3c3f07ae196e7039c6771ae6e95ecac2858ef22ede4," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一户1");
