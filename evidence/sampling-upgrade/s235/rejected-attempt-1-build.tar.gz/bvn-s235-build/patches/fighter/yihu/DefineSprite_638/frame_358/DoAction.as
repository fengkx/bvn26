_root.aiEvent("doaction_entry", "1da99c7d94e35af8402c8d28bf514db407668f085a8725915f6ed549076b5146," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
