_root.aiEvent("doaction_entry", "63d0ccff39d90311fd3c945c1a34e214241629f0202a9786b8ea522744a0459d," + escape(String(this)) + "," + _currentframe);
jump = 1;
jumped = 0;
