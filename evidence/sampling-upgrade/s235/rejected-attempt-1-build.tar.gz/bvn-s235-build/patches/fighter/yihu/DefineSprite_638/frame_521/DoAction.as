_root.aiEvent("doaction_entry", "bbb59d08cf99aa4f4427ce2c16f9c3e9e91f3c6e5935c76f0bf64bee04580293," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
