_root.aiEvent("doaction_entry", "de56a5e79c602b4cb25d1e0a32b6d7e7410ffd249a7e60d13d9396bb3cd5d86e," + escape(String(this)) + "," + _currentframe);
doZhaoHuan();
