_root.aiEvent("doaction_entry", "5f3de0d302c8a85835279509e82f3a74d5f8c93d95ec75b1de4c8c9d344ba9ec," + escape(String(this)) + "," + _currentframe);
动作 = 2;
