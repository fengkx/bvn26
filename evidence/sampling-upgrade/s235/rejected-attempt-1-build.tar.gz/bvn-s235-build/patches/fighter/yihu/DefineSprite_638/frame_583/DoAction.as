_root.aiEvent("doaction_entry", "abf4a9aa6d908e36d55c39bd2e33850dfa22a4829daa27e4134ecfeb5a33bdc6," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
