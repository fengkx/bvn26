_root.aiEvent("doaction_entry", "754ea50659a98577eb8245f7dd20c88d7f716f5c0d0129b3cbd0f3c76433411f," + escape(String(this)) + "," + _currentframe);
jump = 0;
