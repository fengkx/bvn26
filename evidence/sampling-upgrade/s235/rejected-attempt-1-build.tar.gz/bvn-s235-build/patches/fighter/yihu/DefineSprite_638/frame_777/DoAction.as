_root.aiEvent("doaction_entry", "9ce2c729b503bad4bc4e029a8f0c0962c70927f8fdc9961efd452a47308ebe12," + escape(String(this)) + "," + _currentframe);
if(sw == true)
{
   stop();
}
