_root.aiEvent("doaction_entry", "38b7589ab051656615a9e87cc6df025cbb6b91127bca0a6b523e81e57bdf9adb," + escape(String(this)) + "," + _currentframe);
动作 = 0;
