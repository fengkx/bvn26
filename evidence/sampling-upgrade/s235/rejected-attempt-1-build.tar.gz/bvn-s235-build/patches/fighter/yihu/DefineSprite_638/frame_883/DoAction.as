_root.aiEvent("doaction_entry", "2825d1a1ecc3cf794a22c6bc05a6d4cbab52b8df922bf513a0532f82fed224ff," + escape(String(this)) + "," + _currentframe);
_root.aiEvent("intro_body_enter","883," + _currentframe);
kcplayed = 2;
gotoAndStop("站立");
play();

_root.aiEvent("intro_body_exit","883," + _currentframe);
