_root.aiEvent("doaction_entry", "bda570a95b92addf968a7ae795c319b88741c3da328fa395e83dadbf8d65e07d," + escape(String(this)) + "," + _currentframe);
this._name = "abcd";
