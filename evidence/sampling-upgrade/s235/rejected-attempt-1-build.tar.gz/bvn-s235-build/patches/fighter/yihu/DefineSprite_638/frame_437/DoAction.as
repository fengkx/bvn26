_root.aiEvent("doaction_entry", "85936739c8b11ef26f6e590ea917690c92772f9d81fdfbc90c148053bd956855," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
