_root.aiEvent("doaction_entry", "e35a57d7274e136ea315f0f25b9351acced76118d8c114d1d4d4a878331f378a," + escape(String(this)) + "," + _currentframe);
stop();
