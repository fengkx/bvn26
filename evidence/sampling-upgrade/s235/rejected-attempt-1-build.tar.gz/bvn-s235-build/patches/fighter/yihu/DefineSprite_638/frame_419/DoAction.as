_root.aiEvent("doaction_entry", "44dabd13f6f8190e1970aca713b85df53e2f9f72c69694ccae7be7cc9b36a664," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
