_root.aiEvent("doaction_entry", "c2d7710efc88fd6470069781c0f3360553947705851c6d515bd9b043d7379392," + escape(String(this)) + "," + _currentframe);
动作 = 0;
