_root.aiEvent("doaction_entry", "74475828024eacefb0192f4fa3312decf38aa32fc32b848392a1b2da750acaea," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"一户2");
