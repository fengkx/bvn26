_root.aiEvent("doaction_entry", "6dbfc8b2c715cc6c837fb86eb87bb9ff55c0c5f72db9e6d1f85f2df13ad7ba68," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
