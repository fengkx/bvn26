_root.aiEvent("doaction_entry", "c66d1a5edf7df798642e553c6e2274f9ff13cadbdabd1c13e8cf4aacbe176627," + escape(String(this)) + "," + _currentframe);
stop();
