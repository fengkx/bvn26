_root.aiEvent("doaction_entry", "2a8a791c0e4defb00d0a16bf6d1920f5ffb837f4264f52d67c8361ded6f0bf14," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
