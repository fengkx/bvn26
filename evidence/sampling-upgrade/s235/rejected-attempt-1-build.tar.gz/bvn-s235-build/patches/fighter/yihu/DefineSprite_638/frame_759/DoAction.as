_root.aiEvent("doaction_entry", "3aff8cb5a269f5199a4b56f1d1e8b9f296ae73bfe0f957f0ce81e50ddc7267b7," + escape(String(this)) + "," + _currentframe);
stop();
