_root.aiEvent("doaction_entry", "314b13a62d75b02b750e3cd69194b98e002125c6b85a235551176baf62499a40," + escape(String(this)) + "," + _currentframe);
动作 = 0;
