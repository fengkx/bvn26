_root.aiEvent("doaction_entry", "018fb7c889788c8185daf21f37deceb262bb580c465e5f18c75576bbe22ecd40," + escape(String(this)) + "," + _currentframe);
_root.hideFace(pn);
