_root.aiEvent("doaction_entry", "150948dd3b15eeb8e11521352b54f08b0284db32d44a724d09963bc388d47436," + escape(String(this)) + "," + _currentframe);
onBeHit(true);
