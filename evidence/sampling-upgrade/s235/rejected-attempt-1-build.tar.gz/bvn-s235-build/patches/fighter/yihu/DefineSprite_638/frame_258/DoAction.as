_root.aiEvent("doaction_entry", "2b4338ad62f548034e6426ac6e6b4d948461018c3bded63c392abf77a22b1dbe," + escape(String(this)) + "," + _currentframe);
动作 = 0;
