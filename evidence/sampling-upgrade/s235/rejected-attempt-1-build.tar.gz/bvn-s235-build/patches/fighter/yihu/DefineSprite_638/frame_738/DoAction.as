_root.aiEvent("doaction_entry", "eff8bdafe63b0e574c8987ecbb73c7ed3410952a465f687c76fa0f10deb8e97c," + escape(String(this)) + "," + _currentframe);
play();
