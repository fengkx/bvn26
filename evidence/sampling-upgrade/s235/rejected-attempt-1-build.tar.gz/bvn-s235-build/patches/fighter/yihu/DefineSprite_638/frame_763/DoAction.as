_root.aiEvent("doaction_entry", "b0617bda417222be9735f6e741bda5bb8a95e5bb59feb616a6c3302278a1ef06," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
