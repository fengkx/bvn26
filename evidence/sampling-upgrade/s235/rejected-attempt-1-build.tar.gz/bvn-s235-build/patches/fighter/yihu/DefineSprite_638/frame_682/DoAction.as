_root.aiEvent("doaction_entry", "f3134fec21f9ae1e4e75dad479bf27b8295315e7f334b23ea7aa3d1f425b6425," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
