_root.shunbuxg(_parent);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_23/DoAction.as");
