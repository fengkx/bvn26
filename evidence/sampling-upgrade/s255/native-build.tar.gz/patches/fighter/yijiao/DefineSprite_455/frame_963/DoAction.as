kcplayed = 2;
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_963/DoAction.as");
