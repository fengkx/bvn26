gotoAndStop("落");
play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_70/DoAction.as");
