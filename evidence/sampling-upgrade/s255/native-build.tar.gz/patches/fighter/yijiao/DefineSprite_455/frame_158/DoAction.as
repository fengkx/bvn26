gotoAndStop("跳招0");
play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_158/DoAction.as");
