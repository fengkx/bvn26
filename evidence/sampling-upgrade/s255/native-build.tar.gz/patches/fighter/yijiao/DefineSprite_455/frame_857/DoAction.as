_root.touchFloorEffect(_parent);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_857/DoAction.as");
