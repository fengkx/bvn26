_root._y -= 3;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_612/DoAction.as");
