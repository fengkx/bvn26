_root._y -= 2;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_614/DoAction.as");
