动作 = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_377/DoAction.as");
