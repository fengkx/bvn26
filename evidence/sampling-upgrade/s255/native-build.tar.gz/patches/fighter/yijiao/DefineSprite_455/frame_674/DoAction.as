动作 = 3;
bs = 1;
ql -= 300;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_674/DoAction.as");
