jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_74/DoAction.as");
