kcplayed = 3;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_920/DoAction.as");
