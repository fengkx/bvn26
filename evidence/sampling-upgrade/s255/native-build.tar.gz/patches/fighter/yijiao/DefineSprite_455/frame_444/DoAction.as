动作 = 1;
ql += 5;
jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_444/DoAction.as");
