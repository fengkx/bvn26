动作 = 3;
bs = 1;
ql -= 100;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_578/DoAction.as");
