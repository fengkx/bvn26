动作 = 1;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_204/DoAction.as");
