_root.cbsd(pn);
_root.showFace(pn,"一角2");

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_675/DoAction.as");
