_root.shine();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_607/DoAction.as");
