动作 = 2;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_809/DoAction.as");
