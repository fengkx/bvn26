_root._y = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_895/DoAction.as");
