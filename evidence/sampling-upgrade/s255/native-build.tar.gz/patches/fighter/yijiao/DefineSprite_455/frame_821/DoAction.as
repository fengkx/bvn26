onDefence(2);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_821/DoAction.as");
