_root.bsw(pn);
bs = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_604/DoAction.as");
