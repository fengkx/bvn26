khit = 1;
动作 = 1;
jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_146/DoAction.as");
