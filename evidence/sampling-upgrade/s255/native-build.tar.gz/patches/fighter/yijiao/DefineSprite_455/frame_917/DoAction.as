play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_917/DoAction.as");
