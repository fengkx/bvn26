jump = 0;
jumped = 1;
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_842/DoAction.as");
