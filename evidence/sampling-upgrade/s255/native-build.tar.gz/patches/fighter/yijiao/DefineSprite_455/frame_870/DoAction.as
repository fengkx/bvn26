if(sw == true)
{
   stop();
}

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_870/DoAction.as");
