_parent.moveX(150);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_545/DoAction.as");
