stop();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_853/DoAction.as");
