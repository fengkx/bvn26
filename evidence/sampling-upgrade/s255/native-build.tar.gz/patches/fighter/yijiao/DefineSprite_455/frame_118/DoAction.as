khit = 0;
jump = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_118/DoAction.as");
