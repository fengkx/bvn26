_root._y += 5;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_609/DoAction.as");
