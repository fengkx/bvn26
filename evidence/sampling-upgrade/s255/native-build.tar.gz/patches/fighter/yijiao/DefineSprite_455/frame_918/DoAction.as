play();
kcplayed = 1;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_918/DoAction.as");
