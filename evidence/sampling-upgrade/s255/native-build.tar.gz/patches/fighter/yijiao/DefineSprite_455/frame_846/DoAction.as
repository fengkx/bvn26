onBeHit(true);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_846/DoAction.as");
