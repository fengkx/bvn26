_root.shunbuxg(_parent);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_544/DoAction.as");
