play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_832/DoAction.as");
