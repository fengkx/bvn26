stop();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_1032/DoAction.as");
