动作 = 1;
ql += 10;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_410/DoAction.as");
