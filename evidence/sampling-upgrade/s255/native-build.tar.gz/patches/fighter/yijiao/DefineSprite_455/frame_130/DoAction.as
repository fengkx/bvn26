khit = 1;
动作 = 1;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_130/DoAction.as");
