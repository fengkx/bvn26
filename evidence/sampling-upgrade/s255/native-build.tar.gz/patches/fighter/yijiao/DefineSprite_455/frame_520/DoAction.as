_root.bsd(pn);
_root.showFace(pn,"一角1");

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_520/DoAction.as");
