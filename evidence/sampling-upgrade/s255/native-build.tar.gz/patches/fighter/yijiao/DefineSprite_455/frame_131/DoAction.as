_parent.moveX(5);
_parent.moveY(5);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_131/DoAction.as");
