gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_278/DoAction.as");
