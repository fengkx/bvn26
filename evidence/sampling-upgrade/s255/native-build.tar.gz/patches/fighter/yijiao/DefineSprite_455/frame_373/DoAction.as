_root.shine(16776960);

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_373/DoAction.as");
