onBeHit();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_833/DoAction.as");
