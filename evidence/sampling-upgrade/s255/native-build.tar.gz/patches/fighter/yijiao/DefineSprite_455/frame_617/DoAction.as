_root._y += 1;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_617/DoAction.as");
