动作 = 3;
bs = 1;
ql -= 100;
jump = 1;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_518/DoAction.as");
