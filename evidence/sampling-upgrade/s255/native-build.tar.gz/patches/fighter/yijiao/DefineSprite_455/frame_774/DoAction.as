doZhaoHuan();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_774/DoAction.as");
