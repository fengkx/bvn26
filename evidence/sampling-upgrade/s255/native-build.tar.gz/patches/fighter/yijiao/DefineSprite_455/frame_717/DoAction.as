_root.cbsw(pn);
bs = 0;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_717/DoAction.as");
