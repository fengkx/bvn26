gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_103/DoAction.as");
