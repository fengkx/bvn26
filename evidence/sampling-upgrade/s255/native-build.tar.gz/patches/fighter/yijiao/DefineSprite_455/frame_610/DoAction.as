_root._y -= 4;

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_610/DoAction.as");
