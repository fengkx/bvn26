gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_455/frame_140/DoAction.as");
