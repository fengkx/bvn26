stop();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_189/frame_13/DoAction.as");
