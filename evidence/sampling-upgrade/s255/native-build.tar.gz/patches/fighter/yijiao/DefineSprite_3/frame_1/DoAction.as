stop();

_root.aiGeoStamp(this, "game/fighter/yijiao.swf#DefineSprite_3/frame_1/DoAction.as");
