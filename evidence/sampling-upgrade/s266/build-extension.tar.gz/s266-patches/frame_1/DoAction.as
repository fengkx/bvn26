Stage.displayState = "normal";
Stage.scaleMode = "showAll";
// Keep the observer root outside the receiver that the authored goto can remove.
_global.bvnChadRoot = _root;
_global.bvnChadArmed = false;
_global.bvnChadObserve = function(phase, receiver, s257Witness)
{
   s257Witness.observerEntry = 1;
   if(phase == "s257_control") return;
   var root = _global.bvnChadRoot;
   if(phase == "caller_before" && root.aiFight == 10 && receiver._parent == root.game.p1.mc)
   {
      _global.bvnChadArmed = true;
      _global.bvnChadReceiver = receiver;
      _global.bvnChadParent = receiver._parent;
      _global.bvnChadDepth = receiver.getDepth();
      _global.bvnChadPath = String(receiver);
   }
   if(!_global.bvnChadArmed || root.aiFight < 10 || root.aiFight > 11)
   {
      return;
   }
   var parent = _global.bvnChadParent;
   var saved = _global.bvnChadReceiver;
   var occupant = parent.getInstanceAtDepth(_global.bvnChadDepth);
   root.aiEvent("chad_lifecycle", phase + "," + escape(_global.bvnChadPath) + "," + escape(String(receiver)) + "," + escape(String(saved)) + "," + escape(String(saved._parent)) + "," + saved._currentframe + "," + _global.bvnChadDepth + "," + parent._currentframe + "," + escape(String(occupant)) + "," + (occupant == saved));
};
_root.aiHelperClipFrame = function(helper, instanceName)
{
   var clip = helper[instanceName];
   return clip == undefined ? undefined : clip._currentframe;
};
_root.aiHelperState = function(player)
{
   var f = _root.game[player + "fz"];
   var m = f;
   _root.aiEvent("helper_state", player + "," + m._currentframe + "," + _root.aiNumber(f._x) + "," + _root.aiNumber(f._y) + "," + _root.aiNumber(f._xscale) + "," + m.attacking + "," + m.动作 + "," + m.hits + "," + _root.aiHelperClipFrame(f,"atm1") + "," + _root.aiHelperClipFrame(f,"atm2") + "," + _root.aiHelperClipFrame(f,"atm3"));
   _root.aiEvent("helper_clip_state", player + "," + m._currentframe + "," + "atm1" + "=" + _root.aiHelperClipFrame(f,"atm1"));
   var parent = f._parent;
   _root.aiEvent("helper_lifecycle", player + "," + m._currentframe + "," + f._visible + "," + _root.zhanting + "," + (parent == undefined ? undefined : parent._currentframe) + "," + _root.aiHelperClipFrame(f,"atm1") + "," + _root.aiHelperClipFrame(f,"atm2") + "," + _root.aiHelperClipFrame(f,"atm3"));
};
// Analysis-only binary significand encoding avoids FP32's short decimal strings.
_root.aiNumber = function(value)
{
   if(typeof value != "number" || !isFinite(value)) return String(value);
   if(value == 0) return "f:" + (1 / value < 0 ? -1 : 1) + ":0:0:0";
   var sign = value < 0 ? -1 : 1;
   var fraction = Math.abs(value);
   var exponent = 0;
   while(fraction >= 2) { fraction /= 2; exponent++; }
   while(fraction < 1) { fraction *= 2; exponent--; }
   var mantissa = fraction * 4503599627370496;
   var high = Math.floor(mantissa / 67108864);
   var low = mantissa - high * 67108864;
   return "f:" + sign + ":" + exponent + ":" + high + ":" + low;
};
// Analysis-only bootstrap: the original battle loader and AI remain active.
_root.aiRun = "s266-context-r02";
_root.aiSeq = 0;
_root.aiDisplay = 0;
_root.aiFight = -1;
_root.aiDraw = 0;
_root.aiClockDraw = 0;
_root.aiNativeRandom = Math.random;
_root.aiEvent = function(kind, value)
{
   trace("AIREF|" + aiRun + "|" + (++aiSeq) + "|" + getTimer() + "|" + aiDisplay + "|" + aiFight + "|" + kind + "|" + value);
};
_root.aiTimer = function(site)
{
   var value = getTimer();
   _root.aiEvent("clock", (++_root.aiClockDraw) + "," + site + "," + value);
   return value;
};
_root.aiRandom = function(site)
{
   var value = _root.aiNativeRandom();
   _root.aiEvent("random", (++_root.aiDraw) + "," + site + "," + _root.aiNumber(value));
   return value;
};
_root.aiPredicate = function(name, receiver, value)
{
   if(receiver._parent._parent.useAI || receiver._parent.useAI)
   {
      _root.aiEvent("predicate", name + "," + receiver + "," + value);
   }
   return value;
};
_root.aiState = function(player)
{
   var f = _root.game[player];
   var m = f.mc;
   _root.aiEvent("state", player + "," + m._currentframe + "," + _root.aiNumber(f._x) + "," + _root.aiNumber(f._y) + "," + _root.aiNumber(f._xscale) + "," + m.动作 + "," + _root.aiNumber(m.hp) + "," + _root.aiNumber(m.ql) + "," + m.sw + "," + m.touch + "," + m.touchFloor + "," + m.hits + "," + _root.zhanting + "," + m.hstm + "," + m.hurtSkling);
};
_root.aiGeometry = function()
{
   var f = _root.game.p2;
   var m = f.mc;
   var target = _root.game.p1.mc.bdmn;
   var names = ["kanmian","tkanmian","zh1mian","zh2mian","zh3mian","kj1mian","kj2mian","bsmian","sbsmian","cbsmian","tzmian","absmian"];
   _root.aiEvent("geometry_frame", m._currentframe + "," + f._x + "," + f._y + "," + f._xscale);
   var chain = [f,m,m.AImain];
   for(var c = 0; c < chain.length; c++)
   {
      var cm = chain[c].transform.matrix;
      var gm = chain[c].transform.concatenatedMatrix;
      _root.aiEvent("geometry_matrix", c + "," + cm.a + "," + cm.b + "," + cm.c + "," + cm.d + "," + cm.tx + "," + cm.ty + "," + gm.a + "," + gm.b + "," + gm.c + "," + gm.d + "," + gm.tx + "," + gm.ty);
   }
   for(var n = 0; n < names.length; n++)
   {
      var obj = m.AImain[names[n]];
      var bounds = obj.getBounds(f);
      _root.aiEvent("sensor_bounds", names[n] + "," + bounds.xMin + "," + bounds.yMin + "," + bounds.xMax + "," + bounds.yMax + "," + obj.hitTest(target));
      var own = obj.getBounds(obj);
      var sm = obj.transform.matrix;
      _root.aiEvent("sensor_local", names[n] + "," + own.xMin + "," + own.yMin + "," + own.xMax + "," + own.yMax + "," + sm.a + "," + sm.b + "," + sm.c + "," + sm.d + "," + sm.tx + "," + sm.ty);
   }
};
function showCommt()
{
   if(allowGoLink)
   {
      goLink();
      return undefined;
   }
   if(_global.bridge)
   {
      _global.bridge.showGameList();
   }
}
function goLink(url)
{
}
_root.ver = "V 2.6";
_root.date_ver = "2016/6/23";
var adType;
var wudi = false;
var TYPE_4399 = "4399";
var allowGoLink = true;
var NO_AD = "no-ad";
var debuging = true;
adType = TYPE_4399;
var _loc0_;
if((_loc0_ = adType) === TYPE_4399)
{
   _global.bridge = AS2_4399_API.Bridge.getInstance();
   var _4399_function_ad_id = "944c23f5e64a80647f8d0f3435f5c7a8";
   allowGoLink = false;
}

gotoAndPlay(6);

_global.s263Run = function()
{
   var host = _root.createEmptyMovieClip("s263Host", _root.getNextHighestDepth());
   var worker = function(witness, invalidate)
   {
      var saved = witness;
      var operation = invalidate;
      saved.before = 1;
      saved.receiverBefore = this == saved.receiver;
      operation(saved);
      saved.post = 1;
   };
   var operation = function(witness)
   {
      witness.occupiedBefore = witness.host.getInstanceAtDepth(witness.depth) == witness.receiver;
      if(witness.mode == "remove") witness.receiver.removeMovieClip();
      witness.emptyAtBoundary = witness.host.getInstanceAtDepth(witness.depth) == undefined;
      witness.boundary = 1;
   };
   var modes = ["retain", "remove"];
   for(var i = 0; i < 2; i++)
   {
      var receiver = host.createEmptyMovieClip("receiver", 1);
      receiver.run = worker;
      var witness = {mode:modes[i],host:host,receiver:receiver,depth:1,before:0,boundary:0,post:0};
      receiver.run(witness, operation);
      aiEvent("s263_register_control", witness.mode + "," + witness.before + "," + witness.receiverBefore + "," + witness.occupiedBefore + "," + witness.emptyAtBoundary + "," + witness.boundary + "," + witness.post + "," + (host.getInstanceAtDepth(1) == undefined));
      receiver.removeMovieClip();
   }
   host.removeMovieClip();
};

_global.s266Run = function()
{
   var operation = function(witness)
   {
      witness.occupiedBefore = witness.host.getInstanceAtDepth(witness.depth) == witness.receiver;
      witness.host.gotoAndStop(witness.target);
      witness.emptyAtBoundary = witness.host.getInstanceAtDepth(witness.depth) == undefined;
      witness.parentFrame = witness.host._currentframe;
      witness.boundary = 1;
   };
   var hosts = [_root.s266Retain, _root.s266Remove];
   var modes = ["retain", "remove"];
   for(var i = 0; i < 2; i++)
   {
      var host = hosts[i];
      var receiver = host.child;
      var witness = {mode:modes[i],host:host,receiver:receiver,target:i + 2,depth:receiver.getDepth(),before:0,boundary:0,post:0};
      receiver.worker(witness, operation);
      aiEvent("s266_authored_control", witness.mode + "," + witness.before + "," + witness.receiverBefore + "," + witness.definingBefore + "," + witness.occupiedBefore + "," + witness.emptyAtBoundary + "," + witness.parentFrame + "," + witness.depth + "," + witness.boundary + "," + witness.post + "," + (host.getInstanceAtDepth(witness.depth) == undefined));
   }
};
