rad = _root.aiRandom("main#DefineSprite_2060/frame_15/DoAction.as:1") * 15;
gotoAndPlay(15);
