_root.aiEvent("doaction_entry", "87a51b14b65d12ed2d2e2d2581d50e8aacd0bc3cbbe6bce39a91f35201ed1cf1," + escape(String(this)) + "," + _currentframe);
动作 = 1;
