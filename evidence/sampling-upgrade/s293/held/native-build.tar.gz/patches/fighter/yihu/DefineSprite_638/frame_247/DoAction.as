_root.aiEvent("doaction_entry", "6ac244ef91cb02c8a9c264fa18fc431dddd5545d965e2a014de983b8a176e3bc," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
