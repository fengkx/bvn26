_root.aiEvent("doaction_entry", "d02bdcaa81730c6f45633a191e4251cfc73098022055a81c1daf4192978a9481," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
