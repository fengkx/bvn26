_root.aiEvent("doaction_entry", "1bec53922fb1552852a7ebc2724f733b6271afbe5d274c4ff5d637cf67cea042," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
