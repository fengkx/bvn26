_root.aiEvent("doaction_entry", "9452eb336ee4aeb33835736e0777307920a9bf0c7e7b15e4457f1d95fee1b774," + escape(String(this)) + "," + _currentframe);
动作 = 1;
