_root.aiEvent("doaction_entry", "24da1db278d368c8daf750b8d811a6821fec6423d29c0c192f4ba02a43373a42," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
