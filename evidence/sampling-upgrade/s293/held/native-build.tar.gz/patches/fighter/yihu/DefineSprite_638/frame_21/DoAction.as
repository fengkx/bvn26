_root.aiEvent("doaction_entry", "d49862d1010d266c7119c099891e6546344c937b6cb041fb75da4e852398caaa," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
