_root.aiEvent("doaction_entry", "3941fd5371d008d56a342b9712642a5f9c9ce459b22c05ecefe25cb475cd522d," + escape(String(this)) + "," + _currentframe);
khit = 1;
jump = 1;
动作 = 1;
ql += 5;
