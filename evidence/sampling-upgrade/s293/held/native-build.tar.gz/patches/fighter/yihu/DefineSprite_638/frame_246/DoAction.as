_root.aiEvent("doaction_entry", "8fe1354e2223bdc02dc14356c6b6604940f8adbef2388ab6e57ebee0c6014802," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
