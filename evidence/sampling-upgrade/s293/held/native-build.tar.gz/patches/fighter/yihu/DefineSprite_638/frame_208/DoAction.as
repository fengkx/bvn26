_root.aiEvent("doaction_entry", "41ea8112f06dc4007d3a3ac251afd84b005cd0278d43ffc00892eaa28d4afdd0," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
