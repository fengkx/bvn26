_root.aiEvent("doaction_entry", "620ec7832f414028827dfe07d498c521fd96066fd20ef490201466fc9728442a," + escape(String(this)) + "," + _currentframe);
hits = 0;
