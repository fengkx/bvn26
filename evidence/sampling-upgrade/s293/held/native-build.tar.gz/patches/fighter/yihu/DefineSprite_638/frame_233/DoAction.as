_root.aiEvent("doaction_entry", "87b39ff8032338600c8e652f3cffdab5c13a84d0ea6d7f5ac34fab72dc193185," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
