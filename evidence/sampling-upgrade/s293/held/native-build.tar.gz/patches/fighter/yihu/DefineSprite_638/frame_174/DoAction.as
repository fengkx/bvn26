_root.aiEvent("doaction_entry", "3b9dbef7df02cabb802e6f6fce9f7dc09127c4dc40014e7d0ba8ffeb4bee7316," + escape(String(this)) + "," + _currentframe);
动作 = 1;
