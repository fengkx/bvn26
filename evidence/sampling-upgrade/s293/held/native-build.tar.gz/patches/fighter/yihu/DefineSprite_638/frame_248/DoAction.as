_root.aiEvent("doaction_entry", "84c0e2bcbb5b3f4ae9c3c0eac2966112e15a21a9d40eddc082ea1bb805e1c5ee," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
