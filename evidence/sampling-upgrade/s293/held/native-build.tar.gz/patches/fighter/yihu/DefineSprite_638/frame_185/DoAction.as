_root.aiEvent("doaction_entry", "6d1af114ca763faca2f2eba38ba4a4b73a80f6ae17d069cb901284af3e7a1cb0," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
