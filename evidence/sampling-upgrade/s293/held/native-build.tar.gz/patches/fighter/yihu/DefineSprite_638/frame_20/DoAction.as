_root.aiEvent("doaction_entry", "f7ad2c873866137a3488a704f6e6f3c17d5a6675bfb89244d30f2dd347249c96," + escape(String(this)) + "," + _currentframe);
jump = 1;
