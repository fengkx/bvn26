_root.aiEvent("doaction_entry", "09511f0f84707b17181759d9c55e766154237ab452edef8d2be5726d04febc40," + escape(String(this)) + "," + _currentframe);
动作 = 0;
