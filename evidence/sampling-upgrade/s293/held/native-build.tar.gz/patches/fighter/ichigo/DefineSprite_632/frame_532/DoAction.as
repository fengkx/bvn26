_root.aiEvent("doaction_entry", "d8aab284239204fbf9bd326212abc75cc140fa1c72e508dfe2a9ffefec2bd5a8," + escape(String(this)) + "," + _currentframe);
_root.shine(16711680);
