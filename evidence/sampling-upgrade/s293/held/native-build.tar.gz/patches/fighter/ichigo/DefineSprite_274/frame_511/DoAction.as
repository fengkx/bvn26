_root.aiEvent("doaction_entry", "781776c31b3e1126f164fb060bfaf7207d5890b3e35e2757e046478f47d043ad," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
