_root.aiEvent("doaction_entry", "fc9646032cfa41bc46447908963a764536cbc2bb233cd6657615165f39151b0b," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
