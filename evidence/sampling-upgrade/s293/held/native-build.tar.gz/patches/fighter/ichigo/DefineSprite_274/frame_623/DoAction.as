_root.aiEvent("doaction_entry", "1065110c8e481855d4288f4f3d2e492215e79679fd8b8769c22dc2856f613c35," + escape(String(this)) + "," + _currentframe);
stop();
