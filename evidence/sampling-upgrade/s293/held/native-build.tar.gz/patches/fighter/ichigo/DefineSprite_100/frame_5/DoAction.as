_root.aiEvent("doaction_entry", "68f4692f84753561ac00e75d7c7a6725996e6af37ba096957177ef0a67782515," + escape(String(this)) + "," + _currentframe);
this._name = "abcd";
