_root.aiEvent("doaction_entry", "f3d0ad79d38bb6c40c857191cec007cf6467c6a582982c9f6ebe17bc337592d5," + escape(String(this)) + "," + _currentframe);
play();
