_root.aiEvent("doaction_entry", "9ae51ebef3e01a0b4ed5abfaab59516d84a372f13b3bfb8069f2c1e76128b3eb," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
