_root.aiEvent("doaction_entry", "832b8f53d5c3a9b6876e757ff5a97dfa2524ae5db01072d9bd0b0dab88e8e586," + escape(String(this)) + "," + _currentframe);
kcplayed = 1;
