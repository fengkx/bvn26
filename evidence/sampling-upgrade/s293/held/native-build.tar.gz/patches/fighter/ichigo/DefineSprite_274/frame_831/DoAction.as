_root.aiEvent("doaction_entry", "1b71b292a1657726a7878d603a5bb1a6ab5e6add1cbc1e13f0000ea1c62d602e," + escape(String(this)) + "," + _currentframe);
stop();
