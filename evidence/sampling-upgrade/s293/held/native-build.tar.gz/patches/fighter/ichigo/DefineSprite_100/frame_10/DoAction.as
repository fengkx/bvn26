_root.aiEvent("doaction_entry", "844bb8e04c537de1891d9f0ef813e30706281c70d14b8ee3fb3f34065a8cda25," + escape(String(this)) + "," + _currentframe);
stop();
