_root.aiEvent("doaction_entry", "bea9b6b95cca81a3ba17c158949b8214a7b748df0a7f11697af3725a8b01e869," + escape(String(this)) + "," + _currentframe);
_parent.gotoAndStop(2);
