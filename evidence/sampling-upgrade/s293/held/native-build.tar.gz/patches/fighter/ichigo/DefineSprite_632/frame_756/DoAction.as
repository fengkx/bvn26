_root.aiEvent("doaction_entry", "32dcd6caa1592b9ef84f4e359cbb0a33367f5dc3db98a3c5c64f292ce26f7fa9," + escape(String(this)) + "," + _currentframe);
if(_parent._xscale > 0)
{
   _parent._xscale = -100;
   _parent._x = _root.game["p" + pn]._x + 30;
}
else
{
   _parent._xscale = 100;
   _parent._x = _root.game["p" + pn]._x - 30;
}
