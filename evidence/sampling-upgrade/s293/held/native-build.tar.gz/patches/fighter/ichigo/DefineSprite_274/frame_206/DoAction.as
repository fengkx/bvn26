_root.aiEvent("doaction_entry", "946c879eac984ba397583e31bd68784285ab47b0bc11b74f640a833a2aaddb28," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
_root.shunbuxg(_parent);
