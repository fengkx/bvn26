_root.aiEvent("doaction_entry", "d352acb3862109505524885368613ab5b1ecf1c4258965c2fded90ab2d073fd6," + escape(String(this)) + "," + _currentframe);
jump = 0;
jumped = 1;
clearInterval(tdint);
gotoAndStop("站立");
play();
