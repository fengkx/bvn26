_root.aiEvent("doaction_entry", "0bdc9c8182b16255967af41cc22bbbaee7366d4a77ccac4f32e405d2ebe9a310," + escape(String(this)) + "," + _currentframe);
动作 = 2;
