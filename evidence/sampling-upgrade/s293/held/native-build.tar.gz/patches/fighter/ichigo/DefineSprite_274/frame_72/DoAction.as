_root.aiEvent("doaction_entry", "ee07bcb514aba878ef563f8e5902a0f54f86c7486c412f9ee45bb3824a785b44," + escape(String(this)) + "," + _currentframe);
jump = 1;
jumped = 0;
