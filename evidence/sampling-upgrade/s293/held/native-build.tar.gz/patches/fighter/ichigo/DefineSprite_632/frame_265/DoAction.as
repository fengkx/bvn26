_root.aiEvent("doaction_entry", "385ae05b2bd0ccc9e9272400b3dce4f3355fbeb5d504b0893022167a0b1f0241," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
