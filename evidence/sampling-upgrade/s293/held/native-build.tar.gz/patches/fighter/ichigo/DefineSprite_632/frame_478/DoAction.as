_root.aiEvent("doaction_entry", "9dbb972bbf7d1b77ebccec67f9ebb86569791daabaf0c738e4e240721702db99," + escape(String(this)) + "," + _currentframe);
动作 = 0;
