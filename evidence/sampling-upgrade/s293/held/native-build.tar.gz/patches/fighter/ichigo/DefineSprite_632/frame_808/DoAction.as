_root.aiEvent("doaction_entry", "16f8a5e3ede8ef795e2ce236fcc7437351ec107f1ad07df91c7c05a67d2993cc," + escape(String(this)) + "," + _currentframe);
_root.shine();
_root.shine(16711680);
