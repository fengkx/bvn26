_root.aiEvent("doaction_entry", "e1a2635ca39d5fe88f1f070c2561562b01f64f8e78761d51939a4812145809ed," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
