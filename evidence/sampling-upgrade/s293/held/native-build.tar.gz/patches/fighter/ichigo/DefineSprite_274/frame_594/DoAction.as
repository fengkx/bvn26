_root.aiEvent("doaction_entry", "d19b96ab414cf586a9b4b4927ad5533edcaf15c28666da75ca2a732d02849884," + escape(String(this)) + "," + _currentframe);
动作 = 2;
