_root.aiEvent("doaction_entry", "18c8885ad512cfe6a6a522c403dbc76b40ef82fd38c37babfc4ea84fe64fc0db," + escape(String(this)) + "," + _currentframe);
hits = 0;
