_root.aiEvent("doaction_entry", "78a9a9fee8687d506c1c91e77fc516e39e964af399c1218070956b7ad32e792c," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
