_root.aiEvent("doaction_entry", "f68cc8b106e89961174176418173d4118f802ed79e011016e10345a4e4fdd6b5," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
_root.shunbuxg(_parent);
