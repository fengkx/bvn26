_root.aiEvent("doaction_entry", "e253439df0f85b1c615911375f91226c278dd93cfab5d34a609d21f068af8649," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
