_root.aiEvent("doaction_entry", "b4119ace3d66cfda9c78c69fe4c2089e7b32eeaf3ed3a7247d91c2d41793967f," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
