_root.aiEvent("doaction_entry", "7768d9c87ff09c29e81df98c488ceb4f5d123f2a873a5d45e509b848c5d0524f," + escape(String(this)) + "," + _currentframe);
动作 = 1;
