_root.aiEvent("doaction_entry", "1cbd144d44cb94feab773eb1c94f47c7f1411f5197af0eaac9c86b8087fc8fc5," + escape(String(this)) + "," + _currentframe);
khit = 1;
动作 = 1;
