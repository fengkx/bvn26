_root.aiEvent("doaction_entry", "ec6e46768e340badcb45c03413d1570cdf31edcb4d237f38bc459ec6c5d08364," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
