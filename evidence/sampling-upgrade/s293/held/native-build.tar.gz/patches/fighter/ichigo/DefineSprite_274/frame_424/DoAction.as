_root.aiEvent("doaction_entry", "5ce3704dee2aa080f4929af91f284b86c6a4f29c73b5822dfb8c91cb449de092," + escape(String(this)) + "," + _currentframe);
动作 = 0;
