_root.aiEvent("doaction_entry", "b199e5cce7f000dd4c18634c3cd55ec0e90df2ed955a0cb000bfdc80be2d5a94," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
