_root.aiEvent("doaction_entry", "13492f7f33d694aaad37152441ce62a180fb4386bd3dd68508d23e4c7e3e3116," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
jump = 1;
jumped = 0;
