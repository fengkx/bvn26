_root.aiEvent("doaction_entry", "a5462e85cafe78a9a91f005ef790281ec277f58464389a7af5081a52a918d5cc," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
