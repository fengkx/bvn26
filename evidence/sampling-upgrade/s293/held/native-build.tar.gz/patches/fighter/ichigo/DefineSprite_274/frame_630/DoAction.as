_root.aiEvent("doaction_entry", "4e6a5bb3967b43dd7d239d536f328b965be81d38e40a531ae7e9d90f306415e9," + escape(String(this)) + "," + _currentframe);
hited = 0;
play();
