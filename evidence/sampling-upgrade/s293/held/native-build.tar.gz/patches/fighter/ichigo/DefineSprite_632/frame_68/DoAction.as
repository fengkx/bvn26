_root.aiEvent("doaction_entry", "fee583bcd222ae8291ba529ce442c05eda6d5950221f09ec516e39adf96452fc," + escape(String(this)) + "," + _currentframe);
jump = 1;
jumped = 0;
