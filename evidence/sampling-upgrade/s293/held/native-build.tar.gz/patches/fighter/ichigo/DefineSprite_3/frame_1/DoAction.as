_root.aiEvent("doaction_entry", "4421271749851348775749cd538e22c799807c1a761a62530f15a8bc816e407b," + escape(String(this)) + "," + _currentframe);
stop();
