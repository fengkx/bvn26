_root.aiEvent("doaction_entry", "127bba5ebf87bba9b6038816da03ef4af5afcfce158d3b79f0a85d6a739fd719," + escape(String(this)) + "," + _currentframe);
kcplayed = 3;
