_root.aiEvent("doaction_entry", "4756a339d368fcac7c668f0d98776df206f90f2b965afc1907a7585f69a15864," + escape(String(this)) + "," + _currentframe);
_root._y += 5;
