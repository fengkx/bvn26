_root.aiEvent("doaction_entry", "0a140ac36e2de3341a9308d139cc31acf4b9ef62290b35cb4d5a5d16b2ea45d2," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
