_root.aiEvent("doaction_entry", "5567140afa9a55d6a66dc63842ba624ae69b9e5572d0f48fc032dd84c962790f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
