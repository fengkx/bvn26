_root.aiEvent("doaction_entry", "ff1e27d03961f84b53b7c7dfab664e14ee06c3912f7adf3da4ebd264bb5edadb," + escape(String(this)) + "," + _currentframe);
if(_parent._xscale > 0)
{
   _parent._x = _root.game["p" + pn]._x - 30;
}
else
{
   _parent._x = _root.game["p" + pn]._x + 30;
}
_parent._y = _root.game["p" + pn]._y;
