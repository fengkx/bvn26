_root.aiEvent("doaction_entry", "9719098b21757c94b04006e674628c4984b4ee141d26f35bdcfe57b0212e716c," + escape(String(this)) + "," + _currentframe);
hits = 0;
