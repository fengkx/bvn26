_root.aiEvent("doaction_entry", "de38c00253108767b550ccde7740a18bbbf2bccc88962fee97336922c27a32b1," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
