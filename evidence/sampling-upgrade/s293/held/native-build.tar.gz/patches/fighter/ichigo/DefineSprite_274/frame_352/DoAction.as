_root.aiEvent("doaction_entry", "e76921a76c3ba845d59a48c2741c41a34f8ee8c4146d37f73f24c804f3547820," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
