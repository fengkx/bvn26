_root.aiEvent("doaction_entry", "5baaf3f0a3acef94142d11834d37ba57bf6071e84f35453af6407f4d759980dc," + escape(String(this)) + "," + _currentframe);
动作 = 0;
