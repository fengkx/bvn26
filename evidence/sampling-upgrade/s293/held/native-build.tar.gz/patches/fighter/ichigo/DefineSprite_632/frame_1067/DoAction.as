_root.aiEvent("doaction_entry", "46c6269d5bb059eb232a407f531ebded0f4e8db3f9ea50b6280a16680d004ef2," + escape(String(this)) + "," + _currentframe);
stop();
