_root.aiEvent("doaction_entry", "80725cf41139f6ff9ae65147a585e9481489c2eab1b01e2f095c6da90f17af65," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
