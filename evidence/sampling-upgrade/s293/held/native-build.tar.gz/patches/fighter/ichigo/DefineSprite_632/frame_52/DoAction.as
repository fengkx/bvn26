_root.aiEvent("doaction_entry", "be287145c0d179967bade25668ff3a1f0478758c435138994c312537a4a36ac7," + escape(String(this)) + "," + _currentframe);
jump = 0;
