_root.aiEvent("doaction_entry", "b0e2c9fdd68edf0b9554340691215d9eff9c4f68fab6846a4fb4f613767be952," + escape(String(this)) + "," + _currentframe);
动作 = 1;
