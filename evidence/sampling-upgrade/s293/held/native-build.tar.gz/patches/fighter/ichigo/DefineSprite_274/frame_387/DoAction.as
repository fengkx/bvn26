_root.aiEvent("doaction_entry", "9614819237561a887f0a474d69ad6496ea701db97189b78cdb1ac7bf32bc1a8c," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一户1");
