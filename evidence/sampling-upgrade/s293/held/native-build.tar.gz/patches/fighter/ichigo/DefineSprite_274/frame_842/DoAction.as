_root.aiEvent("doaction_entry", "54020f94c8ed5bb0cc2bcbdf733a7e1a22320f28a7cf626f15f047892e52d4bd," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
