_root.aiEvent("doaction_entry", "31b48e15b6c526cd004fdf86e0041e5761710a2d32efe3e7cc2f314a733287c9," + escape(String(this)) + "," + _currentframe);
_root.shine();
