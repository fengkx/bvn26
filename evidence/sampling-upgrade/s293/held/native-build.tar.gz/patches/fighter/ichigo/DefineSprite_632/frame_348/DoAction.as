_root.aiEvent("doaction_entry", "8eb983c120f5d68f8d3255ee6dfc249402f2b3b2cf57d65127e53c9b8d4fee2a," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
