_root.aiEvent("doaction_entry", "9d3c1957d3db27822cf95bb9449f69f374f2e932f3ab7af6c9b94237065f0856," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
