_root.aiEvent("doaction_entry", "1b3e101e18d1846d0e79d291ed15521d7761931af230030e81d65efedd70c8e0," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
