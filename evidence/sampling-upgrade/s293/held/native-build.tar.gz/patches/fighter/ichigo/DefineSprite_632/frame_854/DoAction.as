_root.aiEvent("doaction_entry", "f517dcae8f96cc7ba122d31c40f42a66401ca404ed9d444e847a70ad13cee736," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
