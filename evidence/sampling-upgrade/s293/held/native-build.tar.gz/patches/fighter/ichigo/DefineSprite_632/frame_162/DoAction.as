_root.aiEvent("doaction_entry", "481aff749e4686f493355d1c1db682e591f25c1b2c03550e3ec503bf5a461f41," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
