_root.aiEvent("doaction_entry", "a0dbec1c8194408a4de48857ac30e24c1a55849615b21ef2750985101a0445dd," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"白一护1");
