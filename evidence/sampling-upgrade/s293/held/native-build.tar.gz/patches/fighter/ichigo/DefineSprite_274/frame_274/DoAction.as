_root.aiEvent("doaction_entry", "cd396f4e3576e4dadf9d7f27170c4cff759b9f003bcda40d5968905df31a7721," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 5;
