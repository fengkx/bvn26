_root.aiEvent("doaction_entry", "fc2fd285a255fcee7d8009ec184f6bac69597d494609bd044cd27659049f6a43," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
