_root.aiEvent("doaction_entry", "f7c39e2767e579715319ef0b0c8074a47bbc9a1877b18bb0354f22aeff0a23ec," + escape(String(this)) + "," + _currentframe);
if(_parent._xscale > 0)
{
   _parent._xscale = -100;
   _parent._x = _root.game["p" + pn]._x + 50;
}
else
{
   _parent._xscale = 100;
   _parent._x = _root.game["p" + pn]._x - 50;
}
