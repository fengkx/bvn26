_root.aiEvent("doaction_entry", "0f9755a445ff1cd558868c3e140682332d09181daaa72859b9c654e605e4d26c," + escape(String(this)) + "," + _currentframe);
动作 = 0;
