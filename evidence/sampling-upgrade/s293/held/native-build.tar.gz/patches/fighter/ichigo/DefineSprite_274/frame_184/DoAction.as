_root.aiEvent("doaction_entry", "0ff3465691bc86b43bb55c15f9db9b76b9bbb901a536336727344fe8bec0f6d7," + escape(String(this)) + "," + _currentframe);
动作 = 1;
