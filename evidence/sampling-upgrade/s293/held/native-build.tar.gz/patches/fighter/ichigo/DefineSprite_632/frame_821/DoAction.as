_root.aiEvent("doaction_entry", "2b3344f10d39405685709bf73c621f60e9cb9d2305230e22bb37f4433e98b11f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
