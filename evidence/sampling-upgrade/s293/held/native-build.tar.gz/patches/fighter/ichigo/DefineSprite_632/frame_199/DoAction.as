_root.aiEvent("doaction_entry", "4bc8bfe869998aa0b88b5e2fb4ecc4d49b5f07cdacb139a3a8c5fc38d57cef81," + escape(String(this)) + "," + _currentframe);
动作 = 0;
