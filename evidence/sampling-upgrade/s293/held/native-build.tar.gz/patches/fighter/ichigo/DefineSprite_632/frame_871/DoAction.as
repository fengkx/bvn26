_root.aiEvent("doaction_entry", "5ed755d23b105735d70fb545ea55746e357203319cad3a507c15996b9e48e770," + escape(String(this)) + "," + _currentframe);
play();
