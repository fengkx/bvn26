_root.aiEvent("doaction_entry", "cd5eeb2912f6769206774e211ce6da611d5f1dd6a26511acda42e2a953061c15," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
bs = 0;
