_root.aiEvent("doaction_entry", "3adcab4c54a05617382380242385ad76bc1edcfff919b23e30e5080cc8cb1b68," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
jump = 1;
