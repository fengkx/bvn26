_root.aiEvent("doaction_entry", "acc517a3f897701577a252f9fe50af243c9ace9bc73c4f7855d3205cae947106," + escape(String(this)) + "," + _currentframe);
动作 = 1;
