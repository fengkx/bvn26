_root.aiEvent("doaction_entry", "9215969ad31c3b62febd958637fd4dc572c515151977e7ec8eebbf8c06a430fd," + escape(String(this)) + "," + _currentframe);
trace("hz");
