_root.aiEvent("doaction_entry", "1033dc317536fd15293e94e7767b84ec847006ce41e27efd315338601e47a03a," + escape(String(this)) + "," + _currentframe);
动作 = 1;
ql += 10;
