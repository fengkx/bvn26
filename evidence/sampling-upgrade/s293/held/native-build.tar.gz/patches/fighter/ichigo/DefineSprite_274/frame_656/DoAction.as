_root.aiEvent("doaction_entry", "61b61f2f07cd9b506f9da67a3cc133dfe03aea2c275d6ce286da55ac16743e97," + escape(String(this)) + "," + _currentframe);
if(sw == true)
{
   stop();
}
