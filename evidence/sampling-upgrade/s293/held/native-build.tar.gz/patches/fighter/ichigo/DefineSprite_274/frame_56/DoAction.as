_root.aiEvent("doaction_entry", "f897e81440677a21a56359263a6ebc0fb6eb8bc3f653cb3f59f7180a77d429fb," + escape(String(this)) + "," + _currentframe);
jump = 0;
