_root.aiEvent("doaction_entry", "6e82ac80dd64685ac1e4a804c9ce8446f4e259705f139d6601df24c7a1c6f909," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
