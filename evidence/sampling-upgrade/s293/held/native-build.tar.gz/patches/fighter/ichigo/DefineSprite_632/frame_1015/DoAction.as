_root.aiEvent("doaction_entry", "9d25f621dba3ef55cda32bf9a2ce76f46682cb15750dbfff1f7ccf1c7164feb7," + escape(String(this)) + "," + _currentframe);
wankai_end();
