_root.aiEvent("doaction_entry", "d7027b578684a6ef99b9cd376ff4239f90f8ca999e7df7d96d7397fd891a7972," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
