_root.aiEvent("doaction_entry", "a98ad7a4448105e68463c6f6167343f1ea6c452f4254786d43eecaf401e8f395," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
