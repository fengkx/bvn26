_root.aiEvent("doaction_entry", "303eb084723f30b3b0943ba8f50a64e79802fa7f7fb93124ac32ba138b872190," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
