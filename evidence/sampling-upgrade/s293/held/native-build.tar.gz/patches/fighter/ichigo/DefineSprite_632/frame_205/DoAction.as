_root.aiEvent("doaction_entry", "1dffa170a60eee8cca485013b0a2ae295f2bd46fa67b0080637f5ff0313f3127," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
