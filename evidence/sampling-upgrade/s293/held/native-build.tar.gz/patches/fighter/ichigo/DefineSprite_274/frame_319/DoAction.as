_root.aiEvent("doaction_entry", "e9cad7f61d1d2575c63cb884da2154e3c601540b5cfa0e834a16945d7d32cc87," + escape(String(this)) + "," + _currentframe);
动作 = 0;
