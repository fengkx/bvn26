_root.aiEvent("doaction_entry", "961b5ec280e072ecb63f104c5774ed9c0bafb88c0c0e729e5c1126d733b28733," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
