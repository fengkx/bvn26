_root.aiEvent("doaction_entry", "7c564a28248182e6fc635b7006a31b3496058e4f16c96e97c039815d354cb48d," + escape(String(this)) + "," + _currentframe);
khit = 0;
jump = 0;
