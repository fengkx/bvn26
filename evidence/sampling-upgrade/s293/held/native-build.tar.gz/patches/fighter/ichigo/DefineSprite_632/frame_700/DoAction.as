_root.aiEvent("doaction_entry", "7bd85a5514017b99bc9be93d1b81d724c7c089c8b3ccf7bd5caf8e229b0e310c," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 300;
jump = 1;
