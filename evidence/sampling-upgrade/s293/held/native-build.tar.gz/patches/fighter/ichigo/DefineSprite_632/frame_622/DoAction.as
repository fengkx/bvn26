_root.aiEvent("doaction_entry", "b8766dc8d2dc05b3be0efb22bf53f7183751e359e65984fd1e9f07a76ca5f331," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
