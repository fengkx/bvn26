_root.aiEvent("doaction_entry", "e107ed5cf9814ce3dd4f4d49cef36bdc349a8a35546d9ca1d17a35264c61ff23," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
