_root.aiEvent("doaction_entry", "57418b2a41cd47fb7995a57a62e7c7c09f93ab2e735b47162466e170b372e6dd," + escape(String(this)) + "," + _currentframe);
onDefence();
