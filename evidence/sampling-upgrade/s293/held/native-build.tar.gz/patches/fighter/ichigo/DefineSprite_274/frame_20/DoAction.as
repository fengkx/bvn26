_root.aiEvent("doaction_entry", "50e012123edbecb5c99d710ce0e019eaae68a46050da1467dc4bdb34da124d92," + escape(String(this)) + "," + _currentframe);
jump = 1;
