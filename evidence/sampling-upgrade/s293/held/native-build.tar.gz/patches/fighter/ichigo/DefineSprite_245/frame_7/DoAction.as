_root.aiEvent("doaction_entry", "bbd1e47e5e45fd9e29b29d3ac0bc129c40705048d966163c23b05dd5a19cbe86," + escape(String(this)) + "," + _currentframe);
_root._y += 4;
