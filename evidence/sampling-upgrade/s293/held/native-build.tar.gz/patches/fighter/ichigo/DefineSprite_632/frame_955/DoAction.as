_root.aiEvent("doaction_entry", "bcc68ac241d7b2c57a275afd799bb2a9aa9403a33120ae230c22d07277bc3901," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
