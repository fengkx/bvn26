_root.aiEvent("doaction_entry", "d3541b5fc4b3cecefbddeef663b8f213323830d278ac16a9938e1b3ba78220d5," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
