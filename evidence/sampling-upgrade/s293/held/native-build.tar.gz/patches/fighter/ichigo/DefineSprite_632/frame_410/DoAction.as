_root.aiEvent("doaction_entry", "12fab5746dff373fa198060ff96b1f32a77b4d3a47bc98674649ad4f4ad41684," + escape(String(this)) + "," + _currentframe);
动作 = 0;
