_root.aiEvent("doaction_entry", "1547d101adba872318a5e8b1830f3c4473680e167ce2e9ff3a753a00890a2912," + escape(String(this)) + "," + _currentframe);
kcplayed = 3;
