_root.aiEvent("doaction_entry", "bfb81860d35c5961034d55bd3ec736b030a97fce6517ba493e571927a4199de5," + escape(String(this)) + "," + _currentframe);
_root._y -= 2;
