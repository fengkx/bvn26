_root.aiEvent("doaction_entry", "879d27bbf07573c67d4eb4737e964b9f18d98b17f971ee70e8c15d8c592ef550," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
