_root.aiEvent("doaction_entry", "968829ce46982da72767bb72a624c54baf41b2c10a2ae78c9f8d8e2e9fa8f4e7," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
