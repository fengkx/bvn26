_root.aiEvent("doaction_entry", "0cd0ccccccab2279c538251c572512ec14e865941abd2b9447e57dc914f33140," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
