_root.aiEvent("doaction_entry", "e2140f87cf3e262870e63ed4a2c5b7c2f8df325c62df4ea1974b3ebd50e3d57a," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
jump = 1;
