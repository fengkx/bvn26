_root.aiEvent("doaction_entry", "87f99e9f461dd3ab39fc65413ebfc3bd877f5b79220bfb3b09d3c55abe917d7f," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"白一护2");
