_root.aiEvent("doaction_entry", "fc906c0d08728a6d0abb6f779c9db5c1fd0fbfe00753cb22547b3a80cbd46b15," + escape(String(this)) + "," + _currentframe);
_root.cbsd(pn);
_root.showFace(pn,"白一护2");
