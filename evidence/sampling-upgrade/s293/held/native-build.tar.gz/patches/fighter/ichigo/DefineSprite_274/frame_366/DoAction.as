_root.aiEvent("doaction_entry", "860b9f75b52095adbcc64ea208d75d8fd193f1895f88f5bdf772395013598202," + escape(String(this)) + "," + _currentframe);
动作 = 0;
