_root.aiEvent("doaction_entry", "ce2eb4f754dc597471c50d985a8a84bd12723b09450a16314b17f5fbdc7214a6," + escape(String(this)) + "," + _currentframe);
动作 = 0;
