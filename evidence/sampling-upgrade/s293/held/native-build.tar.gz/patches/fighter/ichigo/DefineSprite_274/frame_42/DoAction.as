_root.aiEvent("doaction_entry", "c33750dfbb9b4d44d3d134ef9891154302b12565e3a79f436902ba71a7b08217," + escape(String(this)) + "," + _currentframe);
jump = 1;
