_root.aiEvent("doaction_entry", "1bd0eb53c90378f1436f3922e63abd27a0bbf66bd305a023ac9b967607421e17," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
