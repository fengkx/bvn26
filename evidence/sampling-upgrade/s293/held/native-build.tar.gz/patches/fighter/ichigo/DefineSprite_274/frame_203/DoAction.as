_root.aiEvent("doaction_entry", "ec44b09dff884d1a1207dfffb0635f93c7324be49f371f9e0daed57a751b5cd2," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
