_root.aiEvent("doaction_entry", "d587084884ec221f5fdaa1d4647979d860e8053bd5589b24bbd22b0e2a4c204b," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
