_root.aiEvent("doaction_entry", "e428cbb74a9e5f4dc4630c0bffcf01bc22a964f2195a419f43407f5421b7a564," + escape(String(this)) + "," + _currentframe);
jump = 0;
