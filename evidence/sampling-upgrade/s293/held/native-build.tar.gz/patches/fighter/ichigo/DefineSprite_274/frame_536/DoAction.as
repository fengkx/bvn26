_root.aiEvent("doaction_entry", "d433c3265613070ab22a115efb99e23dbbb65a672a13352bd432aa0861b333c0," + escape(String(this)) + "," + _currentframe);
doZhaoHuan();
