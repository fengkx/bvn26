_root.aiEvent("doaction_entry", "dbf4359efac8513aaa268793bafe0f35db3b6213d82312a076349f2e2d5fce08," + escape(String(this)) + "," + _currentframe);
_root.shine();
