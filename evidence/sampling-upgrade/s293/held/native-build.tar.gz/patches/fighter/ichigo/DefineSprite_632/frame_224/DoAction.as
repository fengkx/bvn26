_root.aiEvent("doaction_entry", "6fbdb191c24846f8e16dc6e7b6ba1cb0dc816930ca45bfd6ce100d8832599083," + escape(String(this)) + "," + _currentframe);
动作 = 0;
