_root.aiEvent("doaction_entry", "036c8544f4382b5d88887f5b3d8e888192515a1b0bbb9dbf38317a85992255c2," + escape(String(this)) + "," + _currentframe);
onBeHit();
