_root.aiEvent("doaction_entry", "02fd746f91b87ddbc0c0423fee501024d90c2945da5e7e705d2f854f284ddde1," + escape(String(this)) + "," + _currentframe);
动作 = 1;
