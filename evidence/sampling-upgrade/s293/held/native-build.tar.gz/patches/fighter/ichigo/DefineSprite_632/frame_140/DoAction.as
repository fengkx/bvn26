_root.aiEvent("doaction_entry", "71deaeb5516e51117fca0891ca8cf7b53725c45541e3baa0c30de943ed47abf3," + escape(String(this)) + "," + _currentframe);
khit = 1;
jump = 0;
jumped = 0;
动作 = 1;
ql += 5;
