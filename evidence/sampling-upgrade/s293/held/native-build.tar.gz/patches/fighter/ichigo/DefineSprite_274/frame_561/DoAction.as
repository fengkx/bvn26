_root.aiEvent("doaction_entry", "1cf55fa7f3724e28ff908ebe55d1aa0767278015ee002ce3b69da64d2f7f6e63," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
