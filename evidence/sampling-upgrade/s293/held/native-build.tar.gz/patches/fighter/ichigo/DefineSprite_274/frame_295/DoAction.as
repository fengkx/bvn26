_root.aiEvent("doaction_entry", "ccf884909b0397e8662b90e11c8cf17c87fb877d2fc9a3da185a8d69bdf08ce0," + escape(String(this)) + "," + _currentframe);
动作 = 0;
