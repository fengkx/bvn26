_root.aiEvent("doaction_entry", "f8b29313eb361af7ca1bd142294942fccc072b22b649889a6266e6d433e6fbe6," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
