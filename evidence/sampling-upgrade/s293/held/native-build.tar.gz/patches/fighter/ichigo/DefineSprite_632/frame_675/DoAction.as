_root.aiEvent("doaction_entry", "72682c22deb5517cf3231789c5fcc73d4fe387abf562445377dfe538cbad7c9c," + escape(String(this)) + "," + _currentframe);
动作 = 0;
