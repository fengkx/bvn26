_root.aiEvent("doaction_entry", "fbb3e7318a0c47105453bd1b1136cc77a32ad14398ec20857daf39efe6eab321," + escape(String(this)) + "," + _currentframe);
play();
