_root.aiEvent("doaction_entry", "c9dfcdc53df27b593057aab750f6f3406f6f15d28efaf4279a0819b332b2edaf," + escape(String(this)) + "," + _currentframe);
khit = 0;
jump = 0;
