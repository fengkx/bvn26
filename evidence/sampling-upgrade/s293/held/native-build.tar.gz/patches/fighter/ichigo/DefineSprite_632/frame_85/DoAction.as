_root.aiEvent("doaction_entry", "8af71968b63982bc14d73356c6c6a08084d7989b809e49cf78518002eb5e9b32," + escape(String(this)) + "," + _currentframe);
jump = 0;
