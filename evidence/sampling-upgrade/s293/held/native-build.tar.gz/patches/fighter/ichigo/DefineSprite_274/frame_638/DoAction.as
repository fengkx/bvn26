_root.aiEvent("doaction_entry", "56eddfd56fba30ede974ccadcee79767f89c17f4302ff1490f5791ef3ef453db," + escape(String(this)) + "," + _currentframe);
stop();
