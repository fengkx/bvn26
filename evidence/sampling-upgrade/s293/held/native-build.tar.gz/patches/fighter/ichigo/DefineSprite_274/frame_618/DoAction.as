_root.aiEvent("doaction_entry", "f016fbcbf3180dfc3b893021143954bf0a8279eb6be985ef23f3eec9721079b5," + escape(String(this)) + "," + _currentframe);
onBeHit();
