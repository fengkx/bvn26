_root.aiEvent("doaction_entry", "e0f25605ef9143233b72bc8ef47e286c2ca586cbc320251a8a2b0391ef9ec8b8," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
