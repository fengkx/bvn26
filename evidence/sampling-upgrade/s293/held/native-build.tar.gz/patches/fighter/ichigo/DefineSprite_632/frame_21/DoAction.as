_root.aiEvent("doaction_entry", "37d7baf35b83a369b71861558b13611551f3be2d3b97c54ae5cda5be4162dae6," + escape(String(this)) + "," + _currentframe);
_root.shunbuxg(_parent);
