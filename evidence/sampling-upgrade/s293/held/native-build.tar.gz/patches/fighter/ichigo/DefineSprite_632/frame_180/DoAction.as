_root.aiEvent("doaction_entry", "8694cedd8dd07c19b0a932f662c9ae7f340f23e54fca677a17b1bfb80548e8e8," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
