_root.aiEvent("doaction_entry", "5d384662a066472008199249ae95c27a63178a4c10c93f0a0a8b8b7f8d10f479," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
jump = 1;
