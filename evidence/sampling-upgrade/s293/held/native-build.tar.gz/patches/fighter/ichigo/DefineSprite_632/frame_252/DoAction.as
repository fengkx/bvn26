_root.aiEvent("doaction_entry", "7383cb32ade354e26f4f030342ffe4a4c5cbc2e2a8b19e65fa43226c2f8c8617," + escape(String(this)) + "," + _currentframe);
动作 = 0;
