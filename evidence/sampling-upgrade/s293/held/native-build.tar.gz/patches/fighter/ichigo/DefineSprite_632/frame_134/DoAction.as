_root.aiEvent("doaction_entry", "b658be6767b23db8b47d9d0a5fa76dcfc667191353656f4e84226d42d161d7ab," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
