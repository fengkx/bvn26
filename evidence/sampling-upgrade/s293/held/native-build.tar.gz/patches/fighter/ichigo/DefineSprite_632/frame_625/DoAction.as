_root.aiEvent("doaction_entry", "d6a2c82f1aee62716dbe0b13a104d5905cf2a5dee8de4cbf2c7a94c51d77dd84," + escape(String(this)) + "," + _currentframe);
动作 = 0;
