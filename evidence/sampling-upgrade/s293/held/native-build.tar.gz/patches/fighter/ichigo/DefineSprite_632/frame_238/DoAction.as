_root.aiEvent("doaction_entry", "2ebd8be52f0968e37188812b8ec58ba7ce1684ebf6bbc781446bc073bdf4d4b3," + escape(String(this)) + "," + _currentframe);
动作 = 1;
