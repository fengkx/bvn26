_root.aiEvent("doaction_entry", "18f08b6ee367c83a0c5425d037d93d0457cb189cf28efb081c01edd811759d7a," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
bs = 0;
