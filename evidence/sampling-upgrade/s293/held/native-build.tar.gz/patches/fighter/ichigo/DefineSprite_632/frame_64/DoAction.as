_root.aiEvent("doaction_entry", "be4d01a9a2760d396ee5b30d3c0cad9b26c0322dc5009dd789f42c677fbd30a9," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
