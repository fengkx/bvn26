_root.aiEvent("doaction_entry", "1251f9e4a837bc8560b6fb468d03a4f6131f8b45b014683d1e5421b8375899f3," + escape(String(this)) + "," + _currentframe);
onBeHit(true);
