_root.aiEvent("doaction_entry", "fc046da675a7534db3354594599a5ea31ca727ecd6c79dfcfe7117bc29864f2a," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
jump = 1;
