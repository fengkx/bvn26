_root.aiEvent("doaction_entry", "ac65b565800cb1f1fe645b44c8c57dce866a176059d617631c972b8c64193b29," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
