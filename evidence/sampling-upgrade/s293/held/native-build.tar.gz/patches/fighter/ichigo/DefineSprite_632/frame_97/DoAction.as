_root.aiEvent("doaction_entry", "6e793046356d563103ccf71ec860d4dc55fcd20a00994cace028bc3eaba8863f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
