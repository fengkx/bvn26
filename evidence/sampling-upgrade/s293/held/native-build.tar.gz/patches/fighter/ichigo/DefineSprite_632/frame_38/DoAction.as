_root.aiEvent("doaction_entry", "fe5cd47dbff0616ad0e713c7b959b42ed4b6396d791e9a6d044808583d91a2cf," + escape(String(this)) + "," + _currentframe);
jump = 1;
