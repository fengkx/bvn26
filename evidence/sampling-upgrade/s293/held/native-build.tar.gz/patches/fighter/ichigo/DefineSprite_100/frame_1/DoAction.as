_root.aiEvent("doaction_entry", "e46f2dc041b5427509a1007800ba6c6970a69156631e91f62c1fff54ae0ec21e," + escape(String(this)) + "," + _currentframe);
stop();
var movspeed = 10;
var played = 0;
