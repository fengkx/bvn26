_root.aiEvent("doaction_entry", "2fe7c2146c6a24944d07c45990c2353f653d17b0c2db6dc912d2999ff0c23f7c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
