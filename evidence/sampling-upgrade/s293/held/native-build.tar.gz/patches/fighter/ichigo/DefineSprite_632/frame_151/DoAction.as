_root.aiEvent("doaction_entry", "843416004a3d456109c5dd817b9f015f499f87536935e6ae40ec98500482d345," + escape(String(this)) + "," + _currentframe);
gotoAndPlay(146);
