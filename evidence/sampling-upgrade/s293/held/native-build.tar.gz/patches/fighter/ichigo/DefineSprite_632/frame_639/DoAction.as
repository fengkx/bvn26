_root.aiEvent("doaction_entry", "758aef84a6faa64c64c8a0ff5e750249a4b370b49029b6e16f1f3902e35b3544," + escape(String(this)) + "," + _currentframe);
_root.shine(16711680);
