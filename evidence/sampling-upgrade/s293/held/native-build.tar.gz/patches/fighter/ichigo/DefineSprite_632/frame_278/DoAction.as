_root.aiEvent("doaction_entry", "28eb19280ad96611c778091b0640eab1265f40bc7b6c1e055b18d1811030073f," + escape(String(this)) + "," + _currentframe);
动作 = 0;
