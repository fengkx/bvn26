_root.aiEvent("doaction_entry", "9688a77013b0fc412df59becd9b539eada7b3b08d04749fe95ee70f7dc3999db," + escape(String(this)) + "," + _currentframe);
_root._y += 3;
