_root.aiEvent("doaction_entry", "a888f123b72d35993196b2aca30f3b2cc1d6090a9bfbe54417f1d37900d30f63," + escape(String(this)) + "," + _currentframe);
onDefence();
