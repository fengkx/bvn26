_root.aiEvent("doaction_entry", "62749d1971dcdabc645cc8b4120a940985172a98cd2a9b87225cc85e25dfacb7," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
