_root.aiEvent("doaction_entry", "df7e500aee95517289b2f7474049bc9f1d62e2d142bd5a9069a776bb94622cb4," + escape(String(this)) + "," + _currentframe);
动作 = 1;
