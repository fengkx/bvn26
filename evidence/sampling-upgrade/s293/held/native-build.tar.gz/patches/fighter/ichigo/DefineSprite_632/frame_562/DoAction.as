_root.aiEvent("doaction_entry", "8e16570bc9f62e320c06cba03d5e82c5706ffc7b6b8aca3bbc34a3faf086f382," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
