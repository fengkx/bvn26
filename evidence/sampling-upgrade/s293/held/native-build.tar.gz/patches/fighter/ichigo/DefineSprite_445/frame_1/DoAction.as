_root.aiEvent("doaction_entry", "02f76ba89bb8ebf07f848b3cc2bde28057b8e1ec9b022f4e7112d3c21690f42a," + escape(String(this)) + "," + _currentframe);
stop();
var movspeed = 30;
var played = 0;
