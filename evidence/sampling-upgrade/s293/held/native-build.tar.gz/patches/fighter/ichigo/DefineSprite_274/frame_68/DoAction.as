_root.aiEvent("doaction_entry", "f5f37a8da0324f275c8467ad8094ab48beeb10c3ff497d634f68e4105bf8cb2d," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落");
play();
