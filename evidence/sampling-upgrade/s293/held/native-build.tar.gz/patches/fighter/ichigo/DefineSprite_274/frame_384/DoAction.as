_root.aiEvent("doaction_entry", "2ba3f4d027de5eb69395a95959e1fa3c506aa98c4368f5179053eac7a21e5933," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
jump = 1;
