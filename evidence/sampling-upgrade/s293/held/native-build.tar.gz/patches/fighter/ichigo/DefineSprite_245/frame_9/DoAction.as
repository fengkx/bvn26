_root.aiEvent("doaction_entry", "4b99403669f4db00b2f0b4dfb328a5f0454ab903c3d74dac83cafc079485ab97," + escape(String(this)) + "," + _currentframe);
_root._y -= 3;
