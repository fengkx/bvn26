_root.aiEvent("doaction_entry", "4ba2cdf55ea6911e3ae15bd6c501c1db707ae1ea2eb6358c364fde9731f6c97b," + escape(String(this)) + "," + _currentframe);
if(_parent._xscale > 0)
{
   _parent._x = _root.game["p" + pn]._x - 20;
}
else
{
   _parent._x = _root.game["p" + pn]._x + 20;
}
_parent._y = _root.game["p" + pn]._y;
