_root.aiEvent("doaction_entry", "1dbd30baf4e0ac39ee11a0c96c10d1bf261891dd5506003daff6969b506977ea," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
