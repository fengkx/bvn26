_root.aiEvent("doaction_entry", "9572b964a8b7d15508c6d9800d5b9fb37b316ba3e2c29151dd36fdbb244c7dcf," + escape(String(this)) + "," + _currentframe);
动作 = 0;
