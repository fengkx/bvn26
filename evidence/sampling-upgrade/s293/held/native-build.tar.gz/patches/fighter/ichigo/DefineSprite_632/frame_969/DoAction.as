_root.aiEvent("doaction_entry", "45c21b47d9a2a15a63b496806914f9a003c841f347b82f09e8c4856d6984bb25," + escape(String(this)) + "," + _currentframe);
kcplayed = 1;
