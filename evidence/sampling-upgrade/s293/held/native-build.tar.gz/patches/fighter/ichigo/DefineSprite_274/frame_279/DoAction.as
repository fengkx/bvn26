_root.aiEvent("doaction_entry", "06db15303f92badcd48a1b8472b1cfd0d7416fe051496ac526ede33c57c886fd," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
