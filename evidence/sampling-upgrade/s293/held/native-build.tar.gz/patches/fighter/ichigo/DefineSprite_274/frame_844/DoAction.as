_root.aiEvent("doaction_entry", "a31747c7d9a1c964a9f6bcd7bcdd78876ab41ece34c40cabfd469d7cb08fbffb," + escape(String(this)) + "," + _currentframe);
wankai_start();
