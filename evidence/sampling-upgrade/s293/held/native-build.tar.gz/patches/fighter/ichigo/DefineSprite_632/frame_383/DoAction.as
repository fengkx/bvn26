_root.aiEvent("doaction_entry", "33731a48b6f39b4743c2a151146337b072b57198bb796d61b17432064a44884e," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
