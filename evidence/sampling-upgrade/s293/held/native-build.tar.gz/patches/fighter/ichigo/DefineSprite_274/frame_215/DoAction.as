_root.aiEvent("doaction_entry", "85f45a5f81448aa77a1e8cfa5af8f5d60897809d2c3b53351c549a59af300cd6," + escape(String(this)) + "," + _currentframe);
动作 = 0;
