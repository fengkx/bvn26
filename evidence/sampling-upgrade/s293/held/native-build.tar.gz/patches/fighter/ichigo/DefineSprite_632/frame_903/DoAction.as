_root.aiEvent("doaction_entry", "5f2d8fd7c503acc5f39571494463267e9b04ae5a811d3726b1654f6ff89cc636," + escape(String(this)) + "," + _currentframe);
stop();
