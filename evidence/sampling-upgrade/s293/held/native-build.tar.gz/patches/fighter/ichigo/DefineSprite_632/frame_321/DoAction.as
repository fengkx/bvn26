_root.aiEvent("doaction_entry", "d6d514c2fe1189dc29877d00d16cd1abdce768b4c65076324ba08987947c8778," + escape(String(this)) + "," + _currentframe);
动作 = 0;
