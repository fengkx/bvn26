_root.aiEvent("doaction_entry", "6dc396c2859e8adc9f3b6979e6ff4ab978a12dcb13bc3d2bb27ece825da89fc0," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
