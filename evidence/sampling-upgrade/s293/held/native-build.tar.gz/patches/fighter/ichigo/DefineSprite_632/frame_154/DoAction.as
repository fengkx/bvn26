_root.aiEvent("doaction_entry", "62c98698866bd9f9882ae219ae5b000ed1ddb65a2be78d6811b350eddeec983a," + escape(String(this)) + "," + _currentframe);
jump = 0;
动作 = 0;
