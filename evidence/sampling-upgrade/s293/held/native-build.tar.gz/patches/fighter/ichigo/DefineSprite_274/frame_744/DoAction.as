_root.aiEvent("doaction_entry", "253ddbb5c058e063405f0076660a6bcfc053c4986bb3f8c48f1fc89dd27966ba," + escape(String(this)) + "," + _currentframe);
kcplayed = 2;
gotoAndStop("站立");
play();
