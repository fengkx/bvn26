_root.aiEvent("doaction_entry", "0bec67ebec169f07f67e5ce49aeed47b932f20a012fafdc6f02c7fc54039f53f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
