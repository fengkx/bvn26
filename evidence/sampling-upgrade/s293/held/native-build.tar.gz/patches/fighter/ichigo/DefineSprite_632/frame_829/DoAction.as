_root.aiEvent("doaction_entry", "1effbc42988677ab2536cbe207beba2ad4a62ab1daedde1cfc51302093dfae91," + escape(String(this)) + "," + _currentframe);
doZhaoHuan();
