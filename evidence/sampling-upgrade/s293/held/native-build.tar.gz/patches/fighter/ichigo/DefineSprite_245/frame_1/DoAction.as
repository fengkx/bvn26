_root.aiEvent("doaction_entry", "378e765d1b81aae2141870d4119a20ee90a4ae1d94e37d6496fa37fa3545d19a," + escape(String(this)) + "," + _currentframe);
_root._y -= 5;
