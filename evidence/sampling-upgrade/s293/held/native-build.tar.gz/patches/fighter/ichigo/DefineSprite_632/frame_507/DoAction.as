_root.aiEvent("doaction_entry", "8e27ccd5c72662edc85d23dfb9a7421169cf98ccd9c2193bf8a8bf846a79f24b," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"白一护1");
