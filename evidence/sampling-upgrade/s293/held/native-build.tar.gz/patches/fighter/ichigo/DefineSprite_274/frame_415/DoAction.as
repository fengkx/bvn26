_root.aiEvent("doaction_entry", "a29acafc270d90d65eebbe9c3b78a060de1d0b0cbd08a76f385b04e88e73984a," + escape(String(this)) + "," + _currentframe);
if(_root.game["p" + pn].mc.动作 != -1)
{
   gotoAndStop("站立");
   play();
}
