_root.aiEvent("doaction_entry", "afd7f7417de5fb76492dbf3c85ba51f64ec10b402628e2b6bf0ac2fefc8a1183," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
