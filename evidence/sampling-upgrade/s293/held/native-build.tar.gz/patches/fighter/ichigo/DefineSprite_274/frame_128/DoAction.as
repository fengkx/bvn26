_root.aiEvent("doaction_entry", "7e3c4dcf0fde86d4c2c924ed9229d6f5d32e223b34557cb117a616bf7fd65105," + escape(String(this)) + "," + _currentframe);
khit = 1;
动作 = 1;
