_root.aiEvent("doaction_entry", "e25d5a7d1f3fb555a0c83682f52c09bed6ede13950ba2685cbf3100d1a5ced4d," + escape(String(this)) + "," + _currentframe);
动作 = 3;
bs = 1;
ql -= 100;
jump = 1;
