_root.aiEvent("doaction_entry", "78af033d28fa8c3488c36ec237626cdb2161e040961ddadceb2e3f6d58348d5b," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
