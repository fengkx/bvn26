_root.aiEvent("doaction_entry", "86eb77c2f9c2b89faac60deb21e03f2a68d5a6cd161a90a05eea5c1c35e545b9," + escape(String(this)) + "," + _currentframe);
动作 = 0;
