_root.aiEvent("doaction_entry", "591d087a371e544934f18a4e0656dd4900fca4717dc70a04d5080e8a8f51567f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
