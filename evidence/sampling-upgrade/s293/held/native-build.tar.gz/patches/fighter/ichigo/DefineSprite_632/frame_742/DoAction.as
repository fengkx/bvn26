_root.aiEvent("doaction_entry", "410691624ec1d43df27b08e3d51699941f6ee29cb76098c0e61b86229aa3d079," + escape(String(this)) + "," + _currentframe);
_root.cbsw(pn);
bs = 0;
