_root.aiEvent("doaction_entry", "5334176e5f94771f45c8982bbebfe7875fc0aedb24676ca8171a0b08505761f2," + escape(String(this)) + "," + _currentframe);
stop();
