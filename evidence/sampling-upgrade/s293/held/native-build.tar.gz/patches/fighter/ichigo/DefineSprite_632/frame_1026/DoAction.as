_root.aiEvent("doaction_entry", "30bc5293d5a5ec68f619abe8714d114e1dcab8e8c7822748e1cbc88443d60f5a," + escape(String(this)) + "," + _currentframe);
kcplayed = 2;
gotoAndStop("站立");
play();
