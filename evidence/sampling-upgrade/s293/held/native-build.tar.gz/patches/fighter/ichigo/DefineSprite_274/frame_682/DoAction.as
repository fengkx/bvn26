_root.aiEvent("doaction_entry", "d2ec0cc7a0d4727a4fcc07fec8b224e0c9ff25de6b4b949a7c5154c827e8aec1," + escape(String(this)) + "," + _currentframe);
_root._y = 0;
