_root.aiEvent("doaction_entry", "72685a3a96a59102d1caf9677bb993522f5e163affd2110e43ae80da8018f3a7," + escape(String(this)) + "," + _currentframe);
wankai();
