_root.aiEvent("doaction_entry", "4fc93cf273e04a29472ed83306d962797cecc6b042e81bec2e41ca89aae6bce1," + escape(String(this)) + "," + _currentframe);
_root.shine(1183014);
_root.shine();
