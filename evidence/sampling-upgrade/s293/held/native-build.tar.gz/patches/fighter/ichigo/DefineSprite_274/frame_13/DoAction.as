_root.aiEvent("doaction_entry", "f3783d19e8fced1da79dce43377aa6bbddaf539b4fb5c0b65d9914490ef559fb," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
