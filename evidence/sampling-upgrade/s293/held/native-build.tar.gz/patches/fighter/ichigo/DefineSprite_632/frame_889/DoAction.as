_root.aiEvent("doaction_entry", "5c0ecb365c8b5dc4230d08fee81af63ad2fa5520e60c3e1e533480ced2cfc34e," + escape(String(this)) + "," + _currentframe);
stop();
