_root.aiEvent("doaction_entry", "3c6e30a35a0dcb4b81b48a9a9fcc333d266d988b79bf52608935b5651a323755," + escape(String(this)) + "," + _currentframe);
play();
