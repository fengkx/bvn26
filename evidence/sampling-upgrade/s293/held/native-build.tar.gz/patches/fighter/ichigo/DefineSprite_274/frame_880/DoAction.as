_root.aiEvent("doaction_entry", "8a1219b4bd12dc9bec7e7e2a90b617c1d7f801c34d6741031276dc40398e00bf," + escape(String(this)) + "," + _currentframe);
_root.shine(9697014);
