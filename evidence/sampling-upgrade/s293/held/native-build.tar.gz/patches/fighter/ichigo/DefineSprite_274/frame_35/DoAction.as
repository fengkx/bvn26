_root.aiEvent("doaction_entry", "e6a3e33c96b7d0e16b64f8c1cd6014d5d8eb768e44ce681b977274df3adc48a2," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
