_root.aiEvent("doaction_entry", "eef3dc0aa63b641b5bdba37a9b5620ca9c5734fe2d58e2533ea625f6ea02c86c," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
