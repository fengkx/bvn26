_root.aiEvent("doaction_entry", "38fadb1fd01f52405ffc283d682aaeef3d576110cb0d183bf514e8ebf5a12566," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"一户1");
