_root.aiEvent("doaction_entry", "2c76c64cb934f3dbb05afdd9743cd3f290bfae6abc1cefb50770dd66443647f9," + escape(String(this)) + "," + _currentframe);
_root._y -= 4;
