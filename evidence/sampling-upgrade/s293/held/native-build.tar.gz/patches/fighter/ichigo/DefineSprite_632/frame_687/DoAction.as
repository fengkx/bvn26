_root.aiEvent("doaction_entry", "2373f90992d2b8c89dbbbdc155b9e935f5d0b0aaf3cb10bcf18581cd76d82826," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
