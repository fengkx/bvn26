_root.aiEvent("doaction_entry", "34a04d33880320bcf53d5e66b8a37fbbb15ca8047eaa97d3e46e225a09c93c9b," + escape(String(this)) + "," + _currentframe);
gotoAndStop("落2");
play();
