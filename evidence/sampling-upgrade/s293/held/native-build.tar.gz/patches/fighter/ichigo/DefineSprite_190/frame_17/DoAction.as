_root.aiEvent("doaction_entry", "b6e009ed65351f71ada3a5fe32bbd2a362a24bc44a7acdac8ce9d79e22e67c09," + escape(String(this)) + "," + _currentframe);
stop();
