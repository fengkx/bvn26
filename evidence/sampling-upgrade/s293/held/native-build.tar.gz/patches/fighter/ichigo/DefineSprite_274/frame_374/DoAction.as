_root.aiEvent("doaction_entry", "b5f235796f639cf18ebd6b2fc0252d970ac567bb5492b0e7226791a065e5755f," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
