_root.aiEvent("doaction_entry", "8f80eeb26fa7935d0121768cb28f5db0945271946dc30641d3c31d70fab64a45," + escape(String(this)) + "," + _currentframe);
hited = 0;
play();
