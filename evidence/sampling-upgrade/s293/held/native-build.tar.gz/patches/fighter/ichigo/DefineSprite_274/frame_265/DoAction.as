_root.aiEvent("doaction_entry", "37d1a9fa3702c9fe9f3775113bb9e24658cdeec9e0d717636ce0bb5b41a596c6," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
