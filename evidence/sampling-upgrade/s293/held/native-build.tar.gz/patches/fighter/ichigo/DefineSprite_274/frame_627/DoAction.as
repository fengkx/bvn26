_root.aiEvent("doaction_entry", "fe62aaa3279ccbf6838fb1274f2eb5c6ea977a5a1540f0818686962aa6393ac5," + escape(String(this)) + "," + _currentframe);
jump = 0;
jumped = 1;
gotoAndStop("站立");
play();
