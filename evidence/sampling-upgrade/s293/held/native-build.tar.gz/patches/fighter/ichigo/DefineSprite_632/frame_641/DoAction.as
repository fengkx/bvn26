_root.aiEvent("doaction_entry", "4d719bbf4352f68ee3e08a3dbdff84f580854748cfbfd31b4fb96eb536891a53," + escape(String(this)) + "," + _currentframe);
_root.bsd(pn);
_root.showFace(pn,"白一护1");
