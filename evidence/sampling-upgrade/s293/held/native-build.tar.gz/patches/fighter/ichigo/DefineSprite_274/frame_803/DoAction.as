_root.aiEvent("doaction_entry", "4cd4d431ec71042279a5b97838801442f286ce9d192fa1ab3594f17c7dd09143," + escape(String(this)) + "," + _currentframe);
stop();
