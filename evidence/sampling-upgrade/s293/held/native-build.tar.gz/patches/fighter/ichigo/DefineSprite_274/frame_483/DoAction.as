_root.aiEvent("doaction_entry", "3947a364f1024741e1315b6a5b3b0d96f97aa3c0978631c08aac84c2a6d1d830," + escape(String(this)) + "," + _currentframe);
_root.bsw(pn);
