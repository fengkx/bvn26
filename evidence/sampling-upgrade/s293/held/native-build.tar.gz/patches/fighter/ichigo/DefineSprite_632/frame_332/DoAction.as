_root.aiEvent("doaction_entry", "11d7798231b2d30b37dd60fe1fb4c87538600e96943890fca68800035b49a651," + escape(String(this)) + "," + _currentframe);
gotoAndStop("站立");
play();
