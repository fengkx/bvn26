_root.aiEvent("doaction_entry", "f55184e712713e781e5b1d33c2f663a8bf14a6a9cab564e3394f3bff302d0a32," + escape(String(this)) + "," + _currentframe);
onBeHit(true);
