_root.aiEvent("doaction_entry", "2fff696f1218a9f07faba8121ce27630d391b5014ebde27681c0521a448e6967," + escape(String(this)) + "," + _currentframe);
_root._y += 2;
_root.shine();
