_root.aiEvent("doaction_entry", "4a9119526b28b7f2b2cddc8d57cebb0c8d7f996b09a75f849667ef373cd84746," + escape(String(this)) + "," + _currentframe);
if(sw == true)
{
   stop();
}
