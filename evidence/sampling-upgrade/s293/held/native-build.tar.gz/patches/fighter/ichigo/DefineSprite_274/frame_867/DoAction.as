_root.aiEvent("doaction_entry", "871478dcd343144f17bb65324ccfd65a480ef8724001036c1359e74d60140e87," + escape(String(this)) + "," + _currentframe);
_root.touchFloorEffect(_parent);
