onClipEvent(unload) { _root.s265Life(this,"unload"); }
