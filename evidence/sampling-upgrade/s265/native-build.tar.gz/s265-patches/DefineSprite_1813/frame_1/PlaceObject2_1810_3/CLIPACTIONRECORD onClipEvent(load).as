onClipEvent(load) { _root.s265Life(this,"load"); }
