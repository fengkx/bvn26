_root.s274Generation = 0;
_root.s274Life = function(mc, phase)
{
   if(phase == "load") { mc.s274Generation = ++_root.s274Generation; }
   if(phase == "unload" && mc.s274Generation == 2) _root.s274Unloaded2 = true;
   _root.aiEvent("s274_life", phase + "," + String(mc) + "," + mc.getDepth() + "," + mc.s274Generation + "," + mc._currentframe);
};
_root.s274Entry = function(mc)
{
   if(mc.s274Generation == 2 && _root.aiFight == 1) _root.s274RetainedEntry2 = true;
   _root.aiEvent("s274_entry", String(mc) + "," + mc.getDepth() + "," + mc.s274Generation + "," + mc._currentframe);
};
_root.s274State = function(phase, mc)
{
   _root.aiEvent("s274_state", phase + "," + String(mc) + "," + mc.getDepth() + "," + mc.s274Generation + "," + mc._currentframe);
};
_root.s274Sample = function()
{
   var timer = _root.s258Timer;
   _root.s274State("sample", timer.个);
   if(_root.aiFight == 0)
   {
      timer.个.duplicateMovieClip("__s274Control", 100001);
      timer.__s274Control._visible = false;
      _root.aiEvent("s274_control", "created");
   }
   if(_root.aiFight == 1)
   {
      _root.s274State("retained_before", timer.__s274Control);
      timer.__s274Control.gotoAndStop(2);
      timer.__s274Control.gotoAndStop(1);
      _root.s274State("retained_after", timer.__s274Control);
   }
   if(_root.aiFight == 2)
   {
      _root.s274State("replace_before", timer.__s274Control);
      timer.__s274Control.removeMovieClip();
      timer.个.duplicateMovieClip("__s274Control", 100001);
      timer.__s274Control._visible = false;
      _root.aiEvent("s274_control", "replaced");
   }
   if(_root.aiFight == 3)
   {
      _root.s274State("replace_after", timer.__s274Control);
      _root.s274Calibrated = timer.__s274Control.s274Generation == 3
         && _root.s274Unloaded2 == true && _root.s274RetainedEntry2 == true;
   }
   if(_root.aiFight == 5)
   {
      _root.s274State("encoded_retained_before", timer.__s274Control);
      timer.__s274Control.gotoAndStop(2);
      timer.__s274Control.gotoAndStop(1);
      _root.s274State("encoded_retained_after", timer.__s274Control);
   }
   if(_root.aiFight == 6)
   {
      _root.s274State("encoded_replace_before", timer.__s274Control);
      timer.__s274Control.removeMovieClip();
      timer.个.duplicateMovieClip("__s274Control", 100001);
      timer.__s274Control._visible = false;
   }
   if(_root.aiFight == 7) _root.s274State("encoded_replace_after", timer.__s274Control);
   if(_root.aiFight == 8) timer.__s274Control.removeMovieClip();
   _root.aiEvent("s274_boundary", "before");
   _root.s262Snapshot();
   _root.s258Observe("snapshot_before", timer);
   if(_root.aiFight >= 4)
   {
      // This admits only a bounded observation experiment, never a scene image.
      var digit = timer.个;
      var admitted = _root.s274Calibrated == true && typeof(digit) == "movieclip"
         && digit.s274Generation == 1 && digit.getDepth() == -16381
         && digit._totalframes == 10 && timer._currentframe == 1;
      _root.aiEvent("s274_admission", String(admitted));
      _root.s274State("draw_before", digit);
      if(admitted)
      {
         var image = new flash.display.BitmapData(600,400,false,0);
         _root.aiEvent("s274_memory", "draw_before");
         image.draw(_root);
         _root.aiEvent("s274_memory", "draw_after");
         var chars = 0;
         for(var y=0;y<400;y++)
         {
            var row="";
            var last=image.getPixel32(0,y);
            var count=1;
            for(var x=1;x<=600;x++)
            {
               var value=x<600 ? image.getPixel32(x,y) : -1;
               if(x<600 && value==last) count++;
               else
               {
                  var hex=(last & 0xffffff).toString(16);
                  while(hex.length<6) hex="0"+hex;
                  hex="ff"+hex;
                  row+=hex+":"+count+";";
                  last=value;
                  count=1;
               }
            }
            chars += row.length;
         }
         // Retain only a work-size count; no pixel/row payload leaves memory.
         _root.aiEvent("s274_encoded_size", String(chars));
         image.dispose();
         _root.aiEvent("s274_memory", "encoding_after");
      }
      _root.s274State("draw_after", digit);
   }
   _root.s258Observe("snapshot_after", timer);
   _root.aiEvent("s274_boundary", "after");
};
_root.s262InitSerial = 0;
_root.s262Init = function(mc, symbol)
{
   _root.s262InitSerial++;
   mc.s262InitSerial = _root.s262InitSerial;
   mc.s262InitDisplay = _root.aiDisplay;
   _root.aiEvent("s262_init", String(mc) + "," + symbol + "," + mc.getDepth() + "," + mc.s262InitSerial + "," + mc.s262InitDisplay);
};
_root.s262Node = function(mc, role, level)
{
   if(typeof(mc) != "movieclip") { return; }
   _root.aiEvent("s262_visual", role + "," + String(mc) + "," + mc.getDepth() + "," + mc._currentframe + "," + mc._totalframes + "," + mc.s262InitSerial + "," + mc.s262InitDisplay + "," + mc._x + "," + mc._y + "," + mc._xscale + "," + mc._yscale + "," + mc._rotation + "," + mc._alpha + "," + mc._visible);
   if(level > 0)
   {
      for(var key in mc)
      {
         if(typeof(mc[key]) == "movieclip" && mc[key]._parent == mc)
         {
            _root.s262Node(mc[key], role + "/" + key, level - 1);
         }
      }
   }
};
_root.s262Snapshot = function()
{
   _root.aiEvent("s262_begin", _root.s258Count);
   _root.s262Node(_root.s258Timer, "timer", 1);
   _root.s262Node(_root.xuetiao, "hud", 5);
   _root.s262Node(_root, "root", 0);
   _root.s262Node(_root.game, "camera", 0);
   _root.aiEvent("s262_end", _root.s258Count);
};

_root.s258Count = 0;
_root.s258Observe = function(phase, receiver)
{
   var timer = _root.s258Timer;
   _root.aiEvent("s258_countdown", phase + "," + _root.s258Count + "," + String(receiver) + "," + String(timer) + "," + _root.timeset + "," + _root.gametime + "," + _root.zhanting + "," + _root.game.p1.mc.sw + "," + _root.game.p2.mc.sw + "," + _root.modo + "," + timer.十._currentframe + "," + timer.个._currentframe + "," + timer._currentframe);
};
Stage.displayState = "normal";
Stage.scaleMode = "showAll";
// Capture synchronously before the root observer's terminal boundary.
_root.aiBitmapSample = function() { _root.s274Sample(); };
_root.aiHelperClipFrame = function(helper, instanceName)
{
   var clip = helper[instanceName];
   return clip == undefined ? undefined : clip._currentframe;
};
_root.aiHelperState = function(player)
{
   var f = _root.game[player + "fz"];
   var m = f;
   _root.aiEvent("helper_state", player + "," + m._currentframe + "," + _root.aiNumber(f._x) + "," + _root.aiNumber(f._y) + "," + _root.aiNumber(f._xscale) + "," + m.attacking + "," + m.动作 + "," + m.hits + "," + _root.aiHelperClipFrame(f,"atm1") + "," + _root.aiHelperClipFrame(f,"atm2") + "," + _root.aiHelperClipFrame(f,"atm3"));
   _root.aiEvent("helper_clip_state", player + "," + m._currentframe + "," + "atm1" + "=" + _root.aiHelperClipFrame(f,"atm1"));
   var parent = f._parent;
   _root.aiEvent("helper_lifecycle", player + "," + m._currentframe + "," + f._visible + "," + _root.zhanting + "," + (parent == undefined ? undefined : parent._currentframe) + "," + _root.aiHelperClipFrame(f,"atm1") + "," + _root.aiHelperClipFrame(f,"atm2") + "," + _root.aiHelperClipFrame(f,"atm3"));
};
// Analysis-only binary significand encoding avoids FP32's short decimal strings.
_root.aiNumber = function(value)
{
   if(typeof value != "number" || !isFinite(value)) return String(value);
   if(value == 0) return "f:" + (1 / value < 0 ? -1 : 1) + ":0:0:0";
   var sign = value < 0 ? -1 : 1;
   var fraction = Math.abs(value);
   var exponent = 0;
   while(fraction >= 2) { fraction /= 2; exponent++; }
   while(fraction < 1) { fraction *= 2; exponent--; }
   var mantissa = fraction * 4503599627370496;
   var high = Math.floor(mantissa / 67108864);
   var low = mantissa - high * 67108864;
   return "f:" + sign + ":" + exponent + ":" + high + ":" + low;
};
// Analysis-only bootstrap: the original battle loader and AI remain active.
_root.aiRun = "s274-lifetime-r01";
_root.aiSeq = 0;
_root.aiDisplay = 0;
_root.aiFight = -1;
_root.aiDraw = 0;
_root.aiClockDraw = 0;
_root.aiNativeRandom = Math.random;
_root.aiEvent = function(kind, value)
{
   trace("AIREF|" + aiRun + "|" + (++aiSeq) + "|" + getTimer() + "|" + aiDisplay + "|" + aiFight + "|" + kind + "|" + value);
};
_root.aiTimer = function(site)
{
   var value = getTimer();
   _root.aiEvent("clock", (++_root.aiClockDraw) + "," + site + "," + value);
   return value;
};
_root.aiRandom = function(site)
{
   var value = _root.aiNativeRandom();
   _root.aiEvent("random", (++_root.aiDraw) + "," + site + "," + _root.aiNumber(value));
   return value;
};
_root.aiPredicate = function(name, receiver, value)
{
   if(receiver._parent._parent.useAI || receiver._parent.useAI)
   {
      _root.aiEvent("predicate", name + "," + receiver + "," + value);
   }
   return value;
};
_root.aiState = function(player)
{
   var f = _root.game[player];
   var m = f.mc;
   _root.aiEvent("state", player + "," + m._currentframe + "," + _root.aiNumber(f._x) + "," + _root.aiNumber(f._y) + "," + _root.aiNumber(f._xscale) + "," + m.动作 + "," + _root.aiNumber(m.hp) + "," + _root.aiNumber(m.ql) + "," + m.sw + "," + m.touch + "," + m.touchFloor + "," + m.hits + "," + _root.zhanting + "," + m.hstm + "," + m.hurtSkling);
};
_root.aiGeometry = function()
{
   var f = _root.game.p2;
   var m = f.mc;
   var target = _root.game.p1.mc.bdmn;
   var names = ["kanmian","tkanmian","zh1mian","zh2mian","zh3mian","kj1mian","kj2mian","bsmian","sbsmian","cbsmian","tzmian","absmian"];
   _root.aiEvent("geometry_frame", m._currentframe + "," + f._x + "," + f._y + "," + f._xscale);
   var chain = [f,m,m.AImain];
   for(var c = 0; c < chain.length; c++)
   {
      var cm = chain[c].transform.matrix;
      var gm = chain[c].transform.concatenatedMatrix;
      _root.aiEvent("geometry_matrix", c + "," + cm.a + "," + cm.b + "," + cm.c + "," + cm.d + "," + cm.tx + "," + cm.ty + "," + gm.a + "," + gm.b + "," + gm.c + "," + gm.d + "," + gm.tx + "," + gm.ty);
   }
   for(var n = 0; n < names.length; n++)
   {
      var obj = m.AImain[names[n]];
      var bounds = obj.getBounds(f);
      _root.aiEvent("sensor_bounds", names[n] + "," + bounds.xMin + "," + bounds.yMin + "," + bounds.xMax + "," + bounds.yMax + "," + obj.hitTest(target));
      var own = obj.getBounds(obj);
      var sm = obj.transform.matrix;
      _root.aiEvent("sensor_local", names[n] + "," + own.xMin + "," + own.yMin + "," + own.xMax + "," + own.yMax + "," + sm.a + "," + sm.b + "," + sm.c + "," + sm.d + "," + sm.tx + "," + sm.ty);
   }
};
function showCommt()
{
   if(allowGoLink)
   {
      goLink();
      return undefined;
   }
   if(_global.bridge)
   {
      _global.bridge.showGameList();
   }
}
function goLink(url)
{
}
_root.ver = "V 2.6";
_root.date_ver = "2016/6/23";
var adType;
var wudi = false;
var TYPE_4399 = "4399";
var allowGoLink = true;
var NO_AD = "no-ad";
var debuging = true;
adType = TYPE_4399;
var _loc0_;
if((_loc0_ = adType) === TYPE_4399)
{
   _global.bridge = AS2_4399_API.Bridge.getInstance();
   var _4399_function_ad_id = "944c23f5e64a80647f8d0f3435f5c7a8";
   allowGoLink = false;
}

gotoAndPlay(6);
