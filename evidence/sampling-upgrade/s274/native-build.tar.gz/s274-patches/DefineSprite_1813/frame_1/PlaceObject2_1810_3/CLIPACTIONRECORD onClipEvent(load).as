onClipEvent(load) { _root.s274Life(this,"load"); }
