onClipEvent(unload) { _root.s274Life(this,"unload"); }
