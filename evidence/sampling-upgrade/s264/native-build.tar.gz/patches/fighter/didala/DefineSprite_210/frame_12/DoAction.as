stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_210/frame_12/DoAction.as");
