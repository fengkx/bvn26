stop();
var movspeed = 25;
var played = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_210/frame_1/DoAction.as");
