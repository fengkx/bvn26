this._name = "zh1atm";

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_210/frame_5/DoAction.as");
