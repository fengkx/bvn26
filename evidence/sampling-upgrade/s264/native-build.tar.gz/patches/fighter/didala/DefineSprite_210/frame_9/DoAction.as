_name = "bbb";

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_210/frame_9/DoAction.as");
