动作 = 3;
bs = 1;
ql -= 300;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_706/DoAction.as");
