_root._y = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_966/DoAction.as");
