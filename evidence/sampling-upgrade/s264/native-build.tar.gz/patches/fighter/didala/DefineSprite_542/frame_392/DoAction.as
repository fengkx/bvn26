动作 = 1;
ql += 10;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_392/DoAction.as");
