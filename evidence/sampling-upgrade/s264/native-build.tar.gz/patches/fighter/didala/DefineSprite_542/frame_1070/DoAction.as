kcplayed = 2;
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_1070/DoAction.as");
