stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_909/DoAction.as");
