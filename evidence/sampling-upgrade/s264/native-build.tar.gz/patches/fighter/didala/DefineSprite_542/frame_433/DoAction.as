ql += 5;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_433/DoAction.as");
