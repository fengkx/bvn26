动作 = 1;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_194/DoAction.as");
