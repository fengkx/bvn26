_parent.moveX(speed * 18);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_34/DoAction.as");
