_root.cbsd(pn);
_root.showFace(pn,"迪达拉2");

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_707/DoAction.as");
