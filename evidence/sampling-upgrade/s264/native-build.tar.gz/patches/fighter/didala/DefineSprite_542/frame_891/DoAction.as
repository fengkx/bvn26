play();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_891/DoAction.as");
