动作 = 1;
jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_579/DoAction.as");
