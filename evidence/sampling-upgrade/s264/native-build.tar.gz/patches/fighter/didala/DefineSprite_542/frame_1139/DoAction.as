stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_1139/DoAction.as");
