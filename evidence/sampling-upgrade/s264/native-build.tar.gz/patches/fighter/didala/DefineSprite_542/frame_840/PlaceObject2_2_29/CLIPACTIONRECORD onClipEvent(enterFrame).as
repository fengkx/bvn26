onClipEvent(enterFrame){
   _root.s260Observe("enterFrame_before",this);
   beida();
   _root.s260Observe("enterFrame_after",this);
}
