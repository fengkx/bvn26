gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_676/DoAction.as");
