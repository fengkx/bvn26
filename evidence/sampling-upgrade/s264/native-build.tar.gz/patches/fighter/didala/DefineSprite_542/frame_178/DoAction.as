动作 = 1;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_178/DoAction.as");
