_root.touchFloorEffect(_parent);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_928/DoAction.as");
