gotoAndStop("落2");
play();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_106/DoAction.as");
