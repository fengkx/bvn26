jump = 1;
jumped = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_77/DoAction.as");
