khit = 0;
jump = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_121/DoAction.as");
