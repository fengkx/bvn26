jump = 1;
_parent.moveY(-250);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_826/DoAction.as");
