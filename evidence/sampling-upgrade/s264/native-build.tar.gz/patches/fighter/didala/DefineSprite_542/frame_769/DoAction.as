_root.cbsw(pn);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_769/DoAction.as");
