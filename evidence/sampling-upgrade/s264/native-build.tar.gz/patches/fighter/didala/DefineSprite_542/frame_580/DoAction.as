动作 = 3;
bs = 1;
ql -= 100;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_580/DoAction.as");
