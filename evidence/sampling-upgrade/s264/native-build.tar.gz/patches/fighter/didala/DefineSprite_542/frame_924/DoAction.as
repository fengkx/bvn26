stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_924/DoAction.as");
