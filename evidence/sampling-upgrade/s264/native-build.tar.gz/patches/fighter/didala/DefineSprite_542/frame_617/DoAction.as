_root.bsw(pn);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_617/DoAction.as");
