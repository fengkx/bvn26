jump = 0;
jumped = 1;
gotoAndStop("站立");
play();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_913/DoAction.as");
