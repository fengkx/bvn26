doZhaoHuan();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_845/DoAction.as");
