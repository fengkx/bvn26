if(sw == true)
{
   stop();
}

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_942/DoAction.as");
