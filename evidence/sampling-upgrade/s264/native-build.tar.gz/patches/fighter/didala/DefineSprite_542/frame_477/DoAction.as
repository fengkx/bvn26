_root.bsd(pn);
_root.showFace(pn,"迪达拉1");

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_477/DoAction.as");
