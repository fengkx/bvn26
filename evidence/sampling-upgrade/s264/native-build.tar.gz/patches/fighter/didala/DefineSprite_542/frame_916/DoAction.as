hited = 0;
play();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_916/DoAction.as");
