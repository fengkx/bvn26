_parent.moveX((- speed) * 6);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_970/DoAction.as");
