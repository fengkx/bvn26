gotoAndStop("落");
play();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_73/DoAction.as");
