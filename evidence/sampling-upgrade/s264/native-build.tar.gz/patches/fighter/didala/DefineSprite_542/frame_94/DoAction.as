jump = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_94/DoAction.as");
