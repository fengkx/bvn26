onDefence(2);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_892/DoAction.as");
