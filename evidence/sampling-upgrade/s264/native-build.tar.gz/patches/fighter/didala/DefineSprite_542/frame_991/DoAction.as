kcplayed = 3;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_991/DoAction.as");
