onBeHit(true);

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_917/DoAction.as");
