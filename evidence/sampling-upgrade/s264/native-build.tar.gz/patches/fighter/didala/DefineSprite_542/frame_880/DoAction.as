动作 = 2;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_880/DoAction.as");
