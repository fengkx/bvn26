onBeHit();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_542/frame_904/DoAction.as");
