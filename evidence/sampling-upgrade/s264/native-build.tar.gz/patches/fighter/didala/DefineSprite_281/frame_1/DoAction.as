stop();
var movspeed = 20;
var played = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_281/frame_1/DoAction.as");
