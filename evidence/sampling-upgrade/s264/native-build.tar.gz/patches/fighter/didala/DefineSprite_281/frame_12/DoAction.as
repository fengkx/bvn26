stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_281/frame_12/DoAction.as");
