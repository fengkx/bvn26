this._name = "zh3atm";

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_281/frame_5/DoAction.as");
