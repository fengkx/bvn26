stop();
var movspeed = 15;
var played = 0;

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_84/frame_1/DoAction.as");
