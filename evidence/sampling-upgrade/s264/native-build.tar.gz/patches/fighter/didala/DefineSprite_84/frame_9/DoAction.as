_name = "bbb";

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_84/frame_9/DoAction.as");
