this._name = "tzatm";

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_84/frame_5/DoAction.as");
