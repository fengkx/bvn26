stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_84/frame_12/DoAction.as");
