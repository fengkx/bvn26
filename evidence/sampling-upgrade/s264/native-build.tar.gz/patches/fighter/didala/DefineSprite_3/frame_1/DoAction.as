stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_3/frame_1/DoAction.as");
