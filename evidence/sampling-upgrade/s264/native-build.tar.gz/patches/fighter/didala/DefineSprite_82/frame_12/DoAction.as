stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_82/frame_12/DoAction.as");
