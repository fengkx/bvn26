stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_502/frame_25/DoAction.as");
