stop();

_root.aiGeoStamp(this, "game/fighter/didala.swf#DefineSprite_173/frame_25/DoAction.as");
