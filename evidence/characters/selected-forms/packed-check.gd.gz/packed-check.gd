extends SceneTree

func _initialize() -> void:
	assert(ProjectSettings.load_resource_pack(OS.get_cmdline_user_args()[0], true))
	var available: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://generated/main/character_selection/available.json"))
	assert(available.fighters.size() == 40 and available.helpers.size() == 6)
	assert(available.fighters["佐助须佐"] == "sasukexz")
	for id in ["shouju", "ichigo", "minrenx", "sasukexz"]:
		assert(id in available.fighters.values())
		var fighter: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://generated/fighters/%s/fighter.json" % id))
		assert(fighter.form_frame == 1)
	var intro: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://generated/main/intro/intro.json"))
	assert(intro.fighters.has("sasukexz"))
	var portraits: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://generated/main/character_selection/portraits.json"))
	for texture in portraits["佐助须佐"].textures:
		assert(ResourceLoader.exists("res://generated/main/character_selection/" + texture))
	for id in ["rifagu-2", "rukia-2", "yihu-2", "minren-2", "sasuke-2"]:
		assert(available.forms.has(id))
		assert(id in available.fighters.values())
		var fighter: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://generated/forms/%s/fighter.json" % id))
		assert(fighter.form_frame == 2)
		assert(intro.fighters.has(id))
		for texture in portraits[fighter.fighter_id].textures:
			assert(ResourceLoader.exists("res://generated/main/character_selection/" + texture))
		assert(ResourceLoader.exists("res://generated/forms/%s/player_controller/body.gd" % id))
	print("PACKED_SELECTED_FORMS_OK fighters=40 helpers=6 forms=5 portrait_textures=true opening=true")
	quit()
