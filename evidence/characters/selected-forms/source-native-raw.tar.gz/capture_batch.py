from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();out=Path('/private/tmp/bvn-selected-forms/batch');out.mkdir(exist_ok=True)
catalog=json.load(open('manifest.json'))['fighter_catalog'];results=[]
for casepath in sorted(Path('evidence/characters/selected-forms/cases').glob('*.json')):
 c=json.loads(casepath.read_text());selected={slot:next(n for n,r in catalog.items() if Path(r.get('url','')).stem.lower()==slug and int(r.get('WKframe',1))==int(c['selected_forms'].get(slot,1))) for slot,slug in c['fighters'].items()};folder=out/c['id'];folder.mkdir();start=time.monotonic()
 commands=[['tools/probes/build_ai_reference.py','--ffdec','/Users/fengkx/me/agent-code/toolchains/jpexs-26.2.1/ffdec.jar','--output',str(folder/'probe'),'--run-id',c['id'],'--frames',str(c['frames']),'--p1-character',selected['p1'],'--p2-character',selected['p2'],'--p1-helper','我爱罗','--p2-helper','魂','--move-case',str(casepath),'--profile','diagnostic','--diagnostic-auto-start','--diagnostic-key-injection','--diagnostic-trace-hooks'],['tools/probes/capture_native_player.py',str(folder/'probe'),str(folder/'original.log'),'--allow-window-activation'],['tools/probes/collect_ai_reference.py','--build',str(folder/'probe'),'--capture',str(folder/'original.log'),'--output',str(folder/'collected'),'--retain-post-done-frames']]
 for index,command in enumerate(commands):
  with (folder/f'step-{index}.log').open('w') as log:p=subprocess.run([sys.executable,*command],stdout=log,stderr=subprocess.STDOUT,timeout=180)
  if p.returncode:raise RuntimeError((c['id'],index,p.returncode))
 results.append({'id':c['id'],'seconds':time.monotonic()-start});(out/'captures.json').write_text(json.dumps(results,indent=2)+'\n');print(c['id'],'captured',flush=True)
