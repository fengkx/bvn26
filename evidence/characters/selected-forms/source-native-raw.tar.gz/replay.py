from pathlib import Path
import subprocess,json,time,sys
from concurrent.futures import ThreadPoolExecutor
out=Path('/private/tmp/bvn-selected-forms/native');out.mkdir(exist_ok=True);root=Path.cwd()
godot='/Users/fengkx/me/agent-code/toolchains/godot-4.7.2/Godot.app/Contents/MacOS/Godot'
def run(path):
 c=json.loads(path.read_text());start=time.monotonic();dest=out/(c['id']+'.json')
 with (out/(c['id']+'.log')).open('w') as log:
  p=subprocess.run([godot,'--headless','--path',str(root/'godot'),'--log-file',str(out/(c['id']+'-engine.log')),'-s','res://tests/move_case_reference.gd','--quit-after','1600','--',str(path.resolve()),str(dest)],stdout=log,stderr=subprocess.STDOUT,timeout=180)
 text=(out/(c['id']+'.log')).read_text();r={'id':c['id'],'exit':p.returncode,'seconds':time.monotonic()-start,'errors':[l for l in text.splitlines() if any(x in l for x in ['SCRIPT ERROR','leaked','still in use'])]};print(r,flush=True);return r
with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,sorted(Path('evidence/characters/selected-forms/cases').glob('*.json'))))
(out/'execution.json').write_text(json.dumps(rows,indent=2)+'\n')
