from pathlib import Path
import json,subprocess,time
from concurrent.futures import ThreadPoolExecutor
out=Path('/private/tmp/bvn-selected-forms/authority');out.mkdir(exist_ok=True)
names=['日番谷万解','露其雅始解','一护万解','鸣人九尾','佐助咒怨'];godot='/Users/fengkx/me/agent-code/toolchains/godot-4.7.2/Godot.app/Contents/MacOS/Godot'
def run(i):
 selection=[names[i],names[(i+1)%5],'织姬','魂','现世'];start=time.monotonic()
 with (out/f'{i}.log').open('w') as log:p=subprocess.run([godot,'--headless','--path','godot','--log-file',str(out/f'{i}-engine.log'),'-s','res://tests/authority_projection_smoke.gd','--quit-after','3000','--',json.dumps(selection,ensure_ascii=False)],stdout=log,stderr=subprocess.STDOUT,timeout=180)
 log=(out/f'{i}.log').read_text();r={'selection':selection,'exit':p.returncode,'seconds':time.monotonic()-start,'passed':p.returncode==0 and 'AUTHORITY_PROJECTION_OK' in log and not any(k in log for k in ['SCRIPT ERROR','leaked','still in use'])};print(r,flush=True);return r
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,range(5)))
(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');assert all(r['passed'] for r in results)
