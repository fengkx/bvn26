from pathlib import Path
import subprocess,json,time
root=Path.cwd();out=Path('/private/tmp/bvn-selected-forms/visual');out.mkdir(exist_ok=True)
godot='/Users/fengkx/me/agent-code/toolchains/godot-4.7.2/Godot.app/Contents/MacOS/Godot'
rows=[]
for slug,name in [('rifagu','日番谷万解'),('rukia','露其雅始解'),('yihu','一护万解'),('minren','鸣人九尾'),('sasuke','佐助咒怨')]:
 dest=out/(slug+'-2');dest.mkdir(exist_ok=True);start=time.monotonic()
 with (dest/'run.log').open('w') as log:
  p=subprocess.run([godot,'--path',str(root/'godot'),'--log-file',str(dest/'engine.log'),'-s','/private/tmp/bvn-selected-forms/visual.gd','--quit-after','1800','--',str(dest),name],stdout=log,stderr=subprocess.STDOUT,timeout=100)
 s=(dest/'run.log').read_text();row={'id':slug+'-2','exit':p.returncode,'seconds':time.monotonic()-start,'passed':p.returncode==0 and 'SELECTED_FORM_VISUAL_CAPTURE_OK' in s and 'SCRIPT ERROR' not in s};rows.append(row);print(row,flush=True)
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['passed'] for r in rows)
