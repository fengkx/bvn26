from pathlib import Path
import subprocess,os,time,threading,http.server,functools,json,signal
root=Path.cwd();out=Path('/private/tmp/bvn-sasukexz-integration/web');out.mkdir(exist_ok=True)
class Handler(http.server.SimpleHTTPRequestHandler):
 def end_headers(self):
  self.send_header('Cross-Origin-Opener-Policy','same-origin');self.send_header('Cross-Origin-Embedder-Policy','require-corp');super().end_headers()
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(root/'dist/web')));threading.Thread(target=server.serve_forever,daemon=True).start()
profile=out/'chrome';profile.mkdir(exist_ok=True)
p=subprocess.Popen(['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--headless=new','--user-data-dir='+str(profile),'--remote-debugging-port=0','--no-first-run','--no-default-browser-check','--enable-unsafe-swiftshader','--window-size=1280,900','about:blank'],stdout=(out/'chrome.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
try:
 deadline=time.monotonic()+30
 while not (profile/'DevToolsActivePort').exists():
  assert time.monotonic()<deadline;time.sleep(.1)
 endpoint='http://127.0.0.1:'+(profile/'DevToolsActivePort').read_text().splitlines()[0]
 with (out/'boot.json').open('w') as log:
  result=subprocess.run(['/Users/fengkx/.local/share/mise/installs/node/24.18.0/bin/node','tools/test_chromium_web_boot.mjs',endpoint,'http://127.0.0.1:'+str(server.server_port)+'/index.html',str(out/'boot.png')],stdout=log,stderr=subprocess.STDOUT,timeout=90)
 print('WEB_BOOT_EXIT',result.returncode)
 assert result.returncode==0
finally:
 os.killpg(p.pid,signal.SIGTERM)
 try:p.wait(timeout=8)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
 server.shutdown()
