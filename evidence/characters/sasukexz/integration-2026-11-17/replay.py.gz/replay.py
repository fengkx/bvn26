import json,subprocess,time,sys,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'tools/probes')
from compare_mode_reference import compare
root=Path.cwd();out=Path('/private/tmp/bvn-sasukexz-integration/replay');out.mkdir(exist_ok=True)
original=Path('/Users/fengkx/me/agent-code/bvn2_6-sasukexz')
godot='/Users/fengkx/me/agent-code/toolchains/godot-4.7.2/Godot.app/Contents/MacOS/Godot'
rows=json.loads(Path('evidence/characters/sasukexz/comparisons.json').read_text())
def run(row):
 case=root/row['paths']['fixture'];source=original/row['paths']['source'];assert hashlib.sha256(case.read_bytes()).hexdigest()==row['hashes']['fixture'];assert hashlib.sha256(source.read_bytes()).hexdigest()==row['hashes']['source'];native=out/(row['id']+'.json');start=time.monotonic()
 with (out/(row['id']+'.log')).open('w') as log:
  p=subprocess.run([godot,'--headless','--path',str(root/'godot'),'--log-file',str(out/(row['id']+'-engine.log')),'-s','res://tests/move_case_reference.gd','--quit-after','1200','--',str(case),str(native)],stdout=log,stderr=subprocess.STDOUT,timeout=180)
 log=(out/(row['id']+'.log')).read_text();result={'id':row['id'],'exit':p.returncode,'seconds':time.monotonic()-start,'comparison':compare(source,native),'errors':[l for l in log.splitlines() if any(k in l for k in ['SCRIPT ERROR','leaked','still in use'])]};print(row['id'],result['comparison']['status'],flush=True);return result
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,rows))
(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
assert all(r['exit']==0 and r['comparison']['status']=='matched' and not r['errors'] for r in results)
