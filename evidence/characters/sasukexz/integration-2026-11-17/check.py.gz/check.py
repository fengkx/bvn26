import subprocess,json,time,concurrent.futures
from pathlib import Path
out=Path('/private/tmp/bvn-sasukexz-integration')
godot='/Users/fengkx/me/agent-code/toolchains/godot-4.7.2/Godot.app/Contents/MacOS/Godot'
cases=[('selection','character_selection_smoke.gd',[]),('online-selection','online_character_selection_smoke.gd',[]),('authority','authority_projection_smoke.gd',['--',json.dumps(['佐助须佐','仙鸣','织姬','魂','现世'],ensure_ascii=False)]),('sound','sasukexz_sound_pause_cleanup.gd',[])]
def run(case):
 name,script,args=case;t=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.run([godot,'--headless','--path','godot','--log-file',str(out/(name+'-engine.log')),'-s','res://tests/'+script,'--quit-after','3000']+args,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 s=(out/(name+'.log')).read_text();return {'name':name,'exit':p.returncode,'seconds':time.monotonic()-t,'diagnostics':[l for l in s.splitlines() if any(k in l for k in ['_OK','ERROR','leaked','still in use'])]}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(run,cases))
(out/'checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps(results,ensure_ascii=False))
