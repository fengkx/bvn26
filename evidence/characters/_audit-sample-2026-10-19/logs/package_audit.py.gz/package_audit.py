import datetime,gzip,hashlib,json,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tools/probes'))
from compare_mode_reference import compare,source_rows
scratch=Path('/tmp/sample-new-audit-20261019');out=root/'evidence/characters/_audit-sample-2026-10-19'
def sha(data):return hashlib.sha256(data).hexdigest()
def save(source,target):
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
def stamp(path):return datetime.datetime.fromtimestamp(path.stat().st_mtime,datetime.timezone.utc).isoformat()
results=[]
for role in ['orochimaru','jiraiya','pain']:
 old={r['id']:r for r in json.load(open(root/f'evidence/characters/{role}/comparisons.json'))}
 timeline=json.load(open(root/f'godot/generated/fighters/{role}/timeline.json'))
 masks={f['frame'] for f in timeline['frames'] if any('clip_depth' in p for p in f['display_list'])}
 for kind in ['existing','adversarial']:
  cases=root/f'evidence/characters/{role}/cases' if kind=='existing' else out/'cases'/role
  for fixture in sorted(cases.glob('*.json')):
   case=json.load(open(fixture));case_id=case['id'];folder=scratch/f'flash-{role}-{kind}'/case_id
   events=folder/'events.jsonl';native=scratch/(('native-fresh-' if kind=='existing' else 'adversarial-native-')+role)/(case_id+'.json')
   if not events.exists() or not native.exists():continue
   build=folder.parent/('build-'+case_id);env=build/'capture-environment.json'
   if not env.exists() or not json.load(open(env))['done']:continue
   r=compare(events,native);source=source_rows(events)
   target=out/'traces';save(events,target/(case_id+'.original.jsonl.gz'));save(native,target/(case_id+'.native.json.gz'))
   for name in ['build.json','case.txt','capture-environment.json','original.log']:
    save(build/name,out/'source-builds'/(case_id+'.'+name+'.gz'))
   save(scratch/('probe-'+role)/'instrumentation.diff',out/'instrumentation'/(role+'.diff.gz'))
   result={**r,'id':case_id,'fighter':role,'kind':kind,'capture_completed_at_utc':stamp(events),'native_completed_at_utc':stamp(native),'run_id':json.load(open(build/'build.json'))['run_id'],'first_divergence':r['differences'][0] if r['differences'] else None,'different_states':len(r['differences']),'hashes':{'fixture':sha(fixture.read_bytes()),'original_events':sha(events.read_bytes()),'native':sha(native.read_bytes()),'original_states_canonical':sha(json.dumps(source,sort_keys=True,separators=(',',':')).encode())},'fixture':str(fixture.relative_to(root)),'observed':{}}
   del result['differences']
   if r['differences']:(out/'diagnostics').mkdir(exist_ok=True);(out/'diagnostics'/(case_id+'.differences.json')).write_text(json.dumps(r['differences'],indent=2)+'\n')
   lo,hi=case['target_frames'][:2];result['source_target_seen']=any(x['slot']==case['slot'] and lo is not None and lo<=x['frame']<=hi for x in source)
   for slot in ['p1','p2']:
    rows=[x for x in source if x['slot']==slot]
    result['observed'][slot]={'hp_min':min(x['hp'] for x in rows),'hits_max':max(x['hits'] for x in rows),'paused_states':sum(x['paused'] for x in rows),'final':rows[-1],'facings':sorted({x['xscale'] for x in rows})}
   result['observed']['source_mask_frames_visited']=sorted({x['frame'] for x in source if x['slot']=='p1'}&masks)
   if case_id in old:
    prior=root/old[case_id]['paths']['source'];prior_rows=source_rows(prior)
    result['prior_source_states_identical']=source==prior_rows
    result['prior_original_states_canonical_sha256']=sha(json.dumps(prior_rows,sort_keys=True,separators=(',',':')).encode())
   results.append(result)
(out/'comparisons.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':len(results),'matched':sum(x['status']=='matched' for x in results),'different':[{'id':x['id'],'first':x['first_divergence']} for x in results if x['status']!='matched']},ensure_ascii=False))
