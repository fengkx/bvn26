import subprocess,time,json
from pathlib import Path
base=Path('/tmp/sample-new-audit-20261019')
for role in ['orochimaru','jiraiya','pain']:
 for kind,cases in [('existing',f'evidence/characters/{role}/cases'),('adversarial',f'evidence/characters/_audit-sample-2026-10-19/cases/{role}')]:
  name=role+'-'+kind
  cmd=['python3','tools/test_move_references.py','--probe',str(base/('probe-'+role)),'--cases',cases,'--native',str(base/('native-fresh-'+role)),'--output',str(base/('flash-'+name)),'--capture-runner','tools/probes/capture_native_player.py','--player-app','/Users/fengkx/me/code/flash-player/Flash Player.app','--allow-window-activation','--capture-only']
  start=time.time();r=subprocess.run(cmd,stdout=(base/(name+'-flash.log')).open('w'),stderr=subprocess.STDOUT)
  result={'batch':name,'exit':r.returncode,'started_at':start,'finished_at':time.time()};(base/(name+'-capture-execution.json')).write_text(json.dumps(result,indent=2));print(result,flush=True)
