import subprocess,json,time
from pathlib import Path
base=Path('/tmp/sample-new-audit-20261019');root=Path.cwd()
for role in ['orochimaru','jiraiya','pain']:
 out=base/('native-fresh-'+role);out.mkdir()
 cases=sorted((root/f'evidence/characters/{role}/cases').glob('*.json'))
 (out/'case-paths.json').write_text(json.dumps([str(x) for x in cases]))
 cmd=['/Users/fengkx/me/agent-code/bvn-godot-toolchain/Godot.app/Contents/MacOS/Godot','--headless','--path',str(root/'godot'),'--log-file',str(out/'engine.log'),'-s','res://tests/move_case_reference.gd','--quit-after','5000','--','--batch',str(out/'case-paths.json'),str(out)]
 start=time.time();r=subprocess.run(cmd,capture_output=True,text=True,timeout=900);log=r.stdout+r.stderr;(out/'batch.log').write_text(log)
 result={'role':role,'exit':r.returncode,'started_at':start,'finished_at':time.time(),'passed':r.returncode==0 and 'MOVE_CASE_BATCH_OK' in log and 'SCRIPT ERROR' not in log}
 (out/'execution.json').write_text(json.dumps(result,indent=2));print(result,flush=True)
